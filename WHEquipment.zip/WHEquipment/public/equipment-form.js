const els = {
  form:       document.getElementById('equipmentForm'),
  recordId:   document.getElementById('recordId'),
  serial:     document.getElementById('serial_number'),
  owner:      document.getElementById('owner'),
  brand:      document.getElementById('brand'),
  model:      document.getElementById('model'),
  status:     document.getElementById('status'),
  location:   document.getElementById('location'),
  airTagged:  document.getElementById('air_tagged'),
  notes:      document.getElementById('notes'),
  formTitle:  document.getElementById('formTitle'),
  submitBtn:  document.getElementById('submitBtn'),
  pageTitle:  document.getElementById('pageTitle')
};

const params = new URLSearchParams(location.search);
const editId = params.get('id');

async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) {
    let message = 'Request failed.';
    try {
      const body = await res.json();
      message = body.errors?.join('\n') || message;
    } catch {}
    throw new Error(message);
  }
  if (res.status === 204) return null;
  return res.json();
}

function getFormData() {
  return {
    serial_number: els.serial.value.trim().toUpperCase(),
    owner:         els.owner.value.trim(),
    brand:         els.brand.value.trim(),
    model:         els.model.value,
    status:        els.status.value,
    location:      els.location.value.trim(),
    air_tagged:    els.airTagged.value,
    notes:         els.notes.value.trim()
  };
}

async function loadForEdit() {
  if (!editId) return;
  els.formTitle.textContent = 'Edit Equipment';
  els.submitBtn.textContent = 'Loading...';
  els.submitBtn.disabled = true;
  try {
    const item = await api(`/api/equipment/${editId}`);
    els.recordId.value  = item.id;
    els.serial.value    = item.serial_number;
    els.owner.value     = item.owner || '';
    els.brand.value     = item.brand || '';
    els.model.value     = item.model;
    els.status.value    = item.status;
    els.location.value  = item.location || '';
    els.airTagged.value = item.air_tagged || 'No';
    els.notes.value     = item.notes || '';
    els.formTitle.textContent = 'Edit Equipment';
    els.submitBtn.textContent = 'Update Equipment';
    els.submitBtn.disabled = false;
    els.pageTitle.textContent = 'Edit Equipment · Lox Equipment Tracker';
  } catch (err) {
    els.submitBtn.textContent = 'Unable to load equipment';
    alert(err.message);
  }
}

els.serial.addEventListener('input', () => { els.serial.value = els.serial.value.toUpperCase(); });

els.form.addEventListener('submit', async event => {
  event.preventDefault();
  const id = els.recordId.value;
  const payload = getFormData();
  try {
    if (id) {
      await api(`/api/equipment/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
    } else {
      await api('/api/equipment', { method: 'POST', body: JSON.stringify(payload) });
    }
    location.href = 'index.html';
  } catch (err) {
    alert(err.message);
  }
});

loadForEdit();
