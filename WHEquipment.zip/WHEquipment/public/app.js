const socket = io();

const els = {
  syncStatus:      document.getElementById('syncStatus'),
  searchInput:     document.getElementById('searchInput'),
  filterStatus:    document.getElementById('filterStatus'),
  countSummary:    document.getElementById('countSummary'),
  kpis:            document.getElementById('kpis'),
  list:            document.getElementById('equipmentList'),
  template:        document.getElementById('equipmentCardTemplate'),
  exportBtn:       document.getElementById('exportBtn'),
  historyModal:    document.getElementById('historyModal'),
  historyTitle:    document.getElementById('historyTitle'),
  historySubtitle: document.getElementById('historySubtitle'),
  historyList:     document.getElementById('historyList'),
  closeHistoryBtn: document.getElementById('closeHistoryBtn'),
  movementModal:    document.getElementById('movementModal'),
  movementSubtitle: document.getElementById('movementSubtitle'),
  closeMovementBtn: document.getElementById('closeMovementBtn'),
  movementOptions:  document.querySelectorAll('.movement-option')
};

let equipment = [];
let activeHistoryEquipmentId = null;
let activeMovementEquipmentId = null;
let lastHistoryRows = [];
let lastMovementRows = [];

const statusLabels = {
  'Working':           'Working',
  'Needs Repair':      'Needs Repair',
  'In Maintenance':    'In Maintenance',
  'WH':                'WH',
  'Out of Commission': 'Out of Commission'
};

function setSyncStatus(text, state) {
  els.syncStatus.textContent = text;
  els.syncStatus.className = `status-pill ${state || ''}`;
}

socket.on('connect',    () => setSyncStatus('Live Sync Online', 'online'));
socket.on('disconnect', () => setSyncStatus('Offline / Reconnecting', 'offline'));
socket.on('equipment:list', rows => {
  equipment = Array.isArray(rows) ? rows : [];
  render();
});
socket.on('equipment:history', payload => {
  if (Number(payload?.equipmentId) === Number(activeHistoryEquipmentId)) {
    lastHistoryRows = payload.history || [];
    renderCombinedHistory();
  }
});
socket.on('equipment:movements', payload => {
  if (Number(payload?.equipmentId) === Number(activeHistoryEquipmentId)) {
    lastMovementRows = payload.movements || [];
    renderCombinedHistory();
  }
});

async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) {
    let message = `Request failed (HTTP ${res.status}).`;
    try {
      const body = await res.json();
      message = body.errors?.join('\n') || message;
    } catch {}
    throw new Error(message);
  }
  if (res.status === 204) return null;
  return res.json();
}

els.searchInput.addEventListener('input', render);
els.filterStatus.addEventListener('change', render);
els.closeHistoryBtn.addEventListener('click', closeHistory);
els.historyModal.addEventListener('click', event => { if (event.target === els.historyModal) closeHistory(); });
els.closeMovementBtn.addEventListener('click', closeMovementModal);
els.movementModal.addEventListener('click', event => { if (event.target === els.movementModal) closeMovementModal(); });
document.addEventListener('keydown', event => {
  if (event.key !== 'Escape') return;
  if (!els.historyModal.classList.contains('hidden')) closeHistory();
  if (!els.movementModal.classList.contains('hidden')) closeMovementModal();
});

els.movementOptions.forEach(btn => {
  btn.addEventListener('click', async () => {
    if (!activeMovementEquipmentId) return;
    const destination = btn.dataset.destination;
    try {
      await api(`/api/equipment/${activeMovementEquipmentId}/movements`, {
        method: 'POST',
        body: JSON.stringify({ destination })
      });
      closeMovementModal();
    } catch (err) {
      alert(err.message);
    }
  });
});

// ── Export to Excel ──────────────────────────────────────────────────────────
els.exportBtn.addEventListener('click', () => {
  const rows = equipment.filter(matchesFilters);
  if (!rows.length) { alert('No records to export.'); return; }

  const data = rows.map(item => ({
    'Serial #':   item.serial_number,
    'Owner':      item.owner || '',
    'Brand':      item.brand || '',
    'Model':      item.model,
    'Status':     item.status,
    'Location':   item.location || '',
    'Air Tagged': item.air_tagged || 'No',
    'Notes':      item.notes || '',
    'Added':      formatDateTime(item.created_at),
    'Updated':    formatDateTime(item.updated_at)
  }));

  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Equipment');

  // Auto-size columns
  const colWidths = Object.keys(data[0]).map(key => ({
    wch: Math.max(key.length, ...data.map(r => String(r[key] || '').length)) + 2
  }));
  ws['!cols'] = colWidths;

  const timestamp = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `equipment-inventory-${timestamp}.xlsx`);
});

// ── Filters ──────────────────────────────────────────────────────────────────
function matchesFilters(item) {
  const q      = els.searchInput.value.trim().toLowerCase();
  const status = els.filterStatus.value;
  const haystack = [item.serial_number, item.owner, item.brand, item.model, item.status, item.location, item.notes]
    .join(' ').toLowerCase();
  return (!q || haystack.includes(q)) && (status === 'all' || item.status === status);
}

// ── KPIs ─────────────────────────────────────────────────────────────────────
function renderKpis(rows) {
  const statuses = ['Working', 'Needs Repair', 'In Maintenance', 'WH', 'Out of Commission'];
  els.kpis.innerHTML = statuses.map(s => {
    const count = rows.filter(item => item.status === s).length;
    return `<div class="kpi"><strong>${count}</strong><span>${s}</span></div>`;
  }).join('');
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function addDetail(dl, label, value) {
  const dt = document.createElement('dt');
  dt.textContent = label;
  const dd = document.createElement('dd');
  dd.textContent = value || '—';
  dl.append(dt, dd);
}

function formatValue(value) {
  const text = String(value ?? '').trim();
  if (!text) return '—';
  return statusLabels[text] || text;
}

function formatDateTime(value) {
  if (!value) return '—';
  const normalized = String(value).includes('T') ? value : `${value}Z`;
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
}

function slugify(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

// ── History Modal (edit history + movement log, merged) ──────────────────────
async function openHistory(item) {
  activeHistoryEquipmentId = item.id;
  els.historyTitle.textContent    = 'Activity Log';
  els.historySubtitle.textContent = `${item.owner || item.serial_number} • ${item.serial_number}`;
  els.historyList.innerHTML = '<div class="empty">Loading history...</div>';
  els.historyModal.classList.remove('hidden');
  document.body.classList.add('modal-open');
  try {
    const [history, movements] = await Promise.all([
      api(`/api/equipment/${item.id}/history`),
      api(`/api/equipment/${item.id}/movements`)
    ]);
    lastHistoryRows = history || [];
    lastMovementRows = movements || [];
    renderCombinedHistory();
  } catch (err) {
    els.historyList.innerHTML = `<div class="empty">${err.message}</div>`;
  }
}

function closeHistory() {
  activeHistoryEquipmentId = null;
  lastHistoryRows = [];
  lastMovementRows = [];
  els.historyModal.classList.add('hidden');
  document.body.classList.remove('modal-open');
}

function renderCombinedHistory() {
  const entries = [
    ...lastHistoryRows.map(row => ({ kind: 'edit', created_at: row.created_at, action: row.action, changes: row.changes })),
    ...lastMovementRows.map(row => ({ kind: 'moved', created_at: row.created_at, destination: row.destination, moved_by: row.moved_by }))
  ].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  if (!entries.length) {
    els.historyList.innerHTML = '<div class="empty">No activity has been recorded yet.</div>';
    return;
  }

  els.historyList.innerHTML = '';
  entries.forEach(entry => {
    const item = document.createElement('article');
    item.className = 'history-item';

    const title = document.createElement('div');
    title.className = 'history-item-title';

    if (entry.kind === 'moved') {
      title.innerHTML = `<strong class="moved">Moved → ${entry.destination}</strong><span>${formatDateTime(entry.created_at)}</span>`;
      item.appendChild(title);
    } else {
      title.innerHTML = `<strong>${entry.action === 'created' ? 'Created' : 'Updated'}</strong><span>${formatDateTime(entry.created_at)}</span>`;
      item.appendChild(title);

      const changes = document.createElement('div');
      changes.className = 'history-changes';

      (entry.changes || []).forEach(change => {
        const line = document.createElement('div');
        line.className = 'history-change';
        const label  = document.createElement('span');
        label.className = 'history-label';
        label.textContent = change.label || change.field;
        const before = document.createElement('span');
        before.className = 'history-before';
        before.textContent = formatValue(change.before);
        const arrow = document.createElement('span');
        arrow.className = 'history-arrow';
        arrow.textContent = '→';
        const after = document.createElement('span');
        after.className = 'history-after';
        after.textContent = formatValue(change.after);

        line.append(label, before, arrow, after);
        changes.appendChild(line);
      });

      if (!entry.changes || !entry.changes.length) {
        const line = document.createElement('div');
        line.className = 'history-change';
        line.textContent = 'Record created.';
        changes.appendChild(line);
      }

      item.appendChild(changes);
    }

    els.historyList.appendChild(item);
  });
}

// ── Movement Modal ────────────────────────────────────────────────────────────
function openMovementModal(item) {
  activeMovementEquipmentId = item.id;
  els.movementSubtitle.textContent = `${item.owner || item.serial_number} • ${item.serial_number}`;
  els.movementModal.classList.remove('hidden');
  document.body.classList.add('modal-open');
}

function closeMovementModal() {
  activeMovementEquipmentId = null;
  els.movementModal.classList.add('hidden');
  document.body.classList.remove('modal-open');
}

// ── Main render ────────────────────────────────────────────────────────────
function render() {
  const filtered = equipment.filter(matchesFilters);

  els.countSummary.textContent = `${filtered.length} of ${equipment.length} record${equipment.length === 1 ? '' : 's'}`;
  renderKpis(equipment);

  els.list.innerHTML = '';

  if (!filtered.length) {
    els.list.innerHTML = '<div class="empty">No equipment matches your filters.</div>';
    return;
  }

  filtered.forEach(item => {
    const node = els.template.content.cloneNode(true);
    const card = node.querySelector('.equipment-card');

    node.querySelector('h3').textContent = item.owner || item.model;
    node.querySelector('.serial').textContent = item.serial_number;

    const badge = node.querySelector('.badge');
    badge.textContent = formatValue(item.status);
    badge.classList.add(slugify(item.status));

    const dl = node.querySelector('.details');
    addDetail(dl, 'Brand', item.brand);
    addDetail(dl, 'Model', item.model);
    addDetail(dl, 'Location', item.location);
    addDetail(dl, 'Air Tagged', item.air_tagged);
    addDetail(dl, 'Updated', formatDateTime(item.updated_at));

    const notes = node.querySelector('.notes');
    if (item.notes) {
      notes.textContent = item.notes;
    } else {
      notes.remove();
    }

    node.querySelector('.move-btn').addEventListener('click', () => openMovementModal(item));
    node.querySelector('.history-btn').addEventListener('click', () => openHistory(item));
    node.querySelector('.edit-btn').addEventListener('click', () => {
      location.href = `add-equipment.html?id=${item.id}`;
    });
    node.querySelector('.delete-btn').addEventListener('click', async () => {
      if (!confirm(`Delete ${item.serial_number}? This cannot be undone.`)) return;
      try {
        await api(`/api/equipment/${item.id}`, { method: 'DELETE' });
      } catch (err) {
        alert(err.message);
      }
    });

    els.list.appendChild(node);
  });
}

render();
