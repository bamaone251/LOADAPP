require('dotenv').config();

const path = require('path');
const fs = require('fs');
const express = require('express');
const http = require('http');
const helmet = require('helmet');
const cors = require('cors');
const Database = require('better-sqlite3');
const { Server } = require('socket.io');

const PORT = Number(process.env.PORT || 3045);
const APP_NAME = process.env.APP_NAME || 'Lox Equipment Tracker_noadmin';
const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'equipment.db');

fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Migrate: drop old schema if it has legacy columns
const tableInfo = db.prepare("PRAGMA table_info(equipment)").all();
const hasOldSchema = tableInfo.some(col => col.name === 'type' || col.name === 'date_received');
if (hasOldSchema) {
  db.exec('DROP TABLE IF EXISTS equipment_history; DROP TABLE IF EXISTS equipment;');
}

db.exec(`
CREATE TABLE IF NOT EXISTS equipment (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  serial_number TEXT NOT NULL UNIQUE,
  owner TEXT NOT NULL DEFAULT '',
  brand TEXT NOT NULL DEFAULT '',
  model TEXT NOT NULL DEFAULT 'Truck',
  status TEXT NOT NULL DEFAULT 'Working',
  location TEXT NOT NULL DEFAULT '',
  air_tagged TEXT NOT NULL DEFAULT 'No',
  notes TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS equipment_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  equipment_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  changed_by TEXT DEFAULT 'System',
  changes_json TEXT NOT NULL DEFAULT '[]',
  snapshot_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_equipment_history_equipment_id_created_at
ON equipment_history(equipment_id, created_at DESC);

CREATE TABLE IF NOT EXISTS equipment_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  equipment_id INTEGER NOT NULL,
  destination TEXT NOT NULL,
  moved_by TEXT NOT NULL DEFAULT 'User',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_equipment_movements_equipment_id_created_at
ON equipment_movements(equipment_id, created_at DESC);

CREATE TRIGGER IF NOT EXISTS equipment_updated_at
AFTER UPDATE ON equipment
FOR EACH ROW
BEGIN
  UPDATE equipment SET updated_at = datetime('now') WHERE id = OLD.id;
END;
`);

// Seed from spreadsheet image if table is empty
const rowCount = db.prepare('SELECT COUNT(*) as c FROM equipment').get().c;
if (rowCount === 0) {
  const seedData = [
    // Walkies (Trucks)
    { serial_number: '821-22-56333', owner: 'WLK 01', brand: 'Raymond', model: 'Truck', status: 'Working',       location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '821-22-56335', owner: 'WLK 02', brand: 'Raymond', model: 'Truck', status: 'Working',       location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '821-22-56334', owner: 'WLK 03', brand: 'Raymond', model: 'Truck', status: 'Working',       location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '821-22-56290', owner: 'WLK 04', brand: 'Raymond', model: 'Truck', status: 'WH',            location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '821-23-68581', owner: 'WLK 05', brand: 'Raymond', model: 'Truck', status: 'Working',       location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '821-23-68530', owner: 'WLK 06', brand: 'Raymond', model: 'Truck', status: 'Working',       location: 'FK90', air_tagged: 'Yes', notes: 'Shipped 5/24/2026' },
    { serial_number: '821-23-0072397', owner: 'WLK 07', brand: 'Raymond', model: 'Truck', status: 'Working',     location: 'WH',   air_tagged: 'No',  notes: '' },
    { serial_number: '821-23-0072396', owner: 'WLK 08', brand: 'Raymond', model: 'Truck', status: 'Working',     location: 'WH',   air_tagged: 'No',  notes: '' },
    { serial_number: '821-25-0086290', owner: 'WLK 09', brand: 'Raymond', model: 'Truck', status: 'Working',     location: 'WH',   air_tagged: 'No',  notes: '' },
    // Stackers
    { serial_number: '621-22-17005', owner: 'STK 01', brand: 'Raymond', model: 'Stacker', status: 'Working',     location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '621-22-17008', owner: 'STK 02', brand: 'Raymond', model: 'Stacker', status: 'Working',     location: 'WH',   air_tagged: 'No',  notes: '' },
    { serial_number: '621-22-17126', owner: 'STK 03', brand: 'Raymond', model: 'Stacker', status: 'Working',     location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '621-22-17129', owner: 'STK 04', brand: 'Raymond', model: 'Stacker', status: 'Working',     location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '621-23-18371', owner: 'STK 05', brand: 'Raymond', model: 'Stacker', status: 'Working',     location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '621-23-18283', owner: 'STK 06', brand: 'Raymond', model: 'Stacker', status: 'Working',     location: 'WH',   air_tagged: 'Yes', notes: '' },
    { serial_number: '621-24-0019440', owner: 'STK 07', brand: 'Raymond', model: 'Stacker', status: 'Working',   location: 'WH',   air_tagged: 'No',  notes: '' },
    { serial_number: '621-24-0019446', owner: 'STK 08', brand: 'Raymond', model: 'Stacker', status: 'Working',   location: 'FE11', air_tagged: 'No',  notes: 'Shipped 6/16/2026' },
    { serial_number: '621-24-0019442', owner: 'STK 09', brand: 'Raymond', model: 'Stacker', status: 'Working',   location: 'WH',   air_tagged: 'Yes', notes: '' },
    // Scrubbers
    { serial_number: '22075154',  owner: 'SCRB 01', brand: 'PowerBoss', model: 'Scrubber', status: 'Working',    location: 'FE17', air_tagged: 'Yes', notes: 'PHX26DA — Shipped 6/16/2026' },
    { serial_number: '23026376',  owner: 'SCRB 03', brand: 'PowerBoss', model: 'Scrubber', status: 'Working',    location: 'FE14', air_tagged: 'Yes', notes: 'PHX26DA — Shipped 5/23/2026' },
    { serial_number: '23116407',  owner: 'SCRB 04', brand: 'PowerBoss', model: 'Scrubber', status: 'Working',    location: 'WH',   air_tagged: 'No',  notes: 'PHX26DA' },
  ];

  const insert = db.prepare(`
    INSERT INTO equipment (serial_number, owner, brand, model, status, location, air_tagged, notes)
    VALUES (@serial_number, @owner, @brand, @model, @status, @location, @air_tagged, @notes)
  `);

  const insertAll = db.transaction((rows) => {
    for (const row of rows) insert.run(row);
  });

  insertAll(seedData);
  console.log(`Seeded ${seedData.length} equipment records.`);
}

const allowedModels = new Set(['Truck', 'Stacker', 'Scrubber', 'Dock Plate', 'Sled']);
const allowedStatuses = new Set(['Working', 'Needs Repair', 'In Maintenance', 'WH', 'Out of Commission']);
const allowedAirTagged = new Set(['Yes', 'No']);

const trackedFields = ['serial_number', 'owner', 'brand', 'model', 'status', 'location', 'air_tagged', 'notes'];

const fieldLabels = {
  serial_number: 'Serial #',
  owner: 'Owner',
  brand: 'Brand',
  model: 'Model',
  status: 'Status',
  location: 'Location',
  air_tagged: 'Air Tagged',
  notes: 'Notes'
};

function normalizeText(value) {
  return String(value ?? '').trim();
}

function normalizeSerial(value) {
  return normalizeText(value).toUpperCase();
}

function cleanForHistory(row) {
  const out = {};
  for (const key of trackedFields) out[key] = row?.[key] ?? '';
  return out;
}

function buildChanges(before, after) {
  return trackedFields
    .filter(field => String(before?.[field] ?? '') !== String(after?.[field] ?? ''))
    .map(field => ({
      field,
      label: fieldLabels[field] || field,
      before: before?.[field] ?? '',
      after: after?.[field] ?? ''
    }));
}

function addHistory(equipmentId, action, changes, snapshot, changedBy = 'User') {
  db.prepare(`
    INSERT INTO equipment_history (equipment_id, action, changed_by, changes_json, snapshot_json)
    VALUES (?, ?, ?, ?, ?)
  `).run(
    equipmentId,
    action,
    normalizeText(changedBy) || 'User',
    JSON.stringify(changes || []),
    JSON.stringify(cleanForHistory(snapshot || {}))
  );
}

function parseHistoryRow(row) {
  return {
    ...row,
    changes: JSON.parse(row.changes_json || '[]'),
    snapshot: JSON.parse(row.snapshot_json || '{}')
  };
}

function validateEquipment(input, partial = false) {
  const errors = [];
  const data = {};

  if (!partial || input.serial_number !== undefined) {
    data.serial_number = normalizeSerial(input.serial_number);
    if (!data.serial_number) errors.push('Serial number is required.');
    if (data.serial_number.length > 80) errors.push('Serial number is too long.');
  }

  if (!partial || input.owner !== undefined) {
    data.owner = normalizeText(input.owner);
    if (data.owner.length > 120) errors.push('Owner is too long.');
  }

  if (!partial || input.brand !== undefined) {
    data.brand = normalizeText(input.brand);
    if (data.brand.length > 120) errors.push('Brand is too long.');
  }

  if (!partial || input.model !== undefined) {
    data.model = normalizeText(input.model);
    if (!allowedModels.has(data.model)) errors.push('Invalid model type.');
  }

  if (!partial || input.status !== undefined) {
    data.status = normalizeText(input.status);
    if (!allowedStatuses.has(data.status)) errors.push('Invalid status.');
  }

  if (!partial || input.location !== undefined) {
    data.location = normalizeText(input.location);
    if (data.location.length > 120) errors.push('Location is too long.');
  }

  if (!partial || input.air_tagged !== undefined) {
    data.air_tagged = normalizeText(input.air_tagged);
    if (!allowedAirTagged.has(data.air_tagged)) errors.push('Air Tagged must be Yes or No.');
  }

  if (!partial || input.notes !== undefined) {
    data.notes = normalizeText(input.notes);
    if (data.notes.length > 1000) errors.push('Notes are too long.');
  }

  return { data, errors };
}

function listEquipment() {
  return db.prepare(`
    SELECT e.*,
           (SELECT COUNT(*) FROM equipment_history h WHERE h.equipment_id = e.id) AS history_count
    FROM equipment e
    ORDER BY
      CASE status
        WHEN 'Needs Repair'      THEN 1
        WHEN 'In Maintenance'    THEN 2
        WHEN 'Out of Commission' THEN 3
        WHEN 'WH'                THEN 4
        WHEN 'Working'           THEN 5
        ELSE 6
      END,
      updated_at DESC
  `).all();
}

function getEquipmentById(id) {
  return db.prepare('SELECT * FROM equipment WHERE id = ?').get(id);
}

function listHistory(equipmentId) {
  return db.prepare(`
    SELECT * FROM equipment_history
    WHERE equipment_id = ?
    ORDER BY created_at DESC, id DESC
  `).all(equipmentId).map(parseHistoryRow);
}

// ── App / Server setup ────────────────────────────────────────────────────
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function broadcastList() {
  io.emit('equipment:list', listEquipment());
}

function broadcastHistory(equipmentId) {
  io.emit('equipment:history', {
    equipmentId,
    history: listHistory(equipmentId)
  });
}

// ── Routes ─────────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ ok: true, app: APP_NAME, time: new Date().toISOString() });
});

app.get('/api/equipment', (req, res) => {
  res.json(listEquipment());
});

app.get('/api/equipment/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(404).json({ errors: ['Record not found.'] });
  }
  const item = getEquipmentById(id);
  if (!item) return res.status(404).json({ errors: ['Record not found.'] });
  res.json(item);
});

app.post('/api/equipment', (req, res) => {
  const { data, errors } = validateEquipment(req.body || {});
  if (errors.length) return res.status(400).json({ errors });

  const existing = db.prepare('SELECT id FROM equipment WHERE serial_number = ?').get(data.serial_number);
  if (existing) return res.status(409).json({ errors: ['A record with this serial number already exists.'] });

  const result = db.prepare(`
    INSERT INTO equipment (serial_number, owner, brand, model, status, location, air_tagged, notes)
    VALUES (@serial_number, @owner, @brand, @model, @status, @location, @air_tagged, @notes)
  `).run(data);

  const created = getEquipmentById(result.lastInsertRowid);
  addHistory(created.id, 'created', buildChanges({}, created), created, req.body?.changed_by);

  broadcastList();
  broadcastHistory(created.id);

  res.status(201).json(created);
});

app.put('/api/equipment/:id', (req, res) => {
  const id = Number(req.params.id);
  const before = getEquipmentById(id);
  if (!before) return res.status(404).json({ errors: ['Record not found.'] });

  const { data, errors } = validateEquipment(req.body || {});
  if (errors.length) return res.status(400).json({ errors });

  const dupe = db.prepare('SELECT id FROM equipment WHERE serial_number = ? AND id != ?').get(data.serial_number, id);
  if (dupe) return res.status(409).json({ errors: ['Another record already uses this serial number.'] });

  db.prepare(`
    UPDATE equipment
    SET serial_number = @serial_number,
        owner = @owner,
        brand = @brand,
        model = @model,
        status = @status,
        location = @location,
        air_tagged = @air_tagged,
        notes = @notes
    WHERE id = @id
  `).run({ ...data, id });

  const after = getEquipmentById(id);
  const changes = buildChanges(before, after);
  if (changes.length) {
    addHistory(id, 'updated', changes, after, req.body?.changed_by);
    broadcastHistory(id);
  }

  broadcastList();
  res.json(after);
});

app.delete('/api/equipment/:id', (req, res) => {
  const id = Number(req.params.id);
  const existing = getEquipmentById(id);
  if (!existing) return res.status(404).json({ errors: ['Record not found.'] });

  db.prepare('DELETE FROM equipment WHERE id = ?').run(id);
  broadcastList();
  res.status(204).end();
});

app.get('/api/equipment/:id/history', (req, res) => {
  const id = Number(req.params.id);
  const existing = getEquipmentById(id);
  if (!existing) return res.status(404).json({ errors: ['Record not found.'] });

  res.json(listHistory(id));
});

function listMovements(equipmentId) {
  return db.prepare(`SELECT * FROM equipment_movements
    WHERE equipment_id = ? ORDER BY created_at DESC, id DESC`).all(equipmentId);
}

app.get('/api/equipment/:id/movements', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1 || !getEquipmentById(id)) {
    return res.status(404).json({ errors: ['Record not found.'] });
  }
  res.json(listMovements(id));
});

app.post('/api/equipment/:id/movements', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1 || !getEquipmentById(id)) {
    return res.status(404).json({ errors: ['Record not found.'] });
  }
  const destination = normalizeText(req.body?.destination);
  if (!['Store', 'Driver', 'Load Desk', 'Maintenance'].includes(destination)) {
    return res.status(400).json({ errors: ['Select a valid movement destination.'] });
  }
  const movedBy = normalizeText(req.body?.moved_by) || 'User';
  if (movedBy.length > 120) {
    return res.status(400).json({ errors: ['Name is too long.'] });
  }
  const movement = db.transaction(() => {
    const result = db.prepare(`INSERT INTO equipment_movements
      (equipment_id, destination, moved_by) VALUES (?, ?, ?)`).run(id, destination, movedBy);
    db.prepare('UPDATE equipment SET location = ? WHERE id = ?').run(destination, id);
    return db.prepare('SELECT * FROM equipment_movements WHERE id = ?').get(result.lastInsertRowid);
  })();
  broadcastList();
  io.emit('equipment:movements', { equipmentId: id, movements: listMovements(id) });
  res.status(201).json(movement);
});

// Return useful errors for API failures instead of an HTML error page.
app.use('/api', (req, res) => {
  res.status(404).json({ errors: ['API endpoint not found.'] });
});
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ errors: ['Unable to save or load data. Check the server logs.'] });
});

// ── Socket.io ──────────────────────────────────────────────────────────────
io.on('connection', (socket) => {
  socket.emit('equipment:list', listEquipment());
});

// ── Start ──────────────────────────────────────────────────────────────────
server.listen(PORT, () => {
  console.log(`${APP_NAME} listening on http://127.0.0.1:${PORT}`);
});
