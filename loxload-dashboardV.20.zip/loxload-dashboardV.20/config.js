/* ==========================================================
   Loxload Dashboard — configuration
   This is the only file you should need to edit.
   ========================================================== */

window.DASHBOARD_CONFIG = {
  title: "Loxload Dashboard",

  // Sources offered in every frame dropdown. Add more entries here.
  apps: [
      { key: "f3", name: "Yard",      url: "https://yard.loxload.com/" },
  { key: "f10", name: "Yard Notes",      url: "https://requests.loxload.com/" },
    { key: "f1", name: "PLB Log",   url: "https://plblog.loxload.com/" },
    { key: "f2", name: "Store Map", url: "https://map.loxload.com/" },
    
    { key: "f14", name: "Checklist", url: "https://checklist.loxload.com/" },
    { key: "f4", name: "Shift Notes",     url: "https://comms.loxload.com/" },
    { key: "f6", name: "Efficiency", url: "https://ops.loxload.com/" },
    
    { key: "f7", name: "Error Log", url: "https://error.loxload.com/" },
    { key: "f8", name: "Equipment", url: "https://equipment.loxload.com/" },
    { key: "f12", name: "Loader Times", url: "https://tracker.loxload.com/" },
    { key: "f19", name: "Store Requests", url: "https://storerequests.loxload.com/" },
   
   
    { key: "f13", name: "Load Map", url: "https://loadmap.loxload.com/" },
    
   
 
   
    
  ],

  // Default layout matching the reference picture.
  // Positions and sizes are percentages of the dashboard area.
  layout: [
    { source: "f3",  x: 0,    y: 0,  w: 47,   h: 100, zoom: 50 }, // Yard
    { source: "f10", x: 68.5,   y: 0,  w: 33,   h: 45,  zoom: 80 }, // Yard Notes
    { source: "f14", x: 47,   y: 0,  w: 21.5,   h: 45,  zoom: 60 }, // Checklist
    { source: "f13", x: 47,   y: 45, w: 21.5, h: 55,  zoom: 70 }, // Load Map
    { source: "f2",  x: 68.5, y: 45, w: 31.5, h: 55,  zoom: 110 }, // Store Map
  ],

  // Querystring URLs are only accepted for these hosts (subdomains included).
  allowedHosts: ["loxload.com", "andytalbert.com", "bamaone251.github.io"],

  // Browser features the framed apps may use.
  iframeAllow: "geolocation; fullscreen; clipboard-read; clipboard-write; microphone; camera; autoplay",

  // Wallboard: reload every panel every N hours to clear memory leaks (0 = off)
  autoReloadHours: .1,
};
