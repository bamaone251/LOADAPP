(() => {
'use strict';
const cfg=window.DASHBOARD_CONFIG, grid=document.querySelector('#grid'), $=s=>document.querySelector(s), key='loxdash:workspace:v2';
let editing=false, items=[], serial=Date.now(), statusTimer;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
// Object entries specify geometry; source-only entries remain supported.
const defaults = () => cfg.layout.map((entry, i) => {
  const panel = typeof entry === 'string' ? { source: entry } : entry;
  return {
    id: String(++serial),
    source: panel.source,
    x: panel.x ?? [0, 66.6667, 0, 33.3333, 66.6667][i],
    y: panel.y ?? (i < 2 ? 0 : 50),
    w: panel.w ?? (i === 0 ? 66.6667 : 33.3333),
    h: panel.h ?? 50,
    zoom: panel.zoom ?? 100,
  };
});
function message(s){$('#status').textContent=s;clearTimeout(statusTimer);statusTimer=setTimeout(()=>$('#status').textContent='',3500)}
function save(){try{localStorage.setItem(key,JSON.stringify(items))}catch{message('Browser storage unavailable. Layout will not survive a reload.')}}
function valid(p){return p&&typeof p.id==='string'&&cfg.apps.some(a=>a.key===p.source)&&['x','y','w','h','zoom'].every(k=>Number.isFinite(p[k]))&&p.x>=0&&p.y>=0&&p.w>=15&&p.h>=18&&p.x+p.w<=100.01&&p.y+p.h<=100.01&&p.zoom>=50&&p.zoom<=200}
try{const v=JSON.parse(localStorage.getItem(key));items=Array.isArray(v)&&v.length<=30&&v.every(valid)?v:defaults()}catch{items=defaults()}
$('#brand-title').textContent=cfg.title;document.title=cfg.title;
function tick(){$('#clock').textContent=new Date().toLocaleString(undefined,{weekday:'short',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}tick();setInterval(tick,10000);
function urlFor(app){const raw=new URLSearchParams(location.search).get(app.key);if(raw){try{const u=new URL(raw.startsWith('/')||/^https?:/.test(raw)?raw:'https://'+raw,location.href);if(u.origin===location.origin||(u.protocol==='https:'&&cfg.allowedHosts.some(h=>u.hostname===h||u.hostname.endsWith('.'+h))))return u.href}catch{}}return app.url}
function position(el,p){Object.assign(el.style,{left:p.x+'%',top:p.y+'%',width:p.w+'%',height:p.h+'%'})}
function zoom(el,p){const f=el.querySelector('iframe'),z=p.zoom/100;Object.assign(f.style,{width:100/z+'%',height:100/z+'%',transform:`scale(${z})`});el.querySelector('output').textContent=p.zoom+'%'}
function build(p){const el=document.createElement('section');el.className='panel';el.dataset.id=p.id;
el.innerHTML='<div class="surface"><div class="bar"><button class="move" title="Drag to move frame" aria-label="Move frame">✥</button><select aria-label="Frame source"></select><button data-action="out" title="Zoom out">−</button><output class="zoom"></output><button data-action="in" title="Zoom in">+</button><button data-action="reload" title="Reload frame">↻</button><button data-action="max" title="Maximize or restore">⤢</button><a class="popout" target="_blank" rel="noopener" title="Open source in new tab">↗</a><button data-action="delete" title="Delete frame">×</button></div><div class="content"><iframe referrerpolicy="no-referrer"></iframe></div></div>';
const select=el.querySelector('select'),frame=el.querySelector('iframe');
for(const app of cfg.apps){const o=document.createElement('option');o.value=app.key;o.textContent=app.name;select.append(o)}select.value=p.source;frame.allow=cfg.iframeAllow;
function source(){const app=cfg.apps.find(a=>a.key===p.source);frame.src=urlFor(app);frame.title=app.name;el.querySelector('a').href=urlFor(app)}source();zoom(el,p);position(el,p);
select.onchange=()=>{p.source=select.value;source();save()};
el.addEventListener('click',e=>{const action=e.target.closest('[data-action]')?.dataset.action;if(!action)return;if(action==='delete'){items=items.filter(x=>x!==p);el.remove();save();empty();return}if(action==='reload')frame.src=frame.src;if(action==='max')el.classList.toggle('maximized');if(action==='out'||action==='in'){p.zoom=clamp(p.zoom+(action==='in'?10:-10),50,200);zoom(el,p);save()}});
el.querySelector('.move').addEventListener('pointerdown',e=>drag(e,el,p,'move'));
for(const dir of ['n','s','e','w','ne','nw','se','sw']){const h=document.createElement('div');h.className='handle '+dir;h.title='Drag to resize';h.addEventListener('pointerdown',e=>drag(e,el,p,dir));el.append(h)}grid.append(el)}
function empty(){grid.querySelector('.empty')?.remove();if(!items.length){const e=document.createElement('div');e.className='empty';e.textContent='Your layout is empty. Click + Add frame to get started.';grid.append(e)}}
function render(){grid.replaceChildren();items.forEach(build);empty()}
function drag(e,el,p,dir){if(!editing||el.classList.contains('maximized')||e.button!==0)return;e.preventDefault();const target=e.currentTarget,start={...p},rect=grid.getBoundingClientRect(),sx=e.clientX,sy=e.clientY;target.setPointerCapture(e.pointerId);document.body.classList.add('dragging');el.style.zIndex=5;
function move(ev){const dx=Math.round((ev.clientX-sx)/rect.width*100),dy=Math.round((ev.clientY-sy)/rect.height*100);if(dir==='move'){p.x=clamp(start.x+dx,0,100-p.w);p.y=clamp(start.y+dy,0,100-p.h)}else{if(dir.includes('e'))p.w=clamp(start.w+dx,15,100-start.x);if(dir.includes('s'))p.h=clamp(start.h+dy,18,100-start.y);if(dir.includes('w')){p.x=clamp(start.x+dx,0,start.x+start.w-15);p.w=start.x+start.w-p.x}if(dir.includes('n')){p.y=clamp(start.y+dy,0,start.y+start.h-18);p.h=start.y+start.h-p.y}}position(el,p)}
function end(){target.removeEventListener('pointermove',move);target.removeEventListener('pointerup',end);target.removeEventListener('pointercancel',end);document.body.classList.remove('dragging');el.style.zIndex='';save()}
target.addEventListener('pointermove',move);target.addEventListener('pointerup',end);target.addEventListener('pointercancel',end)}
$('#edit').onclick=()=>{editing=!editing;document.body.classList.toggle('editing',editing);$('#edit').setAttribute('aria-pressed',String(editing));$('#edit').textContent=editing?'Done editing':'Edit layout';$('#hint').textContent=editing?'Drag ✥ to move. Drag frame edges or the mint corner to resize horizontally and vertically. Frames can overlap; move them into open space.':'Choose a source in any frame. Use Edit layout to move and resize frames. Changes save automatically on this browser.'};
$('#add').onclick=()=>{if(items.length>=30){message('Maximum 30 frames.');return}const p={id:String(++serial),source:cfg.apps[0].key,x:5+(items.length%4)*5,y:5+(items.length%4)*5,w:40,h:40,zoom:100};items.push(p);grid.querySelector('.empty')?.remove();build(p);save();if(!editing)$('#edit').click();message('Frame added. Choose its source and drag it into place.')};
$('#reset').onclick=()=>{if(confirm('Restore the default four-frame layout?')){items=defaults();save();render()}};
function reload(){grid.querySelectorAll('iframe').forEach(f=>f.src=f.src)}$('#reload').onclick=reload;
$('#fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen()}catch{message('Fullscreen is unavailable in this browser.')}};
document.addEventListener('keydown',e=>{if(e.key==='Escape')grid.querySelectorAll('.maximized').forEach(el=>el.classList.remove('maximized'))});
if(cfg.autoReloadHours>0)setInterval(reload,cfg.autoReloadHours*3600000);
let lock;async function awake(){try{if('wakeLock' in navigator&&document.visibilityState==='visible')lock=await navigator.wakeLock.request('screen')}catch{}}document.addEventListener('visibilitychange',awake);awake();render();
})();
