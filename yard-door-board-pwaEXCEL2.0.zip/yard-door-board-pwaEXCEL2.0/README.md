# Yard Door Board

Shared real-time communication board for Yard Drivers and the Load Desk.

## Workflow

1. **Yard Driver:** select an Empty door (10–49), enter the Trailer #, and tap **Make Available**.
2. **Load Desk:** switch to **Load Desk View**, assign an Available trailer to a **Run #**, and start Loading.
3. **Load Desk:** tap **Loading Complete** when the trailer is finished.
4. **Yard Driver:** switch to **Yard Driver View** and mark the trailer **Pooled** or **Dispatched** when it leaves the door.
5. The door automatically returns to **Empty** and can receive the next trailer.
6. **Pooled** trailers remain in the shared **Pooled trailers — on site** list with their Run #, source door, and time pooled. In Yard Driver view, use **Dispatch trailer** when one leaves the yard. Directly dispatched trailers do not enter the pool.

All connected users receive updates live through Socket.IO.

The connection indicator shows Live, Reconnecting, or Offline. Changes are paused while disconnected; the latest board arrives automatically on reconnect. An edit opened before another operator changes the same door is rejected with instructions to cancel and reopen it. Other doors can still be updated independently.

Search matches partial trailer or run numbers, ignoring letter case, across doors and pooled trailers. The status filter applies to doors only. Summary totals always describe the whole board. Cards show elapsed time in their current status; timers refresh every 30 seconds and survive restarts and midnight. Corrections to a run or out-of-service flag do not restart the loading timer. Changing the trailer or status does. Older data starts with its last recorded update as an approximate status-start time.

Trailer numbers cannot be assigned to more than one door or simultaneously exist at a door and in the pool. Comparison ignores letter case and surrounding whitespace. Existing duplicates are left intact for manual correction.

## Out of Service doors

- The **Load Desk** can mark any door **Out of Service** and optionally enter a reason.
- Out of Service is stored separately from the trailer/loading status, so existing trailer and Run information is preserved.
- The **Yard Driver View** shows a large red **OUT OF SERVICE — DO NOT USE** warning and will not allow a new trailer to be placed on that door.
- A Load Desk user can **Return to Service** at any time.
- Out-of-service flags persist across midnight until someone returns the door to service.


## PWA

The app is installable on supported mobile and desktop browsers. It includes:

- Web app manifest
- 192px and 512px app icons
- Service worker
- Standalone display mode
- Offline app-shell fallback
- Live operational/API data is never served from cache
- An **Install App** button appears when the browser exposes the PWA install prompt

> For PWA installation outside localhost, serve the app through HTTPS (for example with Nginx + Certbot).

## Daily archive

The container runs in `America/Chicago`. Shortly after the Central Time date changes, the completed day's board and activity log are saved to:

`./archives/DAILY_YARD_BOARD_MM-DD-YY.pdf`

All doors, trailers, runs, statuses, timers, and out-of-service flags carry forward unchanged into the new day. Pooled trailers also carry forward. Today's Activity switches to the new day's events; older events remain in the database and archives. Midnight never clears the yard inventory.

## Exports

- Excel: **Export Excel**
- PDF: **Export PDF**

Both formats include the current pooled trailer inventory. Excel includes a separate Pooled Trailers worksheet.

## Docker deployment

```bash
docker compose up -d --build
```

Open:

```text
http://YOUR-SERVER-IP:3030
```

Persistent data:

- SQLite database: `./data/yard-board.db`
- Daily PDF archives: `./archives/`

## Reverse proxy example

Proxy your HTTPS domain to port `3030`. WebSocket upgrade headers are required for live Socket.IO updates.

## Quick edit
Double-click a door card heading on desktop, or press and hold a card on a touch device, to open the manual edit window. Trailer #, Run #, status, and Out of Service can be corrected directly. Manual edits are written to the daily activity history. Entering a trailer on an Empty door selects Available automatically. Explicitly selecting Empty clears the trailer and run.


## Card editing gestures
- Desktop: double-click any door card to edit it.
- Phone/tablet/PWA: press and hold a door card for about 0.65 seconds.
- The service-worker cache version was bumped so installed PWAs receive the updated JavaScript/CSS after deployment.


## Nightly Excel archives
- At 11:55 PM America/Chicago time, the server automatically saves the current day's board snapshot and activity history as an Excel workbook in `archives/`.
- Files use the format `DAILY_YARD_ACTIVITY_MM-DD-YY.xlsx`.
- All users can open **Daily Archives** in the app to view/download the shared saved files.
- This runs on the server, so no browser needs to remain open.

## Updating and testing

See UPDATE.md for deployment details. `npm test` runs the isolated regression suite against a disposable database. It never opens the operational database.
