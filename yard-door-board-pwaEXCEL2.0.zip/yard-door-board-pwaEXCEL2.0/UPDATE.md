# Installing this update

Extract this update into the existing application folder (the folder containing docker-compose.yml), replacing the application files. The ZIP contains no data or archives folders; keep your existing folders in place. The original deployment database has not been modified while developing or testing this update.

Rebuild and restart from that folder:

```sh
docker compose up -d --build
```

Reload all open browser tabs or close and reopen installed apps after deployment. Older clients cannot save without the new conflict-check information. Database columns and the pooled-trailer table are added automatically at startup, preserving existing rows and history.

## New behavior

1. Midnight archives the day without clearing any doors or pooled trailers. Today's Activity changes to the new day's events.
2. A Live / Reconnecting / Offline indicator shows connection health. Changes pause until the live connection returns and fresh state arrives.
3. Every door action checks the version opened by the operator. If someone else has changed that door, cancel and reopen the dialog to review it before trying again. The old form cannot overwrite the newer information.
4. Cards show time in their current status, updated every 30 seconds. Run corrections and service flags do not reset the loading timer. Older records initially use their last update as an approximate start time.
5. Search finds partial trailer or run numbers across both the board and pool. Status filtering applies to doors; summary totals remain overall totals.
6. Pooled trailers remain on the shared on-site list until a driver confirms dispatch. The list preserves run, source door, and pooling time, persists across restarts, and appears in Excel/PDF exports.

The pool starts empty at upgrade. Historical Pooled events are not automatically converted into current inventory because the old app did not record later pool departures. Tracking begins with trailers pooled after this update.

Previous fixes remain included: immediate edit refresh, errors inside dialogs, duplicate-trailer prevention, and a full-width board that adds columns as the viewport widens. Trailer uniqueness also covers the pool. Existing duplicate records are not automatically removed.

## Verification

Run `npm install` then `npm test`. Tests use temporary data and cover legacy migration, stale edits, duplicate trailers, concurrent placement, time-in-status persistence, midnight carryover, pool dispatch, Excel inventory, offline guards, search, and client-side state refresh. Browser verification also covers editing, search, pooling, dispatch, connection loss, and responsive layout.
