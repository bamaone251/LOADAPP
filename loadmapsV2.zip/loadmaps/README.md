# Mobile-Friendly Load Map (ALDI-style)

A lightweight Flask app to create, edit, and view mobile-friendly Load Maps for trailers (30 pallet positions, 2x15).

## Quick Start

```bash
python3 -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
# Open http://localhost:5959
```

## Notes
- Data is stored locally in `database.sqlite3`. Everyone signs in (see User accounts below).
- Click a pallet to edit its details (Store #, Type, Zone). Long-press to mark/delete.
- New: Scan/store pallet label SSCC-18 barcodes. In the pallet modal, tap the SSCC field and scan (fastest). Optional camera scan is available on supported mobile browsers.
- Tap the "Print / Save PDF" button to generate a printable load map.
- Optimized for mobile use (big tap targets, sticky action bar).


## Daily home screen and archive
- The home list includes only maps whose `map_date` is today in `APP_TIMEZONE`
  (default America/Chicago). Legacy maps use their creation date in that timezone.
- Run numbers sort numerically, lowest first; empty run numbers appear last.
- Open `/archive` or the archive link on Home to browse dated snapshots and download
  complete load maps as JSON. Original database records remain available by ID.
- At 11:57 p.m. local time the running app saves each map to
  `data/archives/YYYY-MM-DD/ID.json`. It checks every 15 seconds, catches up old
  dates after downtime, and refreshes snapshots for late saves or edits.
- Docker persists archives in the existing `./data` mount. Keep the app running
  overnight. Rebuild/restart the container to activate source changes.
- Archived maps open read-only in the trailer layout and support Print / PDF.
- New-map dates and home-list rollover follow the configured app timezone.


## Install as a PWA
- Rebuild/restart Docker, then open the app over HTTPS. Plain HTTP on a LAN IP
  cannot register the service worker or offer normal PWA installation. Localhost
  and 127.0.0.1 are allowed for development. Configure HTTPS at your reverse proxy
  using a certificate trusted by the devices that will install the app.
- Chrome/Edge/Android: choose Install app when offered, or use the browser's
  Install menu. iPhone/iPad Safari: Share > Add to Home Screen.
- Once loaded online, the home app shell can reopen offline. Existing device
  drafts can be resumed, and new maps can be drafted offline. Save map queues
  drafts for synchronization when the app is open and connectivity returns.
- Server lists, maps not saved as device drafts, and archive downloads require
  the server connection. APIs are deliberately never cached as today's data.
- New shell updates activate after existing app tabs/windows close; reopen the
  app to pick up updates. Local drafts are preserved separately from shell caches.
- The server must stay running for the 11:57 p.m. Central archive, even when
  all installed app windows are closed. Installing the PWA does not move the
  database or archive scheduler onto a phone or desktop device.

## Two-page printing
Print / PDF uses Letter portrait: page 1 contains all 30 trailer positions; page 2 contains counts, activity, sanitary checks, additional details and notes. Both pages repeat run/trailer/date/stores. Long content scales down to stay on its sheet. Select Letter, 100% scale, and disable browser headers/footers for the intended layout. Close and reopen installed app windows after deployment to activate updated offline assets.



## User accounts
- Every page and API now requires sign-in. Unsigned visits go to `/login`;
  API calls return 401 (offline drafts stay on the device and sync after sign-in).
- First start creates the admin account **ANDY / Andy123**. Change the password
  on the Account page right away. (Override the first admin with `ADMIN_USERNAME`
  / `ADMIN_PASSWORD` env vars *before* the first start; ignored afterwards.)
- Usernames are stored uppercase and are not case-sensitive at sign-in.
  Passwords are case-sensitive and stored as salted hashes (Werkzeug scrypt).
- Admins manage users at **/account**: add, rename, reset password, make/remove
  admin, delete. Deleting someone who has messages switches the account off
  instead, so conversations stay readable; you can reactivate it later.
- Each user can change their own password at /account. Changing or resetting a
  password signs that user out on their other devices.
- New maps pre-fill the Loader field with the signed-in user's display name.
- Sessions last 30 days (`SESSION_DAYS`). The session key is created once at
  `data/secret_key` (or set `SECRET_KEY`). Keep that file with the database.
- Behind nginx over HTTPS, set `SESSION_COOKIE_SECURE=1` in docker-compose.

## Messages
- **/messages**: pick a person, type, Enter to send (Shift+Enter for a new line).
- The Messages button on every page shows an unread count (checks every 20 s).
  Open conversations refresh every 5 s. Opening a conversation marks it read.
- Messages are stored in the same SQLite database (`messages` table), max 2,000
  characters each.
