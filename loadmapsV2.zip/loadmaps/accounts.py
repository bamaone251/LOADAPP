"""User accounts, sign-in and user-to-user messaging for Load Map.

Registered from app.py with ``accounts.init_app(app, get_db)``.
"""
from __future__ import annotations

import datetime
import os
import re
import secrets
import sqlite3
import time
from functools import wraps
from pathlib import Path

from flask import (Blueprint, g, jsonify, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

bp = Blueprint("accounts", __name__)
_get_db = None

USERNAME_RE = re.compile(r"^[A-Z0-9_.-]{2,32}$")
MIN_PASSWORD = 6
MAX_MESSAGE = 2000
# Pages and files reachable without signing in.
PUBLIC_ENDPOINTS = {"accounts.login", "accounts.logout", "static", "health",
                    "service_worker", "favicon"}


def utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


# ---------- Setup ----------
def init_app(app, get_db):
    """Wire accounts into the Flask app: secret key, tables, login gate, routes."""
    global _get_db
    _get_db = get_db
    app.secret_key = os.environ.get("SECRET_KEY") or _load_secret(app.config["DB_PATH"])
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=datetime.timedelta(days=int(os.environ.get("SESSION_DAYS", "30"))),
    )
    with app.app_context():
        _init_tables(get_db())
    app.before_request(_require_login)
    app.context_processor(lambda: {"current_user": getattr(g, "user", None)})
    app.register_blueprint(bp)


def _load_secret(db_path: str) -> str:
    """Keep one random session key next to the database so sign-ins survive restarts."""
    path = Path(db_path).resolve().parent / "secret_key"
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as fh:
            fh.write(secrets.token_hex(32))
    except FileExistsError:
        pass
    for _ in range(20):  # another worker may still be writing it
        key = path.read_text().strip()
        if key:
            return key
        time.sleep(0.05)
    raise RuntimeError(f"Empty secret key file: {path}")


def _init_tables(db):
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE COLLATE NOCASE,
        display_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        last_login_at TEXT
    );
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER NOT NULL REFERENCES users(id),
        recipient_id INTEGER NOT NULL REFERENCES users(id),
        body TEXT NOT NULL,
        created_at TEXT NOT NULL,
        read_at TEXT
    );
    CREATE INDEX IF NOT EXISTS messages_inbox ON messages(recipient_id, read_at);
    CREATE INDEX IF NOT EXISTS messages_pair ON messages(sender_id, recipient_id, id);
    """)
    # First run: create the admin account (default ANDY / Andy123).
    if not db.execute("SELECT 1 FROM users LIMIT 1").fetchone():
        username = os.environ.get("ADMIN_USERNAME", "ANDY").strip().upper()
        password = os.environ.get("ADMIN_PASSWORD", "Andy123")
        db.execute(
            "INSERT OR IGNORE INTO users (username, display_name, password_hash, is_admin, created_at)"
            " VALUES (?, ?, ?, 1, ?)",
            (username, username.title(), generate_password_hash(password), utc_now()))
    db.commit()


# ---------- Session helpers ----------
def _require_login():
    g.user = None
    uid = session.get("uid")
    if uid:
        row = _get_db().execute("SELECT * FROM users WHERE id = ? AND active = 1", (uid,)).fetchone()
        # A password change bumps the hash, which signs out other devices.
        if row and session.get("pw") == row["password_hash"][-16:]:
            g.user = row
        else:
            session.clear()
    if g.user or request.endpoint in PUBLIC_ENDPOINTS:
        return None
    if request.path.startswith("/api/"):
        return jsonify({"error": "Sign in required"}), 401
    return redirect(url_for("accounts.login", next=request.full_path.rstrip("?")))


def admin_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if not g.user or not g.user["is_admin"]:
            return jsonify({"error": "Admin only"}), 403
        return view(*args, **kwargs)
    return wrapper


def user_dict(row, admin_view=False):
    data = {"id": row["id"], "username": row["username"], "display_name": row["display_name"],
            "is_admin": bool(row["is_admin"])}
    if admin_view:
        data.update(active=bool(row["active"]), created_at=row["created_at"],
                    last_login_at=row["last_login_at"])
    return data


def _safe_next(target: str | None) -> str:
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return "/"


def _payload():
    return request.get_json(silent=True) or {}


# ---------- Pages ----------
@bp.route("/login", methods=["GET", "POST"])
def login():
    error = None
    next_url = _safe_next(request.values.get("next"))
    if request.method == "POST":
        username = request.form.get("username", "").strip().upper()
        password = request.form.get("password", "")
        db = _get_db()
        row = db.execute("SELECT * FROM users WHERE username = ? AND active = 1", (username,)).fetchone()
        if row and check_password_hash(row["password_hash"], password):
            session.clear()
            session.permanent = True
            session["uid"] = row["id"]
            session["pw"] = row["password_hash"][-16:]
            db.execute("UPDATE users SET last_login_at = ? WHERE id = ?", (utc_now(), row["id"]))
            db.commit()
            return redirect(next_url)
        time.sleep(0.6)  # slow down password guessing
        error = "Wrong username or password."
    elif g.user:
        return redirect(next_url)
    return render_template("login.html", error=error, next_url=next_url,
                           username=request.form.get("username", ""))


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("accounts.login"))


@bp.route("/messages")
def messages_page():
    return render_template("messages.html")


@bp.route("/account")
def account_page():
    return render_template("account.html")


# ---------- Account API ----------
@bp.route("/api/me")
def me():
    return jsonify(user_dict(g.user))


@bp.route("/api/me/password", methods=["POST"])
def change_password():
    data = _payload()
    if not check_password_hash(g.user["password_hash"], data.get("current", "")):
        return jsonify({"error": "Current password is wrong."}), 400
    new = data.get("new", "")
    if len(new) < MIN_PASSWORD:
        return jsonify({"error": f"New password needs at least {MIN_PASSWORD} characters."}), 400
    new_hash = generate_password_hash(new)
    db = _get_db()
    db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (new_hash, g.user["id"]))
    db.commit()
    session["pw"] = new_hash[-16:]  # keep this device signed in
    return jsonify({"ok": True})


# ---------- Admin: manage users ----------
@bp.route("/api/admin/users", methods=["GET", "POST"])
@admin_required
def admin_users():
    db = _get_db()
    if request.method == "GET":
        rows = db.execute("SELECT * FROM users ORDER BY active DESC, username").fetchall()
        return jsonify([user_dict(r, admin_view=True) for r in rows])

    data = _payload()
    username = str(data.get("username", "")).strip().upper()
    display = str(data.get("display_name", "")).strip()[:60] or username.title()
    password = str(data.get("password", ""))
    if not USERNAME_RE.match(username):
        return jsonify({"error": "Username: 2–32 letters, numbers, dot, dash or underscore."}), 400
    if len(password) < MIN_PASSWORD:
        return jsonify({"error": f"Password needs at least {MIN_PASSWORD} characters."}), 400
    try:
        cur = db.execute(
            "INSERT INTO users (username, display_name, password_hash, is_admin, created_at)"
            " VALUES (?, ?, ?, ?, ?)",
            (username, display, generate_password_hash(password), int(bool(data.get("is_admin"))), utc_now()))
    except sqlite3.IntegrityError:
        return jsonify({"error": f"{username} already exists."}), 409
    db.commit()
    row = db.execute("SELECT * FROM users WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(user_dict(row, admin_view=True)), 201


@bp.route("/api/admin/users/<int:uid>", methods=["PUT", "DELETE"])
@admin_required
def admin_user(uid: int):
    db = _get_db()
    row = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        return jsonify({"error": "Not found"}), 404
    is_self = uid == g.user["id"]

    if request.method == "DELETE":
        if is_self:
            return jsonify({"error": "You can't delete your own account."}), 400
        if db.execute("SELECT 1 FROM messages WHERE sender_id = ? OR recipient_id = ? LIMIT 1",
                      (uid, uid)).fetchone():
            # Keep message history readable; just switch the account off.
            db.execute("UPDATE users SET active = 0 WHERE id = ?", (uid,))
        else:
            db.execute("DELETE FROM users WHERE id = ?", (uid,))
        db.commit()
        return jsonify({"ok": True})

    data = _payload()
    sets, params = [], []
    if "display_name" in data:
        name = str(data["display_name"]).strip()[:60]
        if not name:
            return jsonify({"error": "Display name can't be blank."}), 400
        sets.append("display_name = ?"); params.append(name)
    if data.get("password"):
        if len(data["password"]) < MIN_PASSWORD:
            return jsonify({"error": f"Password needs at least {MIN_PASSWORD} characters."}), 400
        new_hash = generate_password_hash(data["password"])
        sets.append("password_hash = ?"); params.append(new_hash)
        if is_self:
            session["pw"] = new_hash[-16:]
    for flag in ("is_admin", "active"):
        if flag in data:
            if is_self and not data[flag]:
                return jsonify({"error": "You can't remove your own admin access or deactivate yourself."}), 400
            sets.append(f"{flag} = ?"); params.append(int(bool(data[flag])))
    if sets:
        db.execute(f"UPDATE users SET {', '.join(sets)} WHERE id = ?", [*params, uid])
        db.commit()
    row = db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    return jsonify(user_dict(row, admin_view=True))


# ---------- Messaging API ----------
def _message_dict(row):
    return {"id": row["id"], "sender_id": row["sender_id"], "recipient_id": row["recipient_id"],
            "body": row["body"], "created_at": row["created_at"], "read_at": row["read_at"],
            "mine": row["sender_id"] == g.user["id"]}


@bp.route("/api/messages/unread")
def unread_count():
    n = _get_db().execute("SELECT COUNT(*) FROM messages WHERE recipient_id = ? AND read_at IS NULL",
                          (g.user["id"],)).fetchone()[0]
    return jsonify({"unread": n})


@bp.route("/api/contacts")
def contacts():
    """Everyone you can message, with unread counts and the latest message."""
    me_id = g.user["id"]
    rows = _get_db().execute("""
        SELECT u.id, u.username, u.display_name, u.active,
          (SELECT COUNT(*) FROM messages m
             WHERE m.sender_id = u.id AND m.recipient_id = :me AND m.read_at IS NULL) AS unread,
          (SELECT m.id FROM messages m
             WHERE (m.sender_id = u.id AND m.recipient_id = :me) OR (m.sender_id = :me AND m.recipient_id = u.id)
             ORDER BY m.id DESC LIMIT 1) AS last_id
        FROM users u WHERE u.id != :me
    """, {"me": me_id}).fetchall()
    db = _get_db()
    out = []
    for r in rows:
        last = db.execute("SELECT * FROM messages WHERE id = ?", (r["last_id"],)).fetchone() if r["last_id"] else None
        if not r["active"] and not last:
            continue  # hide switched-off accounts you never talked to
        out.append({"id": r["id"], "username": r["username"], "display_name": r["display_name"],
                    "active": bool(r["active"]), "unread": r["unread"],
                    "last": _message_dict(last) if last else None})
    # Recent conversations first, then everyone else alphabetically.
    out.sort(key=lambda c: (c["last"] is None, -(c["last"]["id"] if c["last"] else 0), c["username"]))
    return jsonify(out)


@bp.route("/api/messages/<int:other_id>", methods=["GET"])
def thread(other_id: int):
    db = _get_db()
    me_id = g.user["id"]
    after = request.args.get("after", 0, type=int)
    rows = db.execute("""
        SELECT * FROM (
          SELECT * FROM messages
          WHERE id > ? AND ((sender_id = ? AND recipient_id = ?) OR (sender_id = ? AND recipient_id = ?))
          ORDER BY id DESC LIMIT 200
        ) ORDER BY id
    """, (after, me_id, other_id, other_id, me_id)).fetchall()
    # Opening a conversation marks what they sent you as read.
    db.execute("UPDATE messages SET read_at = ? WHERE sender_id = ? AND recipient_id = ? AND read_at IS NULL",
               (utc_now(), other_id, me_id))
    db.commit()
    return jsonify([_message_dict(r) for r in rows])


@bp.route("/api/messages", methods=["POST"])
def send_message():
    data = _payload()
    body = str(data.get("body", "")).strip()
    if not body:
        return jsonify({"error": "Message is empty."}), 400
    if len(body) > MAX_MESSAGE:
        return jsonify({"error": f"Message is longer than {MAX_MESSAGE} characters."}), 400
    db = _get_db()
    to = db.execute("SELECT * FROM users WHERE id = ? AND active = 1", (data.get("to"),)).fetchone()
    if not to or to["id"] == g.user["id"]:
        return jsonify({"error": "Choose someone to send to."}), 400
    cur = db.execute("INSERT INTO messages (sender_id, recipient_id, body, created_at) VALUES (?, ?, ?, ?)",
                     (g.user["id"], to["id"], body, utc_now()))
    db.commit()
    row = db.execute("SELECT * FROM messages WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(_message_dict(row)), 201
