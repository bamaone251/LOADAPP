from __future__ import annotations
import os, json, sqlite3, datetime, threading, re
from zoneinfo import ZoneInfo
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory, render_template, g
import accounts

# ---------- Config ----------
DB_PATH = os.environ.get(
    "DB_PATH",
    os.path.join(os.path.dirname(__file__), "data", "database.sqlite3")
)


os.makedirs(os.path.dirname(os.path.abspath(DB_PATH)), exist_ok=True)

app = Flask(__name__, root_path=str(Path(__file__).resolve().parent), static_folder="static", template_folder="templates")
app.config["DB_PATH"] = DB_PATH

APP_TIMEZONE = ZoneInfo(os.environ.get("APP_TIMEZONE", "America/Chicago"))
ARCHIVE_PATH = Path(os.environ.get("ARCHIVE_PATH", str(Path(DB_PATH).parent / "archives")))

def local_now():
    return datetime.datetime.now(APP_TIMEZONE)

def map_day(row):
    if row["map_date"]:
        try:
            return datetime.date.fromisoformat(row["map_date"]).isoformat()
        except ValueError:
            pass
    created = datetime.datetime.fromisoformat(row["created_at"].replace("Z", "+00:00"))
    if created.tzinfo is None:
        created = created.replace(tzinfo=datetime.timezone.utc)
    return created.astimezone(APP_TIMEZONE).date().isoformat()

def run_key(row):
    value = str(row["run_number"] or "").strip()
    return (not bool(value), tuple((0, int(p)) if p.isdigit() else (1, p.lower())
                                  for p in re.split(r"(\d+)", value) if p), row["id"])

def archive_maps():
    """Refresh durable snapshots; catch up after downtime and include late edits."""
    now = local_now()
    today = now.date().isoformat()
    with app.app_context():
        db = get_db()
        # Serialize writers across Gunicorn processes with SQLite's write lock.
        db.execute("BEGIN IMMEDIATE")
        try:
            rows = db.execute("SELECT * FROM load_maps").fetchall()
            for row in rows:
                day = map_day(row)
                if day > today or (day == today and (now.hour, now.minute) < (23, 57)):
                    continue
                folder = ARCHIVE_PATH / day
                folder.mkdir(parents=True, exist_ok=True)
                target = folder / (str(row["id"]) + ".json")
                content = json.dumps(row_to_dict(row), indent=2, ensure_ascii=False) + "\n"
                if not target.exists() or target.read_text(encoding="utf-8") != content:
                    temporary = target.with_suffix(".tmp")
                    temporary.write_text(content, encoding="utf-8")
                    os.replace(temporary, target)
            db.commit()
        except Exception:
            db.rollback()
            raise

def archive_worker():
    while True:
        try:
            archive_maps()
        except Exception:
            app.logger.exception("Nightly load map archive failed; will retry")
        threading.Event().wait(15)

# ---------- DB Helpers ----------
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=20)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS load_maps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        title TEXT NOT NULL,
        run_number TEXT,
        trailer_number TEXT,
        door TEXT,
        fuel_level TEXT,
        driver_name TEXT,
        loader_name TEXT,
        loaded_temp TEXT,
        wol_olpn_count INTEGER,
        stops_json TEXT NOT NULL,          -- [{stop:1, loader:"", driver:""}, ...]
        pallets_json TEXT NOT NULL,        -- 30 items: [{pos:1, row:1, col:1, type:"Frozen|Chiller|Ambient|Eggs|Bread|DP|Flower|Equip", store:"", zone:"F|C|A|E|B|DP|FL|..."}]
        bulkheads_json TEXT NOT NULL,      -- list of indices where bulkheads between pallets are placed (0..15 for row splits); simple integer markers
        plbs_loaded INTEGER DEFAULT 0,
        plbs_created INTEGER DEFAULT 0,
        dpr_rebuilds INTEGER DEFAULT 0,
        dpr_rewraps INTEGER DEFAULT 0,
        dpr_consolidations INTEGER DEFAULT 0,
        loader_notes TEXT,
        driver_notes TEXT,
        sanitary_q1 INTEGER DEFAULT NULL,
        sanitary_q2 INTEGER DEFAULT NULL,
        sanitary_q3 INTEGER DEFAULT NULL,
        sanitary_q4 INTEGER DEFAULT NULL,
        totals_json TEXT NOT NULL          -- {"frozen":0,"chiller":0,"ambient":0,"eggs":0,"bread":0,"dp":0,"flower":0,"equip":0,"total":0}
    );
    """)
    columns = {row["name"] for row in db.execute("PRAGMA table_info(load_maps)")}
    for name in ("client_token", "map_date"):
        if name not in columns:
            db.execute(f"ALTER TABLE load_maps ADD COLUMN {name} TEXT")
    if "stores_json" not in columns:
        db.execute("ALTER TABLE load_maps ADD COLUMN stores_json TEXT NOT NULL DEFAULT '[]'")
    db.execute("CREATE UNIQUE INDEX IF NOT EXISTS loadmap_client_token ON load_maps(client_token)")
    db.commit()

# Ensure DB exists on startup
with app.app_context():
    init_db()

# User accounts, sign-in and messaging (see accounts.py)
accounts.init_app(app, get_db)

# ---------- Routes ----------
@app.route("/")
def index():
    return render_template("index.html", app_timezone=str(APP_TIMEZONE))

@app.route("/api/health")
def health():
    return jsonify({"status":"ok","time": datetime.datetime.utcnow().isoformat()+"Z"})

def row_to_dict(row):
    d = dict(row)
    d["map_date"] = map_day(row)
    # Parse JSON fields
    for k in ("stops_json","pallets_json","bulkheads_json","totals_json","stores_json"):
        if d.get(k):
            d[k] = json.loads(d[k])
    return d

@app.route("/api/loadmaps", methods=["GET","POST"])
def loadmaps():
    db = get_db()
    if request.method == "POST":
        payload = request.get_json(force=True)
        now = datetime.datetime.utcnow().isoformat()+"Z"
        token = payload.get("client_token") or None
        if token:
            existing = db.execute("SELECT * FROM load_maps WHERE client_token = ?", (token,)).fetchone()
            if existing:
                # A POST response may have been lost; apply the latest retained
                # draft to the same map rather than creating a duplicate.
                allowed = set(existing.keys()) - {"id", "created_at", "client_token", "updated_at"}
                values = {k: json.dumps(v) if k.endswith("_json") else v
                          for k, v in payload.items() if k in allowed}
                values["updated_at"] = now
                db.execute("UPDATE load_maps SET " + ", ".join(k + " = ?" for k in values) + " WHERE id = ?",
                           [*values.values(), existing["id"]])
                db.commit()
                return jsonify(row_to_dict(db.execute("SELECT * FROM load_maps WHERE id = ?", (existing["id"],)).fetchone())), 200
        db.execute("""
            INSERT OR IGNORE INTO load_maps
            (created_at, updated_at, title, run_number, trailer_number, door, fuel_level,
             driver_name, loader_name, loaded_temp, wol_olpn_count, stops_json, pallets_json,
             bulkheads_json, plbs_loaded, plbs_created, dpr_rebuilds, dpr_rewraps,
             dpr_consolidations, loader_notes, driver_notes, sanitary_q1, sanitary_q2,
             sanitary_q3, sanitary_q4, totals_json, client_token, map_date, stores_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            now, now,
            payload.get("title","New Load Map"),
            payload.get("run_number"), payload.get("trailer_number"), payload.get("door"),
            payload.get("fuel_level"), payload.get("driver_name"), payload.get("loader_name"),
            payload.get("loaded_temp"), payload.get("wol_olpn_count", 0),
            json.dumps(payload.get("stops_json", [])),
            json.dumps(payload.get("pallets_json", [])),
            json.dumps(payload.get("bulkheads_json", [])),
            payload.get("plbs_loaded", 0), payload.get("plbs_created", 0),
            payload.get("dpr_rebuilds", 0), payload.get("dpr_rewraps", 0),
            payload.get("dpr_consolidations", 0),
            payload.get("loader_notes",""), payload.get("driver_notes",""),
            payload.get("sanitary_q1"), payload.get("sanitary_q2"), payload.get("sanitary_q3"),
            payload.get("sanitary_q4"),
            json.dumps(payload.get("totals_json", {})), token, payload.get("map_date"), json.dumps(payload.get("stores_json", []))
        ))
        db.commit()
        if token:
            row = db.execute("SELECT * FROM load_maps WHERE client_token = ?", (token,)).fetchone()
            return jsonify(row_to_dict(row)), 201
        new_id = db.execute("SELECT last_insert_rowid() as id").fetchone()["id"]
        row = db.execute("SELECT * FROM load_maps WHERE id = ?", (new_id,)).fetchone()
        return jsonify(row_to_dict(row)), 201

    # GET (list)
    q = request.args.get("q","").strip()
    sql = "SELECT * FROM load_maps"
    params = []
    if q:
        sql += " WHERE (title LIKE ? OR run_number LIKE ? OR trailer_number LIKE ?)"
        params = [f"%{q}%", f"%{q}%", f"%{q}%"]
    today = local_now().date().isoformat()
    rows = [r for r in db.execute(sql, params).fetchall() if map_day(r) == today]
    return jsonify([row_to_dict(r) for r in sorted(rows, key=run_key)])

@app.route("/archive")
def archive_page():
    return render_template("archive.html")

@app.route("/api/archives")
def archive_days():
    archive_maps()
    return jsonify(sorted((p.name for p in ARCHIVE_PATH.glob("????-??-??") if p.is_dir()), reverse=True))

def archive_folder(day):
    if datetime.date.fromisoformat(day).isoformat() != day:
        raise ValueError("Invalid date")
    return ARCHIVE_PATH / day

@app.route("/api/archives/<day>")
def archived_maps(day):
    try:
        folder = archive_folder(day)
    except ValueError:
        return jsonify({"error": "Invalid date"}), 400
    if not folder.is_dir():
        return jsonify({"error": "Not found"}), 404
    rows = [json.loads(p.read_text(encoding="utf-8")) for p in folder.glob("*.json")]
    return jsonify(sorted(rows, key=run_key))

@app.route("/api/archives/<day>/<int:lid>")
def archived_download(day, lid):
    try:
        folder = archive_folder(day)
    except ValueError:
        return jsonify({"error": "Invalid date"}), 400
    return send_from_directory(str(folder.resolve()), str(lid) + ".json", as_attachment=request.args.get("download") == "1")

@app.route("/api/loadmaps/<int:lid>", methods=["GET","PUT","DELETE"])
def loadmap_detail(lid: int):
    db = get_db()
    if request.method == "GET":
        row = db.execute("SELECT * FROM load_maps WHERE id = ?", (lid,)).fetchone()
        if not row: 
            return jsonify({"error":"Not found"}), 404
        return jsonify(row_to_dict(row))

    if request.method == "PUT":
        payload = request.get_json(force=True)
        now = datetime.datetime.utcnow().isoformat()+"Z"
        # Build dynamic update for JSON fields
        fields = ["map_date","title","run_number","trailer_number","door","fuel_level","driver_name","loader_name",
                  "loaded_temp","wol_olpn_count","plbs_loaded","plbs_created","dpr_rebuilds","dpr_rewraps",
                  "dpr_consolidations","loader_notes","driver_notes","sanitary_q1","sanitary_q2","sanitary_q3","sanitary_q4"]
        json_fields = ["stops_json","pallets_json","bulkheads_json","totals_json","stores_json"]
        sets = ["updated_at = ?"]
        params = [now]
        for f in fields:
            if f in payload:
                sets.append(f"{f} = ?")
                params.append(payload.get(f))
        for jf in json_fields:
            if jf in payload:
                sets.append(f"{jf} = ?")
                params.append(json.dumps(payload.get(jf)))
        params.append(lid)
        db.execute(f"UPDATE load_maps SET {', '.join(sets)} WHERE id = ?", params)
        db.commit()
        row = db.execute("SELECT * FROM load_maps WHERE id = ?", (lid,)).fetchone()
        if not row: 
            return jsonify({"error":"Not found"}), 404
        return jsonify(row_to_dict(row))

    # DELETE
    db.execute("DELETE FROM load_maps WHERE id = ?", (lid,))
    db.commit()
    return jsonify({"ok": True})

@app.route('/service-worker.js')
def service_worker():
    response = send_from_directory(app.static_folder, 'service-worker.js', mimetype='application/javascript')
    response.headers['Cache-Control'] = 'no-cache'
    return response

# Serve favicon if needed
@app.route('/favicon.ico')
def favicon():
    return send_from_directory(app.static_folder, 'favicon.ico', mimetype='image/vnd.microsoft.icon')

threading.Thread(target=archive_worker, daemon=True, name="loadmap-archive").start()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5506"))
    app.run(host="0.0.0.0", port=port, debug=False)
