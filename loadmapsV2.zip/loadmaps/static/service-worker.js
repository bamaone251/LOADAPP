const CACHE = 'loadmap-mobile-v12';
const PAGES = ['/', '/archive', '/messages', '/account'];
const SHELL = [...PAGES, '/static/css/styles.css', '/static/css/accounts.css', '/static/js/main.js',
  '/static/js/archive.js', '/static/js/print.js', '/static/css/print.css', '/static/js/pwa.js',
  '/static/js/session.js', '/static/js/messages.js', '/static/js/account.js', '/static/manifest.webmanifest',
  '/static/icons/icon-192.png', '/static/icons/icon-512.png',
  '/static/icons/icon-maskable-512.png', '/static/icons/apple-touch-icon.png'];

// Signed-out visits redirect to /login; never store that as an app page.
const cacheable = response => response.ok && !response.redirected;

// Wait for open windows to close before activating new app code during an edit.
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => Promise.all(SHELL.map(async path => {
    try {
      const response = await fetch(path, {cache: 'no-store'});
      if (cacheable(response)) await cache.put(path, response);
    } catch { /* fill in on next online visit */ }
  }))));
});
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('loadmap-mobile-') && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== location.origin || url.pathname.startsWith('/api/')) return;
  // Pages keep their query (e.g. /messages?to=3) but share one cached shell.
  if (!SHELL.includes(url.pathname) || (url.search && !PAGES.includes(url.pathname))) return;
  const result = fetch(event.request).then(async response => {
    if (cacheable(response)) {
      const cache = await caches.open(CACHE); await cache.put(url.pathname, response.clone());
    }
    return response;
  }).catch(async () => (await caches.match(url.pathname, {cacheName: CACHE})) ||
    new Response('Offline. Reconnect and reload Load Map.', {
      status: 503, headers: {'Content-Type': 'text/plain; charset=utf-8'}
    }));
  event.respondWith(result);
  event.waitUntil(result.then(() => undefined));
});
