// Shared by every signed-in page: unread-message badge and expired-session notice.
(() => {
  const POLL_MS = 20000;
  const badges = () => document.querySelectorAll('[data-unread-badge]');

  function setUnread(count) {
    badges().forEach(el => {
      el.textContent = count > 99 ? '99+' : String(count);
      el.classList.toggle('hidden', !count);
    });
    const base = document.title.replace(/^\(\d+\+?\) /, '');
    document.title = count ? `(${count}) ${base}` : base;
  }

  function showSignedOut() {
    if (document.querySelector('#sessionBanner')) return;
    const bar = document.createElement('div');
    bar.id = 'sessionBanner';
    bar.className = 'session-banner';
    bar.setAttribute('role', 'alert');
    const link = document.createElement('a');
    link.href = '/login?next=' + encodeURIComponent(location.pathname + location.search);
    link.className = 'btn primary';
    link.textContent = 'Sign in';
    bar.append('You are signed out. Drafts stay saved on this device.', link);
    document.body.prepend(bar);
  }

  // Any API call that comes back 401 means the session ended.
  const nativeFetch = window.fetch.bind(window);
  window.fetch = async (...args) => {
    const res = await nativeFetch(...args);
    if (res.status === 401) showSignedOut();
    return res;
  };

  async function refreshUnread() {
    if (document.hidden || !navigator.onLine) return;
    try {
      const res = await fetch('/api/messages/unread', {cache: 'no-store'});
      if (res.ok) setUnread((await res.json()).unread);
    } catch { /* offline: keep the last count */ }
  }

  window.loadmapSession = {refreshUnread, setUnread};
  refreshUnread();
  setInterval(refreshUnread, POLL_MS);
  document.addEventListener('visibilitychange', refreshUnread);
  window.addEventListener('online', refreshUnread);
})();
