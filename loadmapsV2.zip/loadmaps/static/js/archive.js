const days = document.querySelector('#days');
const maps = document.querySelector('#maps');
const message = document.querySelector('#message');
const search = document.querySelector('#archiveSearch');
let rows = [], requestId = 0;
function render() {
  maps.replaceChildren();
  const q = search.value.trim().toLowerCase();
  const filtered = rows.filter(row => [row.title, row.run_number, row.trailer_number].some(v => String(v || '').toLowerCase().includes(q)));
  message.textContent = filtered.length ? `${filtered.length} load map(s)` : 'No archived maps match this date and search.';
  for (const row of filtered) {
    const item = document.createElement('div'), label = document.createElement('strong');
    item.className = 'list-item';
    label.textContent = `Run ${row.run_number || '—'} · Trailer ${row.trailer_number || '—'} · ${row.title}`;
    const actions = document.createElement('div');
    const open = document.createElement('a'), download = document.createElement('a');
    open.className = 'btn primary'; open.textContent = 'View / Print';
    open.href = `/?archive_date=${encodeURIComponent(days.value)}&archive_id=${row.id}`;
    download.className = 'btn'; download.textContent = 'Download JSON';
    download.href = `/api/archives/${encodeURIComponent(days.value)}/${row.id}?download=1`;
    actions.append(open, download); item.append(label, actions); maps.append(item);
  }
}
async function show() {
  const id = ++requestId;
  rows = []; maps.replaceChildren();
  if (!days.value) { message.textContent = 'No archived load maps yet.'; return; }
  message.textContent = 'Loading maps…';
  try {
    const res = await fetch(`/api/archives/${encodeURIComponent(days.value)}`, {cache:'no-store'});
    if (!res.ok) throw new Error();
    const data = await res.json();
    if (id !== requestId) return;
    rows = data; render();
  } catch { if (id === requestId) message.textContent = 'Could not load the archive. Refresh to retry.'; }
}
days.onchange = show; search.oninput = render;
(async () => {
  try {
    const res = await fetch('/api/archives', {cache:'no-store'});
    if (!res.ok) throw new Error();
    for (const day of await res.json()) {
      const option = document.createElement('option'); option.value = day; option.textContent = day; days.append(option);
    }
    await show();
  } catch { message.textContent = 'Could not load archive dates. Refresh to retry.'; }
})();
