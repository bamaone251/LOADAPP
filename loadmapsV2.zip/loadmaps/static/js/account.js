// Account page: change your password; admins also manage users.
(() => {
  const $ = sel => document.querySelector(sel);
  const myId = Number(document.body.dataset.userId);

  async function api(url, method = 'GET', body) {
    const res = await fetch(url, {
      method,
      headers: body ? {'Content-Type': 'application/json'} : {},
      body: body ? JSON.stringify(body) : undefined,
      cache: 'no-store',
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    return data;
  }

  function say(el, text, ok = true) {
    el.textContent = text;
    el.classList.toggle('is-error', !ok);
  }

  // ----- Change own password -----
  $('#passwordForm').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target, msg = $('#passwordMsg');
    if (f.new.value !== f.confirm.value) return say(msg, 'New passwords do not match.', false);
    try {
      await api('/api/me/password', 'POST', {current: f.current.value, new: f.new.value});
      f.reset();
      say(msg, 'Password updated. Other devices will need to sign in again.');
    } catch (err) { say(msg, err.message, false); }
  });

  // ----- Admin: users -----
  if (document.body.dataset.admin !== '1') return;

  const button = (label, cls, onClick) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = `btn ${cls}`.trim();
    b.textContent = label;
    b.onclick = onClick;
    return b;
  };

  async function loadUsers() {
    const list = $('#userList');
    try {
      const users = await api('/api/admin/users');
      list.replaceChildren(...users.map(userRow));
    } catch (err) {
      list.textContent = err.message;
    }
  }

  function userRow(u) {
    const li = document.createElement('li');
    li.className = `user-row${u.active ? '' : ' is-inactive'}`;

    const info = document.createElement('div');
    const name = document.createElement('strong');
    name.textContent = `${u.username} · ${u.display_name}`;
    const meta = document.createElement('div');
    meta.className = 'hint';
    const tags = [u.is_admin && 'Admin', !u.active && 'Inactive',
      u.last_login_at ? `Last sign-in ${new Date(u.last_login_at).toLocaleString()}` : 'Never signed in'];
    meta.textContent = tags.filter(Boolean).join(' · ');
    info.append(name, meta);

    const actions = document.createElement('div');
    actions.className = 'user-actions';
    const update = async body => {
      try { await api(`/api/admin/users/${u.id}`, 'PUT', body); loadUsers(); }
      catch (err) { alert(err.message); }
    };

    actions.append(
      button('Rename', '', () => {
        const name = prompt(`Display name for ${u.username}:`, u.display_name);
        if (name && name.trim()) update({display_name: name.trim()});
      }),
      button('Reset password', '', () => {
        const pw = prompt(`New password for ${u.username} (at least 6 characters):`);
        if (pw) update({password: pw});
      }),
    );
    if (u.id !== myId) {
      actions.append(
        button(u.is_admin ? 'Remove admin' : 'Make admin', '', () => update({is_admin: !u.is_admin})),
        u.active
          ? button('Delete', 'danger', async () => {
              if (!confirm(`Delete ${u.username}? Users with message history are switched off instead, so their messages stay readable.`)) return;
              try { await api(`/api/admin/users/${u.id}`, 'DELETE'); loadUsers(); }
              catch (err) { alert(err.message); }
            })
          : button('Reactivate', 'primary', () => update({active: true})),
      );
    }
    li.append(info, actions);
    return li;
  }

  $('#addUserForm').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target, msg = $('#addUserMsg');
    try {
      const user = await api('/api/admin/users', 'POST', {
        username: f.username.value,
        display_name: f.display_name.value,
        password: f.password.value,
        is_admin: f.is_admin.checked,
      });
      f.reset();
      say(msg, `Added ${user.username}.`);
      loadUsers();
    } catch (err) { say(msg, err.message, false); }
  });

  loadUsers();
})();
