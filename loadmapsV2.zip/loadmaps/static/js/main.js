// Utility
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

let currentId = null;
let loadingStores = [];
let archiveView = false;
const appTimezone = document.body.dataset.timezone || "America/Chicago";
function todayDate() {
  const parts = new Intl.DateTimeFormat("en-US", {timeZone:appTimezone, year:"numeric", month:"2-digit", day:"2-digit"}).formatToParts(new Date());
  const get = type => parts.find(p=>p.type===type).value;
  return `${get("year")}-${get("month")}-${get("day")}`;
}
let draftKey = null, scanMode = false, lastPallet = {}, currentPosition = null;
let dirty = false, saving = false, queueBusy = false, toastTimer;
const DRAFTS_KEY = "loxload:loadmap:drafts:v1";
function status(text) { $("#syncStatus").textContent = text; }
function readDrafts() { try { return JSON.parse(localStorage.getItem(DRAFTS_KEY) || "{}"); } catch { return {}; } }
function writeDrafts(drafts) { try { localStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts)); return true; } catch { status("Draft storage unavailable—save online"); return false; } }
function persistDraft(queued = false) {
  if (archiveView || !draftKey || $("#editor").classList.contains("hidden")) return;
  const drafts = readDrafts(), old = drafts[draftKey];
  const entry = { id:currentId, body:collectBody(), savedAt:Date.now(), queued:queued || !!old?.queued };
  if (!$("#palletModal").classList.contains("hidden")) entry.pending = { pos:currentPosition, sscc:$("#p_sscc").value, store:$("#p_store").value, type:$("#p_type").value, zone:$("#p_zone").value, bulk:$("#p_bulk").checked };
  drafts[draftKey] = entry;
  dirty = true;
  const stored = writeDrafts(drafts);
  if (stored) status(navigator.onLine ? "Draft saved on this device" : "Offline—draft saved on this device");
  updateRecovery();
  return stored;
}
function updateRecovery() {
  const entries=Object.entries(readDrafts()).sort((a,b)=>b[1].savedAt-a[1].savedAt);
  $("#recoverBtn").classList.toggle("hidden", !entries.length);
  const list=$("#draftsList");list.replaceChildren();
  for(const [key,draft] of entries){
    const row=document.createElement("div"), name=document.createElement("span"), resume=document.createElement("button"), discard=document.createElement("button");
    row.className="list-item";name.textContent=`Local draft · Run ${draft.body.run_number||"—"} · ${draft.queued?"Pending sync":"Not saved to server"}`;
    resume.className=discard.className="btn";resume.textContent="Resume";discard.textContent="Discard";
    resume.onclick=()=>openEditor(draft.id,key);
    discard.onclick=()=>{if(!confirm("Discard this local draft? Any copy already saved to the server stays available."))return;const drafts=readDrafts();delete drafts[key];writeDrafts(drafts);updateRecovery();};
    row.append(name,resume,discard);list.append(row);
  }
}
function toast(text, undo) {
  clearTimeout(toastTimer); $("#toastText").textContent=text; $("#toast").classList.remove("hidden");
  $("#undoBtn").classList.toggle("hidden", !undo);
  $("#undoBtn").onclick=()=>{ undo?.(); $("#toast").classList.add("hidden"); };
  toastTimer=setTimeout(()=>$("#toast").classList.add("hidden"),10000);
}

let pallets = [];       // length=30
let bulkheads = [];     // indices 1..15 per row put marker after position (1..14); we store absolute positions 1..14 per row (A=1..14, B=16..29) for simplicity
let totals = {
  frozen:0, chiller:0, ambient:0, eggs:0, bread:0, dp:0, flower:0, equip:0, total:0
};

// --- SSCC-18 helpers (barcode on pallet labels) ---
function extractSSCC(raw){
  if(!raw) return "";
  // Common scan outputs may include AI like (00) or parentheses, spaces, FNC1, etc.
  const digits = String(raw).replace(/\D/g, "");
  if(!digits) return "";

  // If scan includes AI 00 (often yields 20 digits starting with 00)
  if(digits.length === 20 && digits.startsWith("00")){
    const cand = digits.slice(2, 20);
    if(cand.length === 18) return cand;
  }

  // If exactly 18 digits, that's our SSCC-18
  if(digits.length === 18) return digits;

  // If longer, prefer the last 18 (many scanners append/precede extra info)
  // Reject ambiguous extra digits rather than silently truncating.


  return "";
}

function ssccDisplay(sscc){
  if(!sscc) return "";
  const d = extractSSCC(sscc);
  if(!d) return "";
  return d.slice(-4);
}

async function openScanOverlay(onResult){
  // Camera scan (Chrome/Android): BarcodeDetector API
  if(!("BarcodeDetector" in window)){
    alert("Camera scan not supported on this device/browser. Tap the SSCC field and scan with your scanner (keyboard wedge) or paste the number.");
    return;
  }

  if(!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) { toast("Camera access needs HTTPS. You can still type, paste or use a handheld scanner.");return; }
  let detector;
  try { const supported=await BarcodeDetector.getSupportedFormats();const formats=["code_128","itf","qr_code","data_matrix"].filter(f=>supported.includes(f));if(!formats.length) throw new Error();detector=new BarcodeDetector({formats}); }
  catch { toast("Camera scanning is unavailable here. Use a handheld scanner or enter the oLPN.");return; }

  const overlay = document.createElement("div");
  overlay.className = "scan-overlay";
  overlay.innerHTML = `
    <div class="scan-card">
      <div class="scan-head">
        <div><strong>Scan SSCC-18</strong><div class="scan-sub">Aim at the pallet label barcode.</div></div>
        <button class="btn" data-scan-close>Close</button>
      </div>
      <video playsinline autoplay></video>
      <div class="scan-foot">Tip: if your handheld scanner acts like a keyboard, just tap the field and scan—no camera needed.</div>
    </div>
  `;
  document.body.appendChild(overlay);

  const video = overlay.querySelector("video");
  const closeBtn = overlay.querySelector("[data-scan-close]");
  let stream = null;
  let running = true;

  async function stop(){
    running = false;
    try{ if(stream) stream.getTracks().forEach(t=>t.stop()); }catch(e){}
    overlay.remove();
    if(window.__activeScanStop === stop) window.__activeScanStop = null;
  }
  // allow ESC handler to close and stop camera tracks
  window.__activeScanStop = stop;
  closeBtn.onclick = stop;
  overlay.addEventListener("click", (e)=>{ if(e.target === overlay) stop(); });

  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: "environment" } },
      audio: false
    });
    if(!running){stream.getTracks().forEach(t=>t.stop());return;}
    video.srcObject = stream;
    await video.play();
  } catch (e){
    await stop();
    alert("Camera permission denied or not available.");
    return;
  }

  // Detect loop
  const tick = async ()=>{
    if(!running) return;
    try{
      const barcodes = await detector.detect(video);
      if(barcodes && barcodes.length){
        const raw = barcodes[0].rawValue || "";
        const sscc = extractSSCC(raw);
        if(sscc){
          await stop();
          onResult(sscc);
          return;
        }
      }
    }catch(e){
      // ignore transient detect errors
    }
    setTimeout(tick,150);
  };
  requestAnimationFrame(tick);
}

function defaultPallets(){
  const arr = [];
  for (let r=0; r<2; r++){
    for (let c=0; c<15; c++){
      const pos = r*15 + c + 1;
      arr.push({pos, row:r+1, col:c+1, type:"", store:"", zone:"", sscc:""});
    }
  }
  return arr;
}

function typeToKey(t){
  if(!t) return null;
  const m = {
    "Frozen":"frozen",
    "Chiller":"chiller",
    "Ambient":"ambient",
    "Eggs":"eggs",
    "Bread":"bread",
    "DP":"dp",
    "Flower":"flower",
    "Equip":"equip"
  };
  return m[t] || null;
}

function recomputeTotals(){
  totals = {frozen:0, chiller:0, ambient:0, eggs:0, bread:0, dp:0, flower:0, equip:0, total:0};
  pallets.forEach(p=>{
    if(p && p.type){
      const keys = p.type.split(" + ").map(typeToKey).filter(Boolean);
      keys.forEach(k=>totals[k]++);
      if(keys.length) totals.total++;
    }
  });
  $("#t_frozen").textContent = totals.frozen;
  $("#t_chiller").textContent = totals.chiller;
  $("#t_ambient").textContent = totals.ambient;
  $("#t_eggs").textContent = totals.eggs;
  $("#t_bread").textContent = totals.bread;
  $("#t_dp").textContent = totals.dp;
  $("#t_flower").textContent = totals.flower;
  $("#t_equip").textContent = totals.equip;
  $("#t_total").textContent = totals.total;
}

let listRequest = 0;
async function fetchList(q=""){
  const requestId=++listRequest;
  const res = await fetch(`/api/loadmaps${q?`?q=${encodeURIComponent(q)}`:""}`, {cache:"no-store"});
  if (!res.ok) throw new Error("Could not load maps");
  const data = await res.json();
  if (requestId !== listRequest) return;
  const list = $("#mapsList");
  list.innerHTML = "";
  if (!data.length) list.textContent = q ? "No matching load maps for today." : "No load maps for today yet.";
  data.forEach(item=>{
    const div = document.createElement("div");
    div.className = "list-item";
    const left = document.createElement("div");
    const heading=document.createElement("strong"), stamp=document.createElement("div");
    heading.textContent=`Run ${item.run_number||"—"} · Trailer ${item.trailer_number||"—"} · ${item.title}`;
    stamp.textContent=`Updated ${new Date(item.updated_at).toLocaleString()}`;
    left.append(heading,stamp);
    const loaderName=String(item.loader_name || "").trim();
    if (loaderName) {
      const loader=document.createElement("div");loader.className="run-loader";
      loader.textContent=`Loader: ${loaderName}`;left.append(loader);
    }
    const right = document.createElement("div");
    const openBtn = document.createElement("button");
    openBtn.className = "btn primary";
    openBtn.textContent = "Open";
    openBtn.onclick = ()=> openEditor(item.id);
    right.appendChild(openBtn);
    div.appendChild(left); div.appendChild(right);
    list.appendChild(div);
  });
}

function palletCard(p) {
  const btn=document.createElement("button"); btn.type="button";
  btn.className="pallet"+(typeToKey(p.type.split(" + ")[0])?` type-${p.type.split(" + ")[0]}`:""); btn.dataset.pos=p.pos;
  const labels=[["pos",`Position ${p.pos}`],["store",p.store||"Empty"],["type",p.type||"Tap to add pallet"]];
  if (p.sscc) labels.push(["sscc",`oLPN …${ssccDisplay(p.sscc)}`]);
  if (bulkheads.includes(p.pos)) labels.push(["bulk","Bulkhead after pallet"]);
  labels.forEach(([cls,text])=>{ const el=document.createElement("span");el.className=cls;el.textContent=text;btn.append(el); });
  btn.onclick=()=>editPallet(p.pos); return btn;
}
function renderGrid() {
  const grid=$("#palletGrid");grid.replaceChildren();
  const marker=text=>{const el=document.createElement("div");el.className="row-label";el.textContent=text;grid.append(el);};
  marker("TRAILER FRONT / NOSE");
  // Preserve existing numbered slots and their left/right pairing.
  for (let i=1;i<=30;i++) grid.append(palletCard(pallets[i-1]));
  marker("TRAILER DOORS / REAR");
}
function normalizeStores(values) {
  return [...new Set(values.map(value=>String(value).trim().toUpperCase()).filter(Boolean))].slice(0,4);
}
function renderLoadingStores() {
  $("#loadingStoresSummary").textContent=loadingStores.length ? `Loading: ${loadingStores.join(" · ")}` : "Loading stores not set";
  $("#editStoresBtn").textContent=loadingStores.length ? "Edit stores" : "Set stores";
}
function showStoresPrompt() {
  if(archiveView) return;
  const dialog=$("#storesDialog");
  $$("#storesForm input").forEach((input,i)=>input.value=loadingStores[i] || "");
  $("#storesError").textContent="";
  dialog.showModal();
}
function renderStoreButtons() {
  const group=$("#p_store_buttons");group.replaceChildren();
  for(const store of loadingStores) {
    const button=document.createElement("button");button.type="button";button.className="btn store-choice";
    button.textContent=store;button.setAttribute("aria-pressed",String($("#p_store").value.trim().toUpperCase()===store));
    button.onclick=()=>{ $("#p_store").value=store;renderStoreButtons();$("#p_continue").click(); };
    group.append(button);
  }
}
$("#editStoresBtn").onclick=showStoresPrompt;
$("#storesCancel").onclick=()=>$("#storesDialog").close();
$("#storesForm").onsubmit=event=>{
  event.preventDefault();
  const stores=normalizeStores($$("#storesForm input").map(input=>input.value));
  if(!stores.length){$("#storesError").textContent="Enter at least one store.";return;}
  loadingStores=stores;renderLoadingStores();persistDraft();$("#storesDialog").close();
};
$("#p_store").addEventListener("input",renderStoreButtons);
function applyBody(item) {
  loadingStores=normalizeStores(Array.isArray(item.stores_json) ? item.stores_json : []);
  renderLoadingStores();
  ["title","run_number","trailer_number","door","fuel_level","loaded_temp","loader_name","driver_name","wol_olpn_count","plbs_loaded","plbs_created","dpr_rebuilds","dpr_rewraps","dpr_consolidations","loader_notes","driver_notes"].forEach(key=>$("#"+key).value=item[key]??"");
  $("#date_field").value=item.map_date||"";
  for(let i=1;i<=4;i++) $("#san_q"+i).value=item["sanitary_q"+i]===1?"Yes":item["sanitary_q"+i]===0?"No":"";
  const defaults=defaultPallets();pallets=defaults.map((p,i)=>({...p,...(item.pallets_json||[])[i],pos:p.pos}));
  bulkheads=item.bulkheads_json||[];renderGrid();recomputeTotals();
}
function setArchiveView(active) {
  archiveView=active;
  $(".bulkhead-help").classList.toggle("hidden",active);
  $$("#editor input, #editor select, #editor textarea, #palletGrid button").forEach(el=>el.disabled=active);
  ["#saveBtn", "#deleteBtn", "#scanModeBtn", "#editStoresBtn"].forEach(sel=>$(sel).classList.toggle("hidden",active));
}
async function openArchived(day,id) {
  try {
    const res=await fetch(`/api/archives/${encodeURIComponent(day)}/${encodeURIComponent(id)}`);
    if(!res.ok) throw new Error();
    const item=await res.json();
    draftKey=null;currentId=null;dirty=false;
    $("#searchControls").classList.add("hidden");$("#listView").classList.add("hidden");
    $("#editor").classList.remove("hidden");
    $("#editorHeading").textContent=`Archived load map · ${day}`;
    applyBody(item);setArchiveView(true);status("Archive · read only");
  } catch { toast("Could not open archived map. Check your connection."); }
}
async function openEditor(id, recoveryKey=null){
  setArchiveView(false);
  if (draftKey && !$("#editor").classList.contains("hidden") && dirty) persistDraft();
  closePallet();
  scanMode=false; $("#scanModeBtn").setAttribute("aria-pressed","false"); $("#scanHint").classList.add("hidden");
  lastPallet={}; dirty=false;
  const cached=readDrafts();
  draftKey=recoveryKey || (id ? `map-${id}` : (crypto.randomUUID?.() || Array.from(crypto.getRandomValues(new Uint8Array(16)), n=>n.toString(16).padStart(2,"0")).join("")));
  $("#searchControls").classList.add("hidden");
  $("#editorHeading").textContent=id?`Load map #${id}`:"New load map";
  currentId = id || null;
  $("#listView").classList.add("hidden");
  $("#editor").classList.remove("hidden");
  if (cached[draftKey]) {
    const draft=cached[draftKey];currentId=draft.id;applyBody(draft.body);dirty=true;
    status(draft.queued?"Changes pending sync":"Recovered local draft");
    if(draft.pending) { const d=draft.pending;editPallet(d.pos); $("#p_sscc").value=d.sscc;$("#p_store").value=d.store;$("#p_type").value=d.type;$("#p_zone").value=d.zone;$("#p_bulk").checked=d.bulk; }
    return;
  }
  if(!id){
    // new
    loadingStores=[];renderLoadingStores();
    $("#title").value =  new Date().toLocaleString();
    $("#run_number").value = ""; 
    $("#trailer_number").value = "";
    $("#door").value = "";
    $("#fuel_level").value = "";
    $("#loaded_temp").value = "";
    $("#loader_name").value = document.body.dataset.userName || "";
    $("#driver_name").value = "";
    $("#wol_olpn_count").value = 0;
    $("#date_field").value = todayDate();
    $(".stop-row .stop-loader");
    $$(".stop-row .stop-loader").forEach(el=>el.value="");
    $$(".stop-row .stop-driver").forEach(el=>el.value="");
    $("#plbs_loaded").value = 0;
    $("#plbs_created").value = 0;
    $("#dpr_rebuilds").value = 0;
    $("#dpr_rewraps").value = 0;
    $("#dpr_consolidations").value = 0;
    $("#loader_notes").value = "";
    $("#driver_notes").value = "";
    $("#san_q1").value = "";
    $("#san_q2").value = "";
    $("#san_q3").value = "";
    $("#san_q4").value = "";
    pallets = defaultPallets();
    bulkheads = [];
    renderGrid();
    recomputeTotals();
    persistDraft();
    showStoresPrompt();
    return;
  }
  try { const res=await fetch(`/api/loadmaps/${id}`);if(!res.ok) throw new Error();applyBody(await res.json());status("Saved"); }
  catch { toast("Cannot open map. Check your connection.");closeEditor(); }
}

function closeEditor(){
  setArchiveView(false);
  if (dirty) persistDraft();
  closePallet();
  draftKey=null;dirty=false;
  $("#searchControls").classList.remove("hidden");
  $("#editor").classList.add("hidden");
  $("#listView").classList.remove("hidden");
  currentId = null;
}

function collectStops(){
  return $$(".stop-row").map((row, idx)=> ({
    stop: idx+1,
    loader: row.querySelector(".stop-loader").value.trim(),
    driver: row.querySelector(".stop-driver").value.trim(),
  }));
}

function ynToNum(v){
  if(v==="Yes") return 1;
  if(v==="No") return 0;
  return null;
}

function collectBody(){
  const body = {
    client_token:draftKey,
    map_date:$("#date_field").value,
    title: $("#title").value.trim() || "LOAD MAPS",
    run_number: $("#run_number").value.trim(),
    trailer_number: $("#trailer_number").value.trim(),
    door: $("#door").value.trim(),
    fuel_level: $("#fuel_level").value.trim(),
    loaded_temp: $("#loaded_temp").value.trim(),
    loader_name: $("#loader_name").value.trim(),
    driver_name: $("#driver_name").value.trim(),
    wol_olpn_count: Number($("#wol_olpn_count").value || 0),
    stores_json: [...loadingStores],
    stops_json: collectStops(),
    pallets_json: pallets,
    bulkheads_json: bulkheads,
    plbs_loaded: Number($("#plbs_loaded").value || 0),
    plbs_created: Number($("#plbs_created").value || 0),
    dpr_rebuilds: Number($("#dpr_rebuilds").value || 0),
    dpr_rewraps: Number($("#dpr_rewraps").value || 0),
    dpr_consolidations: Number($("#dpr_consolidations").value || 0),
    loader_notes: $("#loader_notes").value,
    driver_notes: $("#driver_notes").value,
    sanitary_q1: $("#san_q1").value==="Yes"?1:($("#san_q1").value==="No"?0:null),
    sanitary_q2: $("#san_q2").value==="Yes"?1:($("#san_q2").value==="No"?0:null),
    sanitary_q3: $("#san_q3").value==="Yes"?1:($("#san_q3").value==="No"?0:null),
    sanitary_q4: $("#san_q4").value==="Yes"?1:($("#san_q4").value==="No"?0:null),
    totals_json: totals
  };
  return body;
}
async function save(){
  if(saving || !draftKey) return;
  const stored=persistDraft(true);
  if(!stored){
    if(!navigator.onLine){status("Offline—device storage unavailable; keep this page open");toast("Cannot save an offline draft. Keep this page open until connected.");return;}
    const key=draftKey, body=JSON.stringify(collectBody());saving=true;$("#saveBtn").disabled=true;status("Saving…");
    try {
      const res=await fetch(currentId?`/api/loadmaps/${currentId}`:"/api/loadmaps",{method:currentId?"PUT":"POST",headers:{"Content-Type":"application/json"},body});
      if(!res.ok)throw new Error();const item=await res.json();
      if(key===draftKey){currentId=item.id;dirty=JSON.stringify(collectBody())!==body;status(dirty?"New edits not yet saved":"Saved—local draft storage unavailable");}
    }catch{status("Save failed—keep this page open");toast("Server save failed and device storage is unavailable. Keep this page open and retry.");}
    finally{saving=false;$("#saveBtn").disabled=false;}
    return;
  }
  if(!navigator.onLine){status("Offline—changes pending sync");return;}
  await syncDrafts();
}
async function syncDrafts(){
  if(queueBusy || !navigator.onLine) return;
  queueBusy=true;saving=true;$("#saveBtn").disabled=true;
  try {
    for (const [key,draft] of Object.entries(readDrafts())) {
      if(!draft.queued) continue;
      if(key===draftKey) status("Saving…");
      try {
        const res=await fetch(draft.id?`/api/loadmaps/${draft.id}`:"/api/loadmaps",{method:draft.id?"PUT":"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(draft.body)});
        if(!res.ok) throw new Error(`Server returned ${res.status}`);
        const result=await res.json(), latest=readDrafts(), entry=latest[key];
        if(key===draftKey) currentId=result.id;
        if(entry && entry.savedAt===draft.savedAt && !entry.pending) {
          delete latest[key];if(key===draftKey){dirty=false;status("Saved");}
        } else if(entry) {
          entry.id=result.id;
          // Retain edits made during the request; save again explicitly.
          entry.queued=false;
          if(key===draftKey) status("Newer draft saved on this device");
        }
        writeDrafts(latest);
      } catch(error) { if(key===draftKey) status("Save failed—changes pending sync");toast("Save could not finish. Your draft is kept on this device. Tap Save map to retry.");break; }
    }
  } finally { queueBusy=false;saving=false;$("#saveBtn").disabled=false;updateRecovery(); }
}

async function del(){
  if(saving) return;
  if(!confirm("Delete this load map? Saved maps are permanently removed. Pallets can be cleared individually with Undo.")) return;
  if(currentId) {
    try { const res=await fetch(`/api/loadmaps/${currentId}`,{method:"DELETE"});if(!res.ok) throw new Error(); }
    catch { toast("Delete failed. Check your connection.");return; }
  }
  const drafts=readDrafts();delete drafts[draftKey];writeDrafts(drafts);dirty=false;closeEditor();updateRecovery();safeFetchList();
}
function closePallet(){
  $("#palletModal").classList.add("hidden");document.body.style.overflow="";
  if(typeof window.__activeScanStop==="function") window.__activeScanStop();
  if(currentPosition) document.querySelector(`[data-pos="${currentPosition}"]`)?.focus({preventScroll:true});
}
const palletZones = [
  ["Frozen","Freezer","F","#9cdbe2"],["Chiller","Chiller","C","#b6d995"],
  ["Ambient","Ambient","A","#e4c6a0"],["Eggs","Eggs","E","#e0b3b8"],
  ["Bread","Bread","B","#dfdba0"],["DP","Dry produce","DP","#bfbae6"],
  ["Flower","Flowers","FL","#dfb6df"],["Equip","Equipment","M","#b6c6d3"]
];
function selectedPalletZones(){return $("#p_type").value.split(" + ").filter(Boolean);}
function renderZoneButtons(){
  const selected=selectedPalletZones(),group=$("#p_zone_buttons");group.replaceChildren();
  for(const [value,label,letter,color] of palletZones){
    const button=document.createElement("button");button.type="button";button.className="zone-choice";
    button.style.background=color;button.setAttribute("aria-pressed",String(selected.includes(value)));
    button.textContent=`${selected.includes(value)?"◉":"○"} ${label}`;
    button.onclick=()=>{
      const zones=selectedPalletZones(),index=zones.indexOf(value);
      if(index>=0)zones.splice(index,1);
      else if(zones.length<2)zones.push(value);
      else {$("#p_error").textContent="Choose up to two zones. Remove a selected zone first.";return;}
      $("#p_type").value=zones.join(" + ");
      $("#p_zone").value=zones.map(v=>palletZones.find(z=>z[0]===v)?.[2]||"").join(" + ");
      $("#p_error").textContent="";renderZoneButtons();persistDraft();
    };
    group.append(button);
  }
  $("#p_zone_summary").textContent=selected.length?selected.map(v=>palletZones.find(z=>z[0]===v)?.[1]||v).join(" + "):"No zones selected yet";
  $("#p_save").disabled=$("#p_save_next").disabled=!$("#p_store_step").classList.contains("hidden")||selected.length===0;
}
function setPalletStep(step){
  $("#p_store_step").classList.toggle("hidden",step!==1);
  $("#p_zone_step").classList.toggle("hidden",step!==2);
  $("#p_step").textContent=`STEP ${step} OF 2`;
  $("#p_selected_store").textContent=$("#p_store").value.trim().toUpperCase();
  renderZoneButtons();
  $("#p_error").textContent="";
}
$("#p_continue").onclick=()=>{
  if(!$("#p_store").value.trim()){$("#p_error").textContent="Choose or enter a store.";$("#p_store").focus();return;}
  $("#p_store").value=$("#p_store").value.trim().toUpperCase();
  setPalletStep(2);$("#p_zone_buttons button").focus();persistDraft();
};
$("#p_back").onclick=()=>{setPalletStep(1);$("#p_continue").focus();};
function editPallet(pos){
  currentPosition=pos;const p=pallets[pos-1], empty=!p.type&&!p.store&&!p.sscc;
  $("#modalPos").textContent=`#${pos}`;$("#p_error").textContent="";
  $("#p_sscc").value=p.sscc||"";
  $("#p_store").value=p.store||(scanMode&&empty?lastPallet.store:"")||"";
  renderStoreButtons();
  $("#p_type").value=p.type||(scanMode&&empty?lastPallet.type:"")||"";
  $("#p_zone").value=p.zone||(scanMode&&empty?lastPallet.zone:"")||"";
  $("#p_bulk").checked=bulkheads.includes(pos);
  $("#palletModal").classList.remove("hidden");document.body.style.overflow="hidden";
  setPalletStep(1);
  ($("#p_store_buttons button") || $("#p_store")).focus();
  $("#p_save").onclick=()=>commitPallet(false);
  $("#p_save_next").onclick=()=>commitPallet(true);
  $("#p_clear").onclick=()=>{
    const before=structuredClone(pallets), marks=[...bulkheads];
    pallets[pos-1]={...p,store:"",type:"",zone:"",sscc:""};bulkheads=bulkheads.filter(n=>n!==pos);
    closePallet();renderGrid();recomputeTotals();persistDraft();
    toast(`Position ${pos} cleared`,()=>{pallets=before;bulkheads=marks;renderGrid();recomputeTotals();persistDraft();});
  };
  $("#p_close").onclick=()=>{closePallet();persistDraft();};
}
function commitPallet(next){
  const pos=currentPosition;
  if(!$("#p_store").value.trim()){setPalletStep(1);$("#p_error").textContent="Choose or enter a store.";$("#p_store").focus();return;}
  if(!$("#p_type").value){setPalletStep(2);$("#p_error").textContent="Choose a pallet zone.";$("#p_zone_buttons button").focus();return;}
  const sscc=pallets[pos-1].sscc||"";
  const p=pallets[pos-1];Object.assign(p,{store:$("#p_store").value.trim().toUpperCase(),type:$("#p_type").value,zone:$("#p_zone").value,sscc});
  bulkheads=bulkheads.filter(n=>n!==pos);if($("#p_bulk").checked) bulkheads.push(pos);
  lastPallet={store:p.store,type:p.type,zone:p.zone};
  closePallet();renderGrid();recomputeTotals();persistDraft();
  if(next){const candidates=[...pallets.slice(pos),...pallets.slice(0,pos-1)];const empty=candidates.find(p=>!p.type&&!p.store&&!p.sscc);if(empty)editPallet(empty.pos);else toast("All positions are filled. Review the map, then save.");}
}
// Close modals with ESC
document.addEventListener("keydown", (e)=>{
  if(e.key === "Tab" && !$("#palletModal").classList.contains("hidden") && !document.querySelector(".scan-overlay")) {
    const focusable=$$("#palletModal button, #palletModal input, #palletModal select, #palletModal summary").filter(el=>el.getClientRects().length);
    const first=focusable[0],last=focusable.at(-1);
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
    else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  }
  if(e.key === "Escape"){
    closePallet();
    if(draftKey) persistDraft();
    if(typeof window.__activeScanStop === "function") window.__activeScanStop();
  }
});

$("#newMapBtn").onclick = ()=> openEditor(null);
$("#cancelBtn").onclick = ()=> {closeEditor();safeFetchList();};
$("#saveBtn").onclick = ()=> save();
$("#deleteBtn").onclick = ()=> del();
$("#searchBtn").onclick = ()=> safeFetchList($("#search").value.trim());
function printLoadMap(){
  if($("#editor").classList.contains("hidden")){toast("Open a load map before printing.");return;}
  window.print();
}

$("#printBtn").onclick = ()=> printLoadMap();

// Preserve text as typed, including unfinished pallet edits.
$("#editor").addEventListener("input",()=>persistDraft());
$("#editor").addEventListener("change",()=>persistDraft());
$("#palletModal").addEventListener("input",()=>persistDraft());
$("#palletModal").addEventListener("change",()=>persistDraft());
$("#scanModeBtn").onclick=()=>{scanMode=!scanMode;$("#scanModeBtn").setAttribute("aria-pressed",String(scanMode));$("#scanHint").classList.toggle("hidden",!scanMode);if(scanMode){const p=pallets.find(p=>!p.type&&!p.store&&!p.sscc);if(p) editPallet(p.pos);}};
$("#recoverBtn").onclick=()=>{const entries=Object.entries(readDrafts()).sort((a,b)=>b[1].savedAt-a[1].savedAt);if(entries.length)openEditor(entries[0][1].id,entries[0][0]);};
$("#search").addEventListener("keydown",e=>{if(e.key==="Enter")safeFetchList($("#search").value.trim());});
async function safeFetchList(q=""){try{await fetchList(q);}catch{toast("Could not load saved maps. Local drafts are still available.");}}
window.addEventListener("offline",()=>status("Offline—drafts stay on this device"));
window.addEventListener("online",()=>{status("Online");syncDrafts();safeFetchList();});
window.addEventListener("pagehide",()=>{if(dirty)persistDraft();window.__activeScanStop?.();});
window.addEventListener("beforeunload",e=>{if(dirty){e.preventDefault();e.returnValue="";}});
// Keep the pallet action bar above the mobile keyboard where VisualViewport is available.
function sizeModal(){const v=window.visualViewport;if(!v)return;const modal=$("#palletModal");modal.style.height=v.height+"px";modal.style.top=v.offsetTop+"px";modal.style.bottom="auto";}
window.visualViewport?.addEventListener("resize",sizeModal);window.visualViewport?.addEventListener("scroll",sizeModal);sizeModal();
window.addEventListener("beforeprint",()=>{
  if(!$("#editor").classList.contains("hidden")) window.renderLoadMapPrint(collectBody());
});
window.addEventListener("afterprint",()=>document.querySelector("#loadMapPrint")?.remove());
updateRecovery();safeFetchList();syncDrafts();
const archiveParams=new URLSearchParams(location.search);
if(archiveParams.has("archive_date") && archiveParams.has("archive_id")) openArchived(archiveParams.get("archive_date"),archiveParams.get("archive_id"));
// Refresh the home list across midnight, including tabs returning from sleep.
let listedDay=todayDate();
function refreshDay(){const day=todayDate();if(day!==listedDay){listedDay=day;safeFetchList($("#search").value.trim());}}
setInterval(refreshDay,15000);
document.addEventListener("visibilitychange",()=>{if(!document.hidden)refreshDay();});



