(() => {
  const el = (tag, cls, text) => {
    const node=document.createElement(tag); if(cls) node.className=cls;
    if(text !== undefined) node.textContent=text; return node;
  };
  const value = v => v === null || v === undefined || String(v).trim()==='' ? '—' : String(v);
  function header(map, page) {
    const head=el('header','paper-header'), left=el('div');
    left.append(el('div','paper-eyebrow','LOXLOAD / LOAD OPERATIONS'),el('h1','',`Run # ${value(map.run_number)}`),
      el('p','',`Door # ${value(map.door)}   |   Trailer # ${value(map.trailer_number)}`),
      el('p','',`Loader: ${value(map.loader_name)}   |   Date: ${value(map.map_date)}`));
    const right=el('div','paper-stores');right.append(el('div','paper-eyebrow','STORES BEING LOADED'));
    const stores=map.stores_json?.length ? map.stores_json : [...new Set((map.pallets_json||[]).map(p=>p.store).filter(Boolean))];
    right.append(el('strong','',stores.join(' · ') || '—'),el('p','',`${page} / 2`));
    head.append(left,right);return head;
  }
  function panel(title) { const node=el('section','paper-panel');node.append(el('h2','',title));return node; }
  function facts(title, pairs) {
    const section=panel(title), list=el('dl','paper-facts');
    for(const [label,content] of pairs) {list.append(el('dt','',label),el('dd','',value(content)));}
    section.append(list);return section;
  }
  window.renderLoadMapPrint = map => {
    document.querySelector('#loadMapPrint')?.remove();
    const root=el('div');root.id='loadMapPrint';
    function sheet(page) {
      const sheet=el('section','paper-sheet'), content=el('div','paper-content');
      content.append(header(map,page));sheet.append(content,el('footer','paper-footer',`LOAD MAP · RUN ${value(map.run_number)} · ${value(map.map_date)}                                      ${page} / 2`));
      root.append(sheet);return content;
    }
    const page1=sheet(1);
    page1.append(el('h2','paper-section-title','TRAILER LOAD MAP'));
    page1.append(el('div','paper-direction','TRAILER FRONT / NOSE'));
    const grid=el('div','paper-pallet-grid');
    const marks=new Set(map.bulkheads_json||[]);
    for(let i=0;i<30;i++) {
      const p=(map.pallets_json||[])[i]||{}, card=el('div','paper-pallet');
      const palette={Frozen:'frozen',Chiller:'chiller',Ambient:'ambient',Eggs:'eggs',Bread:'bread',DP:'dp',Flower:'flower',Equip:'equip'};
      const firstType=(p.type||" ").split(" + ")[0];
      if(palette[firstType])card.classList.add('paper-'+palette[firstType]);
      card.append(el('span','paper-position',String(i+1).padStart(2,'0')),
        el('strong','paper-store',p.store || 'Empty'),el('span','paper-type',p.type || '—'),
        el('span','paper-olpn',`oLPN: ${value(p.sscc)}`));
      if(marks.has(i+1)) {card.classList.add('paper-bulkhead');card.append(el('span','paper-bulk-label','BULKHEAD'));}
      grid.append(card);
    }
    page1.append(grid,el('div','paper-direction','TRAILER DOORS / REAR'));
    const counts=map.totals_json||{};
    page1.append(el('p','paper-total',`Total pallets: ${counts.total || 0} / 30`));
    const page2=sheet(2);
    page2.append(el('h2','paper-section-title','LOAD DETAILS & CHECKS'));
    const columns=el('div','paper-columns');
    columns.append(facts('Total Truck Pallet Count Summary',[
      ['Frozen',counts.frozen||0],['Chiller',counts.chiller||0],['Ambient',counts.ambient||0],['Eggs',counts.eggs||0],
      ['Bread',counts.bread||0],['Dry produce',counts.dp||0],['Flower',counts.flower||0],['Equipment',counts.equip||0],['Total pallets',`${counts.total||0} / 30`]
    ]),facts('Load activity',[
      ['# oLPNs',map.wol_olpn_count||0],['PLBs Created',map.plbs_created||0],['PLBs Loaded',map.plbs_loaded||0],
      ['Rewraps',map.dpr_rewraps||0],['Rebuilds',map.dpr_rebuilds||0],['Consolidations',map.dpr_consolidations||0]
    ]));
    page2.append(columns);
    const sanitary=panel('Sanitary Transport Requirements');
    ['Trailer temperature set and cooling correctly','Trailer condition OK','Pallets stable and items secured','Bulkheads in place and airflow OK'].forEach((question,i)=>{
      const answer=map[`sanitary_q${i+1}`], row=el('div','paper-check');
      row.append(el('span','',`${i+1}. ${question}`),el('strong','',answer===1?'Yes':answer===0?'No':'Not recorded'));sanitary.append(row);
    });page2.append(sanitary);
    page2.append(facts('Additional details',[
      ['Driver',map.driver_name],['Fuel level',map.fuel_level],['Loaded temperature',map.loaded_temp],['Title',map.title]
    ]));
    for(const [title,text] of [['Loader notes',map.loader_notes],['Driver notes',map.driver_notes]]) {
      const notes=panel(title);notes.append(el('p','paper-notes',text || `No ${title.toLowerCase()}.`));page2.append(notes);
    }
    document.body.append(root);
    // Fixed Letter sheets, with dynamic scaling for unusually long notes or values.
    // Measurements use the print-specific DOM, so phone screen width has no effect.
    for(const content of root.querySelectorAll('.paper-content')) {
      const available=content.parentElement.clientHeight-30;
      const factor=Math.min(1,available/content.scrollHeight,content.clientWidth/content.scrollWidth);
      content.style.transform=`scale(${factor})`;
    }
  };
})();
