// Messages page: people list on one side, conversation on the other.
(() => {
  const $ = sel => document.querySelector(sel);
  const THREAD_POLL_MS = 5000;
  const CONTACT_POLL_MS = 15000;

  let contacts = [];
  let activeId = Number(new URLSearchParams(location.search).get('to')) || null;
  let lastMessageId = 0;
  let threadBusy = false;

  const fmtTime = iso => {
    const d = new Date(iso);
    const sameDay = d.toDateString() === new Date().toDateString();
    return d.toLocaleString([], sameDay
      ? {hour: 'numeric', minute: '2-digit'}
      : {month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'});
  };

  // ----- People list -----
  async function loadContacts() {
    try {
      const res = await fetch('/api/contacts', {cache: 'no-store'});
      if (!res.ok) return;
      contacts = await res.json();
      renderContacts();
    } catch { /* offline */ }
  }

  function renderContacts() {
    const q = $('#contactSearch').value.trim().toLowerCase();
    const list = $('#contactList');
    list.replaceChildren();
    const shown = contacts.filter(c => !q || `${c.username} ${c.display_name}`.toLowerCase().includes(q));
    if (!shown.length) {
      const li = document.createElement('li');
      li.className = 'hint';
      li.textContent = contacts.length ? 'No one matches.' : 'No other users yet. An admin can add them on the Account page.';
      list.append(li);
      return;
    }
    for (const c of shown) {
      const li = document.createElement('li');
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'contact';
      btn.setAttribute('aria-current', String(c.id === activeId));
      const name = document.createElement('span');
      name.className = 'contact-name';
      name.textContent = c.display_name + (c.active ? '' : ' (inactive)');
      const preview = document.createElement('span');
      preview.className = 'contact-preview';
      preview.textContent = c.last ? `${c.last.mine ? 'You: ' : ''}${c.last.body}` : c.username;
      btn.append(name, preview);
      if (c.unread) {
        const badge = document.createElement('span');
        badge.className = 'badge';
        badge.textContent = c.unread;
        btn.append(badge);
      }
      btn.onclick = () => openThread(c.id);
      li.append(btn);
      list.append(li);
    }
  }

  // ----- Conversation -----
  function openThread(id) {
    activeId = id;
    lastMessageId = 0;
    history.replaceState(null, '', `/messages?to=${id}`);
    const c = contacts.find(x => x.id === id);
    $('#threadTitle').textContent = c ? c.display_name : 'Conversation';
    $('#threadBody').replaceChildren();
    $('#sendForm').classList.toggle('hidden', !c || !c.active);
    $('#sendError').textContent = c && !c.active ? 'This account is inactive. You can read past messages only.' : '';
    $('#chat').classList.add('show-thread');
    renderContacts();
    loadThread();
    if (c?.active) $('#messageInput').focus();
  }

  async function loadThread() {
    if (!activeId || threadBusy) return;
    threadBusy = true;
    const forId = activeId;
    try {
      const res = await fetch(`/api/messages/${forId}?after=${lastMessageId}`, {cache: 'no-store'});
      if (!res.ok || forId !== activeId) return;
      const rows = await res.json();
      if (rows.length) {
        appendMessages(rows);
        window.loadmapSession?.refreshUnread();
        const c = contacts.find(x => x.id === forId);
        if (c?.unread) { c.unread = 0; renderContacts(); }
      } else if (!lastMessageId) {
        const p = document.createElement('p');
        p.className = 'hint empty-thread';
        p.textContent = 'No messages yet. Say hello.';
        $('#threadBody').replaceChildren(p);
      }
    } catch { /* offline */ } finally { threadBusy = false; }
  }

  function appendMessages(rows) {
    const body = $('#threadBody');
    body.querySelector('.empty-thread')?.remove();
    const nearBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 80;
    for (const m of rows) {
      if (m.id <= lastMessageId) continue;
      lastMessageId = m.id;
      const bubble = document.createElement('div');
      bubble.className = `bubble ${m.mine ? 'mine' : 'theirs'}`;
      const text = document.createElement('div');
      text.className = 'bubble-text';
      text.textContent = m.body;
      const meta = document.createElement('div');
      meta.className = 'bubble-meta';
      meta.textContent = fmtTime(m.created_at);
      bubble.append(text, meta);
      body.append(bubble);
    }
    if (nearBottom || rows.some(m => m.mine)) body.scrollTop = body.scrollHeight;
  }

  async function send(e) {
    e.preventDefault();
    const input = $('#messageInput');
    const text = input.value.trim();
    if (!text || !activeId) return;
    const btn = $('#sendForm button');
    btn.disabled = true;
    $('#sendError').textContent = '';
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({to: activeId, body: text}),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Message not sent.');
      input.value = '';
      await loadThread();
      loadContacts();
    } catch (err) {
      $('#sendError').textContent = navigator.onLine ? err.message : 'You are offline. Message not sent.';
    } finally {
      btn.disabled = false;
      input.focus();
    }
  }

  // ----- Wire up -----
  $('#sendForm').addEventListener('submit', send);
  $('#messageInput').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('#sendForm').requestSubmit(); }
  });
  $('#contactSearch').addEventListener('input', renderContacts);
  $('#backBtn').onclick = () => { $('#chat').classList.remove('show-thread'); loadContacts(); };

  setInterval(() => { if (!document.hidden) loadThread(); }, THREAD_POLL_MS);
  setInterval(() => { if (!document.hidden) loadContacts(); }, CONTACT_POLL_MS);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { loadThread(); loadContacts(); } });

  loadContacts().then(() => { if (activeId && contacts.some(c => c.id === activeId)) openThread(activeId); });
})();
