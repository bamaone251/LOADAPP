(() => {
  const button = document.querySelector('#installAppBtn');
  let prompt;
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); prompt = event; button?.classList.remove('hidden');
  });
  button?.addEventListener('click', async () => {
    if (!prompt) return;
    button.disabled = true;
    try { await prompt.prompt(); await prompt.userChoice; }
    catch (error) { console.warn('Installation could not start.', error); }
    finally { prompt = null; button.classList.add('hidden'); button.disabled = false; }
  });
  window.addEventListener('appinstalled', () => {
    prompt = null; button?.classList.add('hidden');
  });
  if ('serviceWorker' in navigator && window.isSecureContext) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js', {scope:'/', updateViaCache:'none'})
        .catch(error => console.warn('Offline support could not start.', error));
    });
  }
})();
