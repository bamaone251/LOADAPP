# Load Desk Daily Shift Notes

A simple shared web app based on the supplied Load Desk form. It creates one standardized daily record, timestamps every entry, applies shift styling automatically, keeps an archive, and exports any day to PDF.

## Included

- One daily notes record using Central Time (`America/Chicago`)
- Logical document name: `DAILY LOAD NOTES MM/DD/YY`
- Automatic archive snapshot at 11:50 PM Central
- Automatic 1st Shift styling before 3:30 PM and 2nd Shift styling at/after 3:30 PM
- Edit, highlight/unhighlight, and delete controls
- Notes up to 2,000 characters each
- Attach up to four JPG or PNG pictures to each note (10 MB per picture)
- Phone camera/gallery picker, in-app thumbnails, full-size viewer, and photo removal
- Attached pictures are included in PDF exports
- Header assignments for Load Desk and supporting WOLs
- Archived-day viewer and per-day PDF export
- Persistent JSON storage suitable for a small internal team
- Responsive phone, tablet, and desktop layout

The `/` characters in the logical document name are shown inside the app. Downloaded files use hyphens (`DAILY LOAD NOTES MM-DD-YY.pdf`) because `/` is not valid inside a filename.

## Quick start with Docker

```bash
docker compose up -d --build
```

Open `http://SERVER-IP:8082`. Data persists in the local `data` folder. The container automatically restarts after a reboot.

## Quick start with Node.js

Requires Node.js 20 or newer.

```bash
npm install
npm start
```

Open `http://localhost:8082`.

Windows users can double-click `start.bat`. Linux users can run `chmod +x start.sh && ./start.sh`.

## Backup

Back up the entire `data` directory. `data/notes-db.json` is the live database, `data/archives` contains daily archive snapshots, and `data/uploads` contains attached pictures.

## Configuration

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `8082` | Web server port |
| `DATA_DIR` | `./data` | Persistent data directory |

All date, shift, and archive calculations are explicitly performed in `America/Chicago`, regardless of the server's operating-system timezone.

## PWA / installable app

This build includes a web app manifest, 192px/512px icons, Apple touch icon metadata, and a service worker.

- Open the site over HTTPS in Chrome/Edge/Android and choose **Install app** / **Add to Home Screen**.
- On iPhone/iPad in Safari, use **Share → Add to Home Screen**.
- The visual app shell can load from cache if the connection drops. Notes, archives, pictures, and PDF actions remain network-authoritative so shared data does not silently diverge.

## Docker deployment

```bash
docker compose up -d --build
```

The app is exposed on:

```text
http://SERVER-IP:8092
```

Persistent data is stored in `./data` through the Docker volume. For full PWA installation support outside localhost, serve the app through HTTPS (for example with Nginx + Certbot).

Useful commands:

```bash
docker compose ps
docker compose logs -f
docker compose restart
docker compose down
```

## Install as a PWA

This build is configured as an installable Progressive Web App (PWA).

- **Android / Chrome / Edge:** open the deployed HTTPS site and tap **INSTALL APP** (or use the browser's Install App option).
- **iPhone / iPad:** open the site in Safari, tap **INSTALL APP** for guidance, then use **Share > Add to Home Screen**.
- **Windows / macOS / Linux:** open the deployed HTTPS site in Chrome or Edge and use **INSTALL APP** or the install icon in the address bar.

For installation from a remote device, serve the app over **HTTPS**. Browsers also allow PWA features on `localhost` for development.
