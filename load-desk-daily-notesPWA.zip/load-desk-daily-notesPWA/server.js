const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const express = require('express');
const cron = require('node-cron');
const multer = require('multer');
const { NotesStore, SECTIONS } = require('./lib/store');
const { TIME_ZONE, dateKey, shiftAt, safeFilename } = require('./lib/time');
const { exportPdf } = require('./lib/pdf');

const app = express();
const port = Number(process.env.PORT || 8092);
const dataDir = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const uploadDir = path.join(dataDir, 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const store = new NotesStore(dataDir);

const imageExtensions = { 'image/jpeg': '.jpg', 'image/png': '.png' };
const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, done) => done(null, `${crypto.randomUUID()}${imageExtensions[file.mimetype] || ''}`)
  }),
  fileFilter: (req, file, done) => {
    if (!imageExtensions[file.mimetype]) return done(new Error('Only JPG and PNG pictures are supported.'));
    return done(null, true);
  },
  limits: { fileSize: 25 * 1024 * 1024, files: 4 }
});

app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(uploadDir, {
  index: false,
  fallthrough: false,
  maxAge: '1d',
  setHeaders: response => response.setHeader('X-Content-Type-Options', 'nosniff')
}));

app.get('/api/config', (req, res) => {
  res.json({ sections: SECTIONS, timeZone: TIME_ZONE, shiftBoundary: '15:30' });
});

app.get('/api/today', (req, res) => {
  const now = new Date();
  res.json({ day: store.ensureDay(dateKey(now)), currentShift: shiftAt(now), serverTime: now.toISOString() });
});

app.get('/api/days', (req, res) => res.json({ days: store.listDays() }));

app.get('/api/days/:date', (req, res) => {
  const day = store.getDay(req.params.date);
  if (!day) return res.status(404).json({ error: 'Daily notes not found.' });
  return res.json({ day });
});

app.patch('/api/today/header', (req, res, next) => {
  try {
    res.json({ day: store.updateHeader(dateKey(), req.body || {}) });
  } catch (error) { next(error); }
});

app.post('/api/today/entries', upload.array('images', 4), (req, res, next) => {
  try {
    const now = new Date();
    const entry = store.addEntry(dateKey(now), {
      ...req.body,
      shift: shiftAt(now),
      images: imageRecords(req.files)
    });
    res.status(201).json({ entry });
  } catch (error) {
    removeUploadedFiles(req.files);
    next(error);
  }
});

app.post('/api/entries/:id/images', upload.array('images', 4), (req, res, next) => {
  try {
    const entry = store.addImages(req.params.id, imageRecords(req.files));
    if (!entry) {
      removeUploadedFiles(req.files);
      return res.status(404).json({ error: 'Note entry not found.' });
    }
    return res.json({ entry });
  } catch (error) {
    removeUploadedFiles(req.files);
    return next(error);
  }
});

app.delete('/api/entries/:entryId/images/:imageId', (req, res) => {
  const result = store.removeImage(req.params.entryId, req.params.imageId);
  if (!result) return res.status(404).json({ error: 'Picture not found.' });
  removeImageFile(result.image);
  return res.json({ entry: result.entry });
});

app.patch('/api/entries/:id', (req, res, next) => {
  try {
    const entry = store.updateEntry(req.params.id, req.body || {});
    if (!entry) return res.status(404).json({ error: 'Note entry not found.' });
    return res.json({ entry });
  } catch (error) { next(error); }
});

app.delete('/api/entries/:id', (req, res) => {
  const entry = store.deleteEntry(req.params.id);
  if (!entry) return res.status(404).json({ error: 'Note entry not found.' });
  for (const image of entry.images || []) removeImageFile(image);
  return res.status(204).end();
});

app.get('/api/days/:date/pdf', (req, res, next) => {
  try {
    const day = store.getDay(req.params.date);
    if (!day) return res.status(404).json({ error: 'Daily notes not found.' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${safeFilename(day.date, '.pdf')}"`);
    return exportPdf(day, res, uploadDir);
  } catch (error) { return next(error); }
});

app.use((error, req, res, next) => {
  console.error(error);
  if (res.headersSent) return next(error);
  return res.status(400).json({ error: error.message || 'Request could not be completed.' });
});

cron.schedule('50 23 * * *', () => {
  const day = store.archiveDay(dateKey());
  console.log(`Archived ${day.filename}`);
}, { timezone: TIME_ZONE });

cron.schedule('0 0 * * *', () => {
  const day = store.ensureDay(dateKey());
  console.log(`Created ${day.filename}`);
}, { timezone: TIME_ZONE });

app.listen(port, '0.0.0.0', () => {
  console.log(`Load Desk Daily Notes is running at http://0.0.0.0:${port}`);
  console.log(`Daily archive: 11:50 PM ${TIME_ZONE}`);
});

function imageRecords(files = []) {
  return files.map(file => ({
    id: crypto.randomUUID(),
    filename: file.filename,
    originalName: String(file.originalname || 'picture').slice(0, 180),
    mimeType: file.mimetype,
    size: file.size
  }));
}

function removeUploadedFiles(files = []) {
  for (const file of files) fs.rmSync(file.path, { force: true });
}

function removeImageFile(image) {
  if (!image?.filename) return;
  const resolved = path.join(uploadDir, path.basename(image.filename));
  fs.rmSync(resolved, { force: true });
}

