# Combined Load Tools PWA

Both attached calculators are combined on one page. Desktop shows them side by side; mobile stacks them. Their inputs stay independent, update results immediately and are remembered on the current browser/device.

## Docker

Unzip, enter the combined-load-tools directory, then run:

```sh
docker compose up -d --build
```

Open http://YOUR-SERVER-IP:8082. Change 8082 in docker-compose.yml if that port is occupied. Put your HTTPS reverse proxy in front of this port for mobile installation and offline support. No database or external APIs are needed.

## Installation

Open your HTTPS address in Chrome or Edge and use Install app when available, or the browser menu's Install/Add to Home Screen option. On iPhone/iPad, open in Safari and use Share > Add to Home Screen. Service workers require HTTPS (or localhost); opening index.html directly or using an HTTP server IP will not enable offline support.

Visit once online to cache the app. Both calculators then work offline. Saved inputs are local to each browser and are not shared with other users.

## Calculations retained from the supplied apps

- Actual efficiency: (Runs + Diversions) / (Total Hours - 0.5 * Backhauls). Adjusted hours must be positive.
- Planned hours: (Runs + Diversions) / 0.67 + 0.5 * Backhauls.
- Loaders needed: planned hours / 8 (fractional eight-hour loader equivalents, not rounded headcount).
- First shift: floor(Runs * 0.65). Second shift: Runs - First shift, retaining the supplied whole-run split.

The page has no CDN dependencies. To release future updates, change the cache version in sw.js and rebuild the container.
