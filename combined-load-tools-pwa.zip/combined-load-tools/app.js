const $=id=>document.getElementById(id);
function calculate(form){
 const data=Object.fromEntries(new FormData(form));
 try{localStorage.setItem('load-tools-'+form.id,JSON.stringify(data));}catch{}
 if(!form.checkValidity()){
 if(form.id==='actual'){$('efficiency').textContent='—';$('actual-detail').textContent='Enter nonnegative values in every field.';}
 else{['required-hours','loaders','first','second'].forEach(id=>$(id).textContent='—');}return;
 }
 const r=Number(data.runs),b=Number(data.backhauls),d=Number(data.diversions);
 if(form.id==='actual'){
 const h=Number(data.hours),adjusted=h-0.5*b;
 $('efficiency').textContent=adjusted>0?((r+d)/adjusted).toFixed(3):'—';
 $('actual-detail').textContent=adjusted>0?`(${r} + ${d}) ÷ (${h} − 0.5 × ${b}) • ${adjusted.toFixed(2)} adjusted hours`:'Total hours must be greater than the backhaul allowance.';
 }else{
 const hours=(r+d)/0.67+0.5*b;
 $('required-hours').textContent=hours.toFixed(2);$('loaders').textContent=(hours/8).toFixed(2);
 $('first').textContent=Math.floor(r*0.65);$('second').textContent=r-Math.floor(r*0.65);
 }
}
['actual','plan'].forEach(id=>{const form=$(id);try{const saved=JSON.parse(localStorage.getItem('load-tools-'+id));if(saved)for(const input of form.querySelectorAll('input'))if(saved[input.name]!==undefined)input.value=saved[input.name];}catch{}
form.addEventListener('submit',e=>{e.preventDefault();calculate(form)});form.addEventListener('input',()=>calculate(form));calculate(form);});
let installPrompt;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;$('install').hidden=false;});
$('install').addEventListener('click',async()=>{if(!installPrompt)return;await installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$('install').hidden=true;});
window.addEventListener('appinstalled',()=>{$('install').hidden=true;});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.error));
