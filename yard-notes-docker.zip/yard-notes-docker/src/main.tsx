import React from 'react';import {createRoot} from 'react-dom/client';import Notes from './Notes';createRoot(document.getElementById('root')!).render(<Notes/>);
