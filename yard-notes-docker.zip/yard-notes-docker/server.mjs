import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
const data=resolve(process.env.DATA_DIR||'data');mkdirSync(data,{recursive:true});
const db=new DatabaseSync(resolve(data,'notes.sqlite'));
db.exec("PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS notes (id TEXT PRIMARY KEY,content TEXT NOT NULL,highlighted INTEGER NOT NULL DEFAULT 0,createdAt INTEGER NOT NULL,updatedAt INTEGER NOT NULL)");
const assets=new Map([['/','index.html'],['/index.html','index.html'],['/app.js','app.js'],['/styles.css','styles.css'],['/sw.js','sw.js'],['/icon.svg','icon.svg'],['/manifest.webmanifest','manifest.webmanifest']]);
const mime={html:'text/html; charset=utf-8',js:'text/javascript; charset=utf-8',css:'text/css; charset=utf-8',svg:'image/svg+xml',webmanifest:'application/manifest+json'};
function json(res,status,value){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value))}
const server=http.createServer(async(req,res)=>{
try{
const path=new URL(req.url,'http://localhost').pathname;
if(path==='/healthz')return json(res,200,{ok:true});
if(path==='/api/notes'){
if(req.method==='GET')return json(res,200,db.prepare('SELECT * FROM notes ORDER BY highlighted DESC, createdAt DESC').all().map(n=>({...n,highlighted:!!n.highlighted})));
if(req.method!=='POST')return json(res,405,{error:'Method not allowed'});
let raw='',size=0;for await(const chunk of req){size+=chunk.length;if(size>65536)return json(res,413,{error:'Note is too large'});raw+=chunk}
let b;try{b=JSON.parse(raw)}catch{return json(res,400,{error:'Invalid JSON'})}
if(!b||!['create','edit','highlight','delete'].includes(b.action))return json(res,400,{error:'Invalid action'});
if(['create','edit'].includes(b.action)&&(typeof b.content!=='string'||!b.content.trim()||b.content.length>10000))return json(res,400,{error:'Write a note of 1 to 10,000 characters.'});
if(b.action!=='create'&&(typeof b.id!=='string'||!Number.isSafeInteger(b.updatedAt)))return json(res,400,{error:'Missing note version'});
if(b.action==='highlight'&&typeof b.highlighted!=='boolean')return json(res,400,{error:'Invalid highlight'});
const now=Date.now();
if(b.action==='create')db.prepare('INSERT INTO notes VALUES (?,?,?,?,?)').run(randomUUID(),b.content.trim(),b.highlighted===true?1:0,now,now);
else{
let result;
if(b.action==='delete')result=db.prepare('DELETE FROM notes WHERE id=? AND updatedAt=?').run(b.id,b.updatedAt);
else if(b.action==='edit')result=db.prepare('UPDATE notes SET content=?,updatedAt=? WHERE id=? AND updatedAt=?').run(b.content.trim(),Math.max(now,b.updatedAt+1),b.id,b.updatedAt);
else result=db.prepare('UPDATE notes SET highlighted=?,updatedAt=? WHERE id=? AND updatedAt=?').run(b.highlighted?1:0,Math.max(now,b.updatedAt+1),b.id,b.updatedAt);
if(!result.changes)return json(res,409,{error:'This note changed or was deleted. Refresh and try again.'});
}
return json(res,200,{ok:true});
}
if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end()}
const file=assets.get(path);if(!file){res.writeHead(404);return res.end('Not found')}
const bytes=readFileSync(new URL('./public/'+file,import.meta.url));res.writeHead(200,{'Content-Type':mime[file.split('.').pop()]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:bytes);
}catch(e){console.error(e);if(!res.headersSent)json(res,500,{error:'Unable to save the note. Try again.'});else res.end()}
});
server.listen(Number(process.env.PORT||4178),'0.0.0.0',()=>console.log('Yard Notes listening on port '+(process.env.PORT||4178)));
process.on('SIGTERM',()=>server.close(()=>{db.close();process.exit(0)}));

