# Yard Notes — Docker
Requires Docker with Docker Compose.

## Start
Extract the ZIP, open a terminal in this folder, and run:

```sh
docker compose up -d --build
```

Open http://localhost:4178 (or http://YOUR-SERVER-IP:4178).
The first build downloads dependencies. No ChatGPT account or cloud service is required.

## Dashboard iframe
```html
<iframe src="http://YOUR-SERVER-IP:4178" title="Yard Notes" style="width:100%;height:600px;border:0"></iframe>
```
Replace YOUR-SERVER-IP with your Docker host. An HTTPS dashboard must embed an HTTPS URL; route this service through your existing HTTPS reverse proxy.

## Features
Shared add/edit/delete, note text without titles, automatic timestamps, highlighted notes first, newest first within each group, search, and automatic refresh every 10 seconds.
Anyone who can reach this service can view and modify notes. There is no login.

## Persistence and backups
Notes live in the Docker named volume `notes-data` at /data/notes.sqlite, including SQLite WAL files. Restarting or rebuilding the container preserves notes.
`docker compose down` preserves the volume. `docker compose down -v` deletes it.
For a consistent backup, stop the service and back up the whole named volume using your Docker backup tools, then restart it.

## Stop / logs
```sh
docker compose down
docker compose logs -f
```

## PWA and offline reading
Install from the browser when opened as a top-level page over HTTPS or localhost.
Service workers are unavailable over plain HTTP on a remote IP. Ordinary notes and iframe use still work over HTTP.
Offline reading becomes available after an online visit in a supported secure context. Editing requires a connection.

## Existing hosted notes
This Docker package starts with an empty database. Notes from the previously hosted Sites app are not automatically transferred.

## Without Docker (optional)
Node.js 24 or newer:
```sh
npm ci
npm run build
npm start
```
Default port: 4178. Local database: ./data/notes.sqlite.

