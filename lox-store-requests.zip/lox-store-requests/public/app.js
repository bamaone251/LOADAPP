'use strict';

// ============================================================
// DOM references and application state
// ============================================================

const $ = selector => document.querySelector(selector);
const form = $('#request-form');

let records = [];
let view = 'current';
let editing = null;
let busy = false;
let installPrompt;
let toastTimer;

let serverOffset = 0;
let renderedDay = null;

// ============================================================
// Request age and border colors
// ============================================================

// Calendar-day age uses Central time, including DST changes.
function requestAgeDays(value) {
  const central = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Chicago',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date(Date.now() + serverOffset));

  return Math.max(
    0,
    Math.round(
      (
        Date.parse(central + 'T00:00:00Z') -
        Date.parse(value + 'T00:00:00Z')
      ) / 86400000
    )
  );
}

function borderState(r) {
  return r.completed_at
    ? 'completed'
    : 'age-' + Math.min(3, requestAgeDays(r.request_date));
}

// ============================================================
// Date formatting and current-view retention
// ============================================================

// Completed requests remain in the current view for 48 hours.
const recent = r =>
  !r.completed_at ||
  Date.parse(r.completed_at) >
    Date.now() + serverOffset - 48 * 3600000;

const date = value =>
  new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/Chicago',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  }).format(new Date(value));

const requestDate = value =>
  new Intl.DateTimeFormat('en-US', {
    timeZone: 'UTC',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }).format(new Date(value + 'T12:00:00Z'));

function todayCentral() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Chicago',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
}

// ============================================================
// DOM helpers and notifications
// ============================================================

function node(tag, cls, text) {
  const el = document.createElement(tag);

  if (cls) {
    el.className = cls;
  }

  if (text !== undefined) {
    el.textContent = text;
  }

  return el;
}

function action(label, cls, handler) {
  const el = node('button', cls, label);
  el.onclick = handler;

  return el;
}

function toast(text) {
  $('#toast').textContent = text;
  $('#toast').hidden = false;

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    $('#toast').hidden = true;
  }, 3500);
}

function showError(message) {
  $('#error').textContent = message;
  $('#error').hidden = !message;
}

// ============================================================
// API requests
// ============================================================

async function api(path, options) {
  const response = await fetch(path, options);
  const data = await response.json();

  if (!response.ok) {
    throw Error(data.error || 'Request failed.');
  }

  return data;
}

async function persist(payload, id) {
  return api('/api/requests' + (id ? '/' + id : ''), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });
}

// ============================================================
// Request types and live refresh
// ============================================================

function fillTypes(types) {
  if (form.elements.request_type.options.length) {
    return;
  }

  for (const type of types) {
    form.elements.request_type.add(new Option(type, type));
    $('#type-filter').add(new Option(type, type));
  }
}

async function refresh() {
  try {
    const data = await api('/api/requests');

    const before =
      JSON.stringify(records) +
      records
        .filter(recent)
        .map(r => r.id)
        .join(',');

    records = data.requests;
    serverOffset = Date.parse(data.server_time) - Date.now();

    fillTypes(data.types);

    const changed =
      before !==
      JSON.stringify(records) +
        records
          .filter(recent)
          .map(r => r.id)
          .join(',');

    $('#connection').textContent =
      '● Live · ' +
      new Intl.DateTimeFormat('en-US', {
        timeZone: 'America/Chicago',
        hour: 'numeric',
        minute: '2-digit'
      }).format(new Date());

    showError('');

    if (
      changed ||
      renderedDay !== todayCentral() ||
      !$('#requests').childElementCount
    ) {
      render();
    }

    if (view === 'exports') {
      await loadExports();
    }
  } catch (error) {
    $('#connection').textContent = '● Connection lost';

    showError(
      'Unable to reach the server. Displayed entries may be out of date. ' +
      error.message
    );
  }
}

// ============================================================
// Filter, sort, and render the request list
// ============================================================

function render() {
  renderedDay = todayCentral();

  const active = records.filter(recent);

  $('#open-count').textContent =
    records.filter(r => !r.completed_at).length;

  $('#urgent-count').textContent =
    records.filter(r => r.urgent && !r.completed_at).length;

  $('#done-count').textContent =
    active.filter(r => r.completed_at).length;

  if (view === 'exports') {
    return;
  }

  const query = $('#search').value.trim().toLowerCase();
  const status = $('#status').value;
  const type = $('#type-filter').value;

  let shown = (view === 'archive' ? records : active).filter(r =>
    (!$('#urgent-filter').checked || r.urgent) &&
    (!type || r.request_type === type) &&
    (
      status === 'all' ||
      (status === 'open' ? !r.completed_at : !!r.completed_at)
    ) &&
    [
      r.id,
      r.store,
      r.request_type,
      r.destination,
      r.notes,
      r.driver,       
      r.request_date
    ].some(value => String(value).toLowerCase().includes(query))
  );

  // Open requests first, then urgent requests, then newest dates.
  shown.sort((a, b) =>
    (!!a.completed_at - !!b.completed_at) ||
    (b.urgent - a.urgent) ||
    b.request_date.localeCompare(a.request_date) ||
    b.id - a.id
  );

  $('#result-count').textContent =
    `${shown.length} request${shown.length === 1 ? '' : 's'} · ` +
    `${view === 'archive' ? 'all entries retained' : 'urgent requests first'}`;

  $('#requests').replaceChildren();

  if (!shown.length) {
    const empty = node('div', 'empty');

    empty.append(
      node(
        'h3',
        '',
        records.length
          ? 'No matching requests'
          : 'A clear board. A fresh start.'
      ),
      node(
        'p',
        '',
        records.length
          ? 'Try another search or filter.'
          : 'Log a store request to keep transfers and cleanouts on track.'
      )
    );

    const add = node('button', 'primary', '+ New request');
    add.onclick = () => openForm();

    empty.append(add);
    $('#requests').append(empty);
  }

  if (shown.length) {
    const headings = node('div', 'request-columns');

    for (const label of [
      'Store',
      'Request',
      'Destination',
      'Notes',
      'Driver',
      'Requested',
      'Completed',
      
      'Status',
      'Actions'
    ]) {
      headings.append(node('span', '', label));
    }

    $('#requests').append(headings);
  }

  for (const r of shown) {
    $('#requests').append(card(r));
  }
}

// ============================================================
// Single-line request rows
// ============================================================

function card(r) {
  const article = node(
    'article',
    'request-card request-row ' +
      borderState(r) +
      (r.urgent ? ' urgent' : '')
  );

  const store = node('div', 'row-store', r.store);

 
  article.append(store);

  for (const [cls, value] of [
    ['row-type', r.request_type],
    ['row-destination', r.destination],
    ['row-notes', r.notes || '—'],
    ['row-driver', r.driver || 'Unassigned'],
    ['row-date', requestDate(r.request_date)],
    ['row-date', r.completed_at ? date(r.completed_at) : '—']
    
  ]) {
    const cell = node('div', cls, value);
    cell.title = value;

    article.append(cell);
  }

  const badges = node('div', 'badges');

  if (r.urgent) {
    badges.append(node('span', 'badge urgent', 'URGENT'));
  }

  badges.append(
    node(
      'span',
      'badge' + (r.completed_at ? ' done' : ''),
      r.completed_at ? 'COMPLETED' : 'UNCOMPLETED'
    )
  );

  const controls = node('div', 'row-actions');

  controls.append(
    action('Edit', 'quiet', () => openForm(r)),
    action('History', 'quiet', () => showHistory(r)),
    action(
      r.completed_at ? '↶ Reopen' : '✓ Complete',
      'complete-action',
      event => quickComplete(r, event.currentTarget)
    )
  );

  article.append(badges, controls);

  return article;
}

// ============================================================
// Request editor
// ============================================================

function openForm(r = null) {
  if (!form.elements.request_type.options.length) {
    return toast('Connect to the server before creating a request.');
  }

  editing = r;
  form.reset();

  $('#form-error').hidden = true;
  $('#form-title').textContent = r
    ? 'Edit request #' + r.id
    : 'New request';

  form.elements.request_date.value = r
    ? r.request_date
    : todayCentral();

  if (r) {
    for (const key of [
      'store',
      'request_type',
      'destination',
      'driver',
      'notes'
    ]) {
      form.elements[key].value = r[key];
    }

    form.elements.urgent.checked = !!r.urgent;
    form.elements.completed.checked = !!r.completed_at;
  }

  $('#editor').showModal();
}

// ============================================================
// Save form submission
// ============================================================

form.addEventListener('submit', async event => {
  event.preventDefault();

  if (busy) {
    return;
  }

  busy = true;

  $('#save').disabled = true;
  $('#form-error').hidden = true;

  const payload = Object.fromEntries(new FormData(form));

  payload.urgent = form.elements.urgent.checked;
  payload.completed = form.elements.completed.checked;

  if (editing) {
    payload.version = editing.version;
  }

  try {
    await persist(payload, editing?.id);

    $('#editor').close();
    toast('Request saved');

    await refresh();
  } catch (error) {
    $('#form-error').textContent = error.message;
    $('#form-error').hidden = false;
  } finally {
    busy = false;
    $('#save').disabled = false;
  }
});

// ============================================================
// Complete or reopen a request
// ============================================================

async function quickComplete(r, button) {
  button.disabled = true;

  try {
    await persist(
      {
        ...r,
        urgent: !!r.urgent,
        completed: !r.completed_at
      },
      r.id
    );

    toast(r.completed_at ? 'Request reopened' : 'Request completed');

    await refresh();
  } catch (error) {
    showError(error.message);
    button.disabled = false;
  }
}

// ============================================================
// Request history
// ============================================================

async function showHistory(r) {
  $('#history-list').textContent = 'Loading history…';
  $('#history-dialog').showModal();

  try {
    const changes = await api(`/api/requests/${r.id}/history`);

    $('#history-list').replaceChildren();

    for (const change of changes) {
      const snapshot = JSON.parse(change.snapshot);
      const item = node('div', 'history-item');

      item.append(
        node('time', '', date(change.changed_at)),
        node(
          'strong',
          '',
          `${snapshot.store} · ${snapshot.request_type}`
        ),
        node(
          'p',
          '',
          `${snapshot.completed_at ? 'Completed' : 'Uncompleted'}` +
          `${snapshot.urgent ? ' · URGENT' : ''}\n` +
          `Destination: ${snapshot.destination}\n` +
          `Driver: ${snapshot.driver || 'Unassigned'}\n` +
          `Request date: ${snapshot.request_date}\n` +
          `${snapshot.notes}`
        )
      );

      $('#history-list').append(item);
    }
  } catch (error) {
    $('#history-list').textContent = error.message;
  }
}

// ============================================================
// Excel exports
// ============================================================

async function loadExports() {
  const files = await api('/api/exports');

  $('#export-list').replaceChildren();

  if (!files.length) {
    const empty = node('div', 'empty');

    empty.append(
      node('h3', '', 'First report arrives at midnight'),
      node(
        'p',
        '',
        'You can download current requests or the full archive at any time.'
      )
    );

    $('#export-list').append(empty);
  }

  for (const file of files) {
    const row = node('div', 'export-file');
    const info = node('div');

    info.append(
      node('strong', '', file.name),
      node(
        'p',
        '',
        `${Math.ceil(file.size / 1024)} KB · Excel workbook`
      )
    );

    const download = node('a', 'button', '↓ Download');
    download.href = '/api/exports/' + encodeURIComponent(file.name);

    row.append(info, download);
    $('#export-list').append(row);
  }

  $('#result-count').textContent =
    files.length + ' saved nightly reports';
}

// ============================================================
// Current, archive, and export views
// ============================================================

async function setView(next) {
  view = next;

  document.querySelectorAll('[data-view]').forEach(button => {
    const selected = button.dataset.view === view;

    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });

  $('#requests').hidden = view === 'exports';
  $('#filters').hidden = view === 'exports';
  $('#exports-panel').hidden = view !== 'exports';

  $('#export').href = view === 'archive'
    ? '/api/export/archive'
    : '/api/export/current';

  $('#footer-note').textContent = view === 'archive'
    ? 'Permanent archive · edit or reopen any request.'
    : 'Completed requests leave the current view after 48 hours. Every entry stays in the archive.';

  if (view === 'exports') {
    try {
      await loadExports();
    } catch (error) {
      showError(error.message);
    }
  } else {
    render();
  }
}

// ============================================================
// Button and filter event handlers
// ============================================================

$('#add').onclick = () => openForm();
$('#refresh').onclick = refresh;

for (const input of [
  '#search',
  '#status',
  '#type-filter',
  '#urgent-filter'
]) {
  $(input).addEventListener('input', render);
}

document.querySelectorAll('[data-view]').forEach(button => {
  button.onclick = () => setView(button.dataset.view);
});

document.querySelectorAll('[data-close]').forEach(button => {
  button.onclick = () => {
    $('#' + button.dataset.close).close();
  };
});

document.querySelectorAll('[data-stat]').forEach(button => {
  button.onclick = () => {
    $('#status').value = button.dataset.stat === 'completed'
      ? 'completed'
      : 'open';

    $('#urgent-filter').checked = button.dataset.stat === 'urgent';
    $('#search').value = '';
    $('#type-filter').value = '';

    setView('current');
  };
});

// ============================================================
// PWA installation
// ============================================================

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  installPrompt = event;

  if (window.self === window.top) {
    $('#install').hidden = false;
  }
});

$('#install').onclick = async () => {
  if (installPrompt) {
    await installPrompt.prompt();

    installPrompt = null;
    $('#install').hidden = true;
  }
};

// ============================================================
// Service worker and automatic refresh
// ============================================================

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

window.addEventListener('online', refresh);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    refresh();
  }
});

// Load requests immediately.
refresh();

// Refresh every 15 seconds while visible and not saving.
setInterval(() => {
  if (!document.hidden && !busy) {
    refresh();
  }
}, 15000);