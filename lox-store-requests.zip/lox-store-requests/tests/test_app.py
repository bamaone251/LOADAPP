import importlib.util
import io
import json
import tempfile
import threading
import unittest
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

spec = importlib.util.spec_from_file_location('app', Path(__file__).parents[1]/'server.py')
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)

class RequestsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        app.DATA = Path(self.temp.name)
        app.initialize()
        self.payload = dict(request_date='2026-11-04', store='fp17', request_type=app.TYPES[0],
                            destination='LOX warehouse', driver='Andy', notes='10 pallets',
                            urgent=True, completed=False)
    def tearDown(self):
        self.temp.cleanup()
    def test_lifecycle_history_and_conflict(self):
        first = app.save_record(self.payload)
        self.assertEqual(first['store'], 'FP17')
        done = app.save_record(dict(self.payload, completed=True, version=first['version']),first['id'])
        self.assertIsNotNone(done['completed_at'])
        unchanged = app.save_record(dict(self.payload,completed=True,version=done['version']),first['id'])
        self.assertEqual(done['completed_at'],unchanged['completed_at'])
        with self.assertRaises(RuntimeError):
            app.save_record(dict(self.payload,version=1),first['id'])
        reopened = app.save_record(dict(self.payload,version=unchanged['version']),first['id'])
        self.assertIsNone(reopened['completed_at'])
        self.assertEqual(len(app.rows()),1)
        with app.connect() as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM history').fetchone()[0],4)
    def test_48_hour_boundary_permanent_archive(self):
        at = datetime(2026,11,4,18,tzinfo=timezone.utc)
        first = app.save_record(self.payload)
        for hours,visible in [(47.999,True),(48,False),(49,False)]:
            with app.connect() as db:
                db.execute('UPDATE requests SET completed_at=? WHERE id=?',(app.stamp(at-timedelta(hours=hours)),first['id']))
            self.assertEqual(bool(app.current(app.rows(),at)),visible)
            self.assertEqual(len(app.rows()),1)
    def test_validation(self):
        for change in [dict(store=''),dict(request_type='Fake'),dict(request_date='2026-02-30'),dict(urgent='yes'),dict(destination='')]:
            with self.assertRaises(ValueError):
                app.save_record(dict(self.payload,**change))
    def test_excel_literal_strings_and_structure(self):
        import openpyxl
        record = app.save_record(dict(self.payload, notes='=HYPERLINK("bad")\x01 < &'))
        wb=openpyxl.load_workbook(io.BytesIO(app.xlsx([record])))
        ws=wb.active
        self.assertEqual(ws.max_column,12)
        self.assertEqual(ws['J2'].value,'=HYPERLINK("bad") < &')
        self.assertEqual(ws['J2'].data_type,'s')
        self.assertEqual(ws.freeze_panes,'A2')
        self.assertEqual(ws.auto_filter.ref,'A1:L2')
    def test_midnight_once_and_restart_catchup(self):
        app.save_record(self.payload)
        with app.connect() as db:
            db.execute("UPDATE settings SET value='2026-11-03' WHERE key='last_export_day'")
        # Nov 4 midnight Central = 06:00 UTC.
        app.export_if_due(datetime(2026,11,4,5,59,tzinfo=timezone.utc))
        self.assertEqual(len(list((app.DATA/'exports').glob('*.xlsx'))),0)
        app.export_if_due(datetime(2026,11,4,6,0,tzinfo=timezone.utc))
        file=app.DATA/'exports/LOX-Requests-2026-11-04.xlsx'
        self.assertTrue(file.exists())
        original=file.stat().st_mtime_ns
        app.export_if_due(datetime(2026,11,4,10,0,tzinfo=timezone.utc))
        self.assertEqual(file.stat().st_mtime_ns,original)
        app.export_if_due(datetime(2026,11,6,12,0,tzinfo=timezone.utc))
        self.assertTrue((app.DATA/'exports/LOX-Requests-2026-11-06.xlsx').exists())
    def test_daylight_saving_midnight(self):
        with app.connect() as db:
            db.execute("UPDATE settings SET value='2026-07-03' WHERE key='last_export_day'")
        app.export_if_due(datetime(2026,7,4,4,59,tzinfo=timezone.utc))
        self.assertFalse(list((app.DATA/'exports').glob('*.xlsx')))
        app.export_if_due(datetime(2026,7,4,5,0,tzinfo=timezone.utc))
        self.assertTrue((app.DATA/'exports/LOX-Requests-2026-07-04.xlsx').exists())
    def test_http_and_iframe_headers(self):
        http=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{http.server_port}'
        try:
            with urllib.request.urlopen(base+'/') as response:
                self.assertIn('https://superdash.loxload.com',response.headers['Content-Security-Policy'])
                self.assertNotIn('X-Frame-Options',response.headers)
                self.assertIn(b'Store Requests',response.read())
            request=urllib.request.Request(base+'/api/requests',data=json.dumps(self.payload).encode(),headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(request) as response:
                self.assertEqual(response.status,201)
            with urllib.request.urlopen(base+'/api/requests') as response:
                self.assertEqual(len(json.load(response)['requests']),1)
            with urllib.request.urlopen(base+'/api/export/current') as response:
                self.assertEqual(response.read()[:2],b'PK')
        finally:
            http.shutdown();http.server_close();thread.join()

if __name__ == '__main__':
    unittest.main()
