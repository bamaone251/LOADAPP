"""LOX store requests: shared SQLite records, permanent history, midnight XLSX."""
import io
import json
import logging
import os
import re
import sqlite3
import threading
import zipfile
from datetime import datetime, timedelta, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from xml.sax.saxutils import escape
from zoneinfo import ZoneInfo

ROOT = Path(__file__).parent
DATA = Path(os.getenv('DATA_DIR', ROOT / 'data'))
CENTRAL = ZoneInfo(os.getenv('APP_TIMEZONE', 'America/Chicago'))
TYPES = ['Dry Pallet Transfer', 'Chiller Pallet Transfer', 'Freezer Pallet Transfer',
         'Store-to-store transfer', 'Cleanout Request', 'Other']
EXPORT_LOCK = threading.Lock()

def now():
    return datetime.now(timezone.utc)

def stamp(t=None):
    return (t or now()).isoformat(timespec='microseconds')

def connect():
    db = sqlite3.connect(DATA / 'requests.sqlite3', timeout=30)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db

def initialize():
    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / 'exports').mkdir(exist_ok=True)
    with connect() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
        CREATE TABLE IF NOT EXISTS requests (
          id INTEGER PRIMARY KEY AUTOINCREMENT, request_date TEXT NOT NULL,
          store TEXT NOT NULL, request_type TEXT NOT NULL, destination TEXT NOT NULL,
          driver TEXT NOT NULL, notes TEXT NOT NULL, urgent INTEGER NOT NULL,
          completed_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          version INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS history (
          id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL,
          changed_at TEXT NOT NULL, snapshot TEXT NOT NULL,
          FOREIGN KEY(request_id) REFERENCES requests(id));
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        ''')
        db.execute("INSERT OR IGNORE INTO settings VALUES ('last_export_day', ?)",
                   (now().astimezone(CENTRAL).date().isoformat(),))

def rows():
    with connect() as db:
        return [dict(r) for r in db.execute('SELECT * FROM requests ORDER BY urgent DESC, request_date DESC, id DESC')]

def current(records, at=None):
    cutoff = stamp((at or now()) - timedelta(hours=48))
    return [r for r in records if not r['completed_at'] or r['completed_at'] > cutoff]

def save_record(payload, request_id=None):
    if not isinstance(payload, dict):
        raise ValueError('Invalid request data.')
    fields = {}
    for key, limit in [('request_date', 10), ('store', 30), ('request_type', 60),
                       ('destination', 120), ('driver', 100), ('notes', 4000)]:
        value = payload.get(key, '')
        if not isinstance(value, str) or len(value) > limit:
            raise ValueError(f'Invalid {key.replace("_", " ")}.')
        fields[key] = value.strip()
    try:
        datetime.strptime(fields['request_date'], '%Y-%m-%d')
    except ValueError:
        raise ValueError('Choose a valid request date.')
    if not fields['store'] or not fields['destination'] or fields['request_type'] not in TYPES:
        raise ValueError('Store, request type, and destination are required.')
    fields['store'] = fields['store'].upper()
    for key in ['urgent', 'completed']:
        if type(payload.get(key, False)) is not bool:
            raise ValueError(f'Invalid {key}.')
    timestamp = stamp()
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        old = db.execute('SELECT * FROM requests WHERE id=?', (request_id,)).fetchone() if request_id else None
        if request_id and not old:
            raise KeyError('Request not found.')
        if old and payload.get('version') != old['version']:
            raise RuntimeError('Another user updated this request. Close this form and refresh before editing.')
        fields.update(urgent=int(payload.get('urgent', False)),
                      completed_at=(old['completed_at'] if old and old['completed_at'] else timestamp)
                      if payload.get('completed', False) else None, updated_at=timestamp)
        if old:
            db.execute('UPDATE requests SET ' + ','.join(k+'=?' for k in fields) + ',version=version+1 WHERE id=?',
                       [*fields.values(), request_id])
        else:
            fields['created_at'] = timestamp
            result = db.execute('INSERT INTO requests ('+','.join(fields)+') VALUES ('+','.join('?' for _ in fields)+')', list(fields.values()))
            request_id = result.lastrowid
        record = dict(db.execute('SELECT * FROM requests WHERE id=?', (request_id,)).fetchone())
        db.execute('INSERT INTO history(request_id,changed_at,snapshot) VALUES (?,?,?)',
                   (request_id, timestamp, json.dumps(record)))
        return record

def xlsx(records, at=None):
    """Write standard XLSX with literal strings, so input cannot become formulas."""
    at = at or now()
    headers = ['ID', 'Request date', 'Store requesting', 'Request', 'Destination', 'Status',
               'Driver', 'Urgent', 'Completed (Central)', 'Notes', 'Created (Central)', 'Updated (Central)']
    def local(value):
        return datetime.fromisoformat(value).astimezone(CENTRAL).strftime('%m/%d/%Y %I:%M %p %Z') if value else ''
    values = [headers] + [[r['id'], r['request_date'], r['store'], r['request_type'], r['destination'],
              'Completed' if r['completed_at'] else 'Uncompleted', r['driver'], 'YES' if r['urgent'] else '',
              local(r['completed_at']), r['notes'], local(r['created_at']), local(r['updated_at'])] for r in records]
    def safe(value):
        return escape(re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', str(value)))
    xmlrows = []
    for number, row in enumerate(values, 1):
        cells = ''.join(f'<c r="{chr(65+i)}{number}" s="{1 if number == 1 else 0}" t="inlineStr"><is><t xml:space="preserve">{safe(v)}</t></is></c>' for i, v in enumerate(row))
        xmlrows.append(f'<row r="{number}" ht="{30 if number == 1 else 44}" customHeight="1">{cells}</row>')
    ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    sheet = f'''<worksheet xmlns="{ns}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>''' + ''.join(f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>' for i,w in enumerate([9,16,19,30,23,18,22,10,29,50,29,29],1)) + f'</cols><sheetData>{"".join(xmlrows)}</sheetData><autoFilter ref="A1:L{len(values)}"/></worksheet>'
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>')
        z.writestr('_rels/.rels', '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', f'<workbook xmlns="{ns}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Store requests" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels', '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr('xl/styles.xml', f'<styleSheet xmlns="{ns}"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF163A45"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
        z.writestr('xl/worksheets/sheet1.xml', sheet)
    return output.getvalue()

def export_if_due(at=None):
    at = at or now()
    day = at.astimezone(CENTRAL).date().isoformat()
    with EXPORT_LOCK, connect() as db:
        last = db.execute("SELECT value FROM settings WHERE key='last_export_day'").fetchone()[0]
        if day <= last:
            return
        # On restart after midnight, save a catch-up snapshot of the current state.
        target = DATA / 'exports' / f'LOX-Requests-{day}.xlsx'
        temporary = target.with_suffix('.tmp')
        temporary.write_bytes(xlsx(current(rows(), at), at))
        temporary.replace(target)
        db.execute("UPDATE settings SET value=? WHERE key='last_export_day'", (day,))

def scheduler(stop):
    while not stop.is_set():
        try:
            export_if_due()
        except Exception:
            logging.exception('Nightly export failed; retrying in 10 seconds')
        stop.wait(10)

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / 'public'), **kwargs)

    def end_headers(self):
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; worker-src 'self'; manifest-src 'self'; frame-ancestors 'self' https://superdash.loxload.com https://superdash.andytalbert.com")
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'same-origin')
        self.send_header('Cache-Control', 'no-store' if self.path.startswith('/api/') else 'no-cache')
        super().end_headers()

    def reply(self, data, status=200, mime='application/json', filename=None):
        body = json.dumps(data).encode() if mime == 'application/json' else data
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(body)))
        if filename:
            self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/health':
            with connect() as db:
                db.execute('SELECT 1')
            return self.reply({'ok': True})
        if path == '/api/requests':
            return self.reply({'requests': rows(), 'types': TYPES, 'timezone': str(CENTRAL), 'server_time': stamp()})
        if re.fullmatch(r'/api/requests/\d+/history', path):
            with connect() as db:
                changes = [dict(r) for r in db.execute('SELECT changed_at,snapshot FROM history WHERE request_id=? ORDER BY id DESC', (int(path.split('/')[3]),))]
            return self.reply(changes)
        if path == '/api/exports':
            return self.reply([{'name': p.name, 'size': p.stat().st_size} for p in sorted((DATA/'exports').glob('*.xlsx'), reverse=True)])
        if path in ['/api/export/current', '/api/export/archive']:
            records = rows()
            if path.endswith('current'):
                records = current(records)
            return self.reply(xlsx(records), mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filename=f'LOX-Requests-{path.split("/")[-1]}-{now().astimezone(CENTRAL).date()}.xlsx')
        if path.startswith('/api/exports/'):
            filename = path.split('/')[-1]
            if re.fullmatch(r'LOX-Requests-\d{4}-\d{2}-\d{2}\.xlsx', filename):
                file = DATA/'exports'/filename
                if file.is_file():
                    return self.reply(file.read_bytes(), mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', filename=filename)
            return self.reply({'error': 'Export not found.'}, 404)
        if path.startswith('/api/'):
            return self.reply({'error': 'Not found.'}, 404)
        super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path != '/api/requests' and not re.fullmatch(r'/api/requests/\d+', path):
            return self.reply({'error': 'Not found.'}, 404)
        # Reject cross-site form writes; API requires a JSON request from our own UI.
        if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
            return self.reply({'error': 'JSON required.'}, 415)
        if self.headers.get('Sec-Fetch-Site') == 'cross-site':
            return self.reply({'error': 'Cross-site write rejected.'}, 403)
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 20000:
                raise ValueError('Invalid request size.')
            payload = json.loads(self.rfile.read(length))
            result = save_record(payload, int(path.split('/')[-1]) if path != '/api/requests' else None)
            self.reply(result, 200 if path != '/api/requests' else 201)
        except RuntimeError as error:
            self.reply({'error': str(error)}, 409)
        except KeyError:
            self.reply({'error': 'Request not found.'}, 404)
        except (ValueError, TypeError) as error:
            self.reply({'error': str(error)}, 400)
        except Exception:
            logging.exception('Save failed')
            self.reply({'error': 'Unable to save. Please retry.'}, 500)

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    initialize()
    stop = threading.Event()
    threading.Thread(target=scheduler, args=(stop,), daemon=True).start()
    server = ThreadingHTTPServer(('0.0.0.0', int(os.getenv('PORT', '8005'))), Handler)
    try:
        server.serve_forever()
    finally:
        stop.set()
        server.server_close()

