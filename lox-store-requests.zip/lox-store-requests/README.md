# LOX Store Requests

Shared, mobile-first store request log for the Loxley district. Runs as a PWA or in a Super Dash iframe. Server-side SQLite keeps devices in sync. No login is included; anyone who can reach the app can view and edit entries.

## Start with Docker

Requirements: Docker Engine and Docker Compose plugin.

```bash
unzip lox-store-requests.zip
cd lox-store-requests
docker compose up -d --build
```

Open `http://YOUR_SERVER_IP:8005`. The supplied Compose file publishes port **8005**. To change the outside port, change only the left side of `8005:8005`.

The service uses Docker's built-in bridge, avoiding a new network allocation for this app. It restarts automatically. Data and Excel exports persist in the named `store-requests-data` volume. Rebuilds and `docker compose down` keep it; **`docker compose down -v` deletes it**.

## Fields and workflow

- Request date defaults to today in Central time and can be changed.
- Store requesting, request type, and destination are required.
- Request types: Dry Pallet Transfer, Chiller Pallet Transfer, Freezer Pallet Transfer, Store-to-store transfer, Cleanout Request, Other.
- Driver can be assigned later. Notes allow pallet counts and extra details.
- Urgent requests receive an amber marker and sort first among uncompleted requests.
- Complete with one tap. The server records the completion timestamp automatically.
- Reopen any completed request. Completing it again starts a new 48-hour period.
- Current requests includes all uncompleted entries plus entries completed less than 48 hours ago.
- Archive retains every entry indefinitely, with search, filters, editing, reopening, and Excel download. There is no delete action.
- History preserves a snapshot of every saved version. Simultaneous edits are checked so one user's stale form cannot overwrite another user's update.
- Visible pages refresh every 15 seconds. Search and status/type/urgent filters are available. Summary counters are clickable.

## Nightly Excel reports

At **midnight America/Chicago** (CST or CDT automatically), the running server creates a real `.xlsx` file containing all uncompleted requests and requests completed in the last 48 hours. The scheduler checks every 10 seconds; generation starts within about 10 seconds of midnight.

Reports are saved under `/data/exports/LOX-Requests-YYYY-MM-DD.xlsx` and appear in the **Exports** tab. They include every requested field, notes, completion time, and creation/update times. Headers are frozen, columns are filterable, and values are stored as literal text to prevent spreadsheet formula injection.

This is an automatic **server save**, not an automatic browser download. Browsers cannot reliably download files unattended at midnight when closed. Users can download saved reports from Exports, current requests with the Excel button, or the entire archive at any time. The current/archive Excel buttons export the complete respective dataset, regardless of on-screen filters.

If the app stops before midnight, it generates a catch-up report on restart for the current Central date. A catch-up report uses the state at restart; it does not reconstruct missed historical midnight snapshots. The first report on a new installation is generated at the next midnight. All saved reports remain available indefinitely.

## HTTPS, PWA installation, and Super Dash

Use a separate hostname such as `store-requests.loxload.com`. The attached dashboard already uses `requests.loxload.com` for Yard Notes; do not replace that existing host unless intended.

1. Point the new hostname's DNS at your reverse proxy.
2. Copy `nginx.conf.example` to `/etc/nginx/sites-available/store-requests.loxload.com` and adjust the upstream IP if necessary.
3. Enable and validate:

```bash
sudo ln -s /etc/nginx/sites-available/store-requests.loxload.com /etc/nginx/sites-enabled/store-requests.loxload.com
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d store-requests.loxload.com
```

HTTPS is required for normal remote PWA installation. Open the app directly in the browser to install: Chrome/Edge use Install App; on iPhone/iPad use Safari's Share → Add to Home Screen. The shell can open offline, but shared records and edits require the server; failed saves are reported and never represented as saved.

In your existing Super Dash `config.js`, add an entry inside `apps` (choose a unique key):

```javascript
{ key: "store-requests", name: "Store Requests", url: "https://store-requests.loxload.com/" },
```

Then choose Store Requests in a panel's dropdown. `loxload.com` is already allowed in the supplied dashboard configuration. This package does not modify any of your existing apps.

The app sends a Content Security Policy allowing frames from `https://superdash.loxload.com`, `https://superdash.andytalbert.com`, and its own origin. It sends no X-Frame-Options header. If your proxy independently adds `X-Frame-Options: SAMEORIGIN` or `DENY`, remove that header for this host. If your iframe has a sandbox attribute, allow scripts, same-origin, forms, and downloads. PWA installation happens from the direct app URL, not from inside the iframe.

If your parent dashboard restricts iframe sources with its own `frame-src` CSP, allow your chosen app hostname there as well.

## Backups and maintenance

To make a portable backup, briefly stop writes and copy the complete data directory:

```bash
docker compose stop store-requests
docker compose cp store-requests:/data ./store-requests-backup
docker compose start store-requests
```

Keep that directory safe: it contains SQLite records, full edit history, and the nightly exports. Restore the contents to `/data` in this service's volume while stopped, preserving ownership UID 10001. To inspect logs:

```bash
docker compose logs --tail=100 store-requests
```

## Run without Docker / validation

Python 3.12+ and system IANA timezone data are sufficient; the app has **no third-party runtime dependencies**.

```bash
python3 server.py
```

Environment settings: `PORT` (default 8005), `DATA_DIR` (default `./data`), and `APP_TIMEZONE` (default America/Chicago). The shipped UI displays Central time; keep the default timezone for the LOX district.

Tests use Python unittest; the Excel compatibility check additionally needs openpyxl in the development environment:

```bash
python3 -m unittest discover -s tests -v
```

Validation performed: request creation/editing/completion/reopening, version conflicts, 48-hour boundary, permanent retention, winter/summer midnight handling, catch-up and once-per-day reports, literal XLSX cells, API responses, and iframe headers. Browser checks covered creation of an urgent request and completion tracking. Docker itself was not available for a container build in the development environment.
