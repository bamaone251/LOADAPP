# Lox PLB Log (Synced)
This version **syncs entries across all users** by storing them in **SQLite on your VPS** and streaming updates via **SSE**.

## Run locally / on VPS
```bash
cd lox-plb-log-sync
npm install
npm start
```

Default: http://localhost:3020

## Environment (optional)
- `PORT=3020`
- `DB_PATH=/opt/lox-plb-log/data/plb.sqlite`
- `CORS_ORIGIN=https://your-dashboard-domain.com` (only if iframing from another origin)

Example:
```bash
PORT=3020 DB_PATH=./data/plb.sqlite npm start
```

## Deploy on your VPS (simple)
1. Copy folder to VPS (e.g. `/opt/lox-plb-log-sync`)
2. Install Node 18+
3. `npm install && npm start`

### Nginx reverse proxy (recommended)
Point a subdomain (e.g. `plblog.andytalbert.com`) to your VPS and proxy to port 3020.
Make sure your Nginx block includes:
- `proxy_http_version 1.1;`
- `proxy_set_header Connection "";` (for SSE)
- `proxy_buffering off;` (for SSE)

If you want, tell me your subdomain and I’ll paste a ready-to-drop Nginx server block.

## PWA support
This build includes a web app manifest, 192/512 icons, an install button (where supported), and a service worker that caches the app shell for offline launch. API and live-sync requests remain network-only so shared PLB records are not served stale.

For installability and camera scanning on phones, serve the app over HTTPS (or localhost during development).
