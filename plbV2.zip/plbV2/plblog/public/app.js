const form = document.getElementById('entryForm');
const storeInput = document.getElementById('storeInput');
const zoneInput = document.getElementById('zoneInput');
const oclInput = document.getElementById('oclInput');
const olpnInput = document.getElementById('olpnInput');
const entriesBody = document.getElementById('entriesBody');
const refreshBtn = document.getElementById('refreshBtn');
const statusPill = document.getElementById('statusPill');
const scanBtn = document.getElementById('scanBtn');
const scanModal = document.getElementById('scanModal');
const closeScanBtn = document.getElementById('closeScanBtn');
const scanVideo = document.getElementById('scanVideo');
const scanError = document.getElementById('scanError');

let entries = [];
let reportTimeZone = 'America/Chicago';

function setStatus(msg){ if(statusPill) statusPill.textContent = msg; }

function escapeHtml(s){
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function render(){
  entriesBody.innerHTML = '';
  if(entries.length === 0){
    entriesBody.innerHTML = '<tr><td colspan="6" class="muted">No entries yet</td></tr>';
    return;
  }
  for(const e of entries){
    const tr = document.createElement('tr');
    const days = PlbAge.ageDays(e.created_at, new Date(), reportTimeZone);
    tr.className = PlbAge.ageClass(days);
    tr.title = days + ' calendar day(s) old';
    tr.innerHTML = `
      <td>${escapeHtml(e.store)}</td>
      <td>${escapeHtml(e.zone)}</td>
      <td>${escapeHtml(e.ocl ?? '')}</td>
      <td>${escapeHtml(e.olpn)}</td>
      <td>${escapeHtml(new Date(e.created_at).toLocaleString())}<br><small>${days} day(s) old</small></td>
      <td><button class="btn" data-action="delete" data-id="${e.id}">Delete</button></td>
    `;
    entriesBody.appendChild(tr);
  }
}

async function api(path, opts){
  const res = await fetch(path, opts);
  const data = await res.json().catch(()=> ({}));
  if(!res.ok || data.ok === false){
    throw new Error(data.error || `Request failed: ${res.status}`);
  }
  return data;
}

async function loadEntries(){
  setStatus('Loading…');
  const data = await api('/api/entries');
  entries = data.entries || [];
  reportTimeZone = data.timeZone || reportTimeZone;
  render();
  setStatus('Ready');
}

async function addEntry(payload){
  setStatus('Saving…');
  const data = await api('/api/entries', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
  // server returns created row
  // keep oldest->newest: push
  entries = entries.filter(e => e.id !== data.entry.id);
  entries.push(data.entry);
  render();
  setStatus('Saved');
}

async function deleteEntry(id){
  setStatus('Deleting…');
  await api(`/api/entries/${encodeURIComponent(id)}`, { method:'DELETE' });
  entries = entries.filter(e => String(e.id) !== String(id));
  render();
  setStatus('Deleted');
}

form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const store = storeInput.value.trim();
  const zone = zoneInput.value.trim();
  const ocl = oclInput.value.trim();
  const olpn = olpnInput.value.trim();
  if(!store || !olpn){
    setStatus('Need Store + oLPN');
    return;
  }
  try{
    await addEntry({ store, olpn, zone, ocl });
    oclInput.value='';
    olpnInput.value='';
    olpnInput.focus();
  }catch(err){
    console.error(err);
    setStatus(err.message || 'Save failed');
  }
});

entriesBody.addEventListener('click', async (e)=>{
  const btn = e.target.closest('button[data-action="delete"]');
  if(!btn) return;
  const id = btn.dataset.id;
  try{
    await deleteEntry(id);
  }catch(err){
    console.error(err);
    setStatus(err.message || 'Delete failed');
  }
});

refreshBtn?.addEventListener('click', ()=> loadEntries());

document.getElementById('exportPdfBtn')?.addEventListener('click', ()=> {
  if(entries.length === 0){
    setStatus('No entries to export');
    return;
  }
  try{
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    
    // Title
    doc.setFontSize(16);
    doc.text('Lox PLB Log', pageWidth / 2, 15, { align: 'center' });
    
    // Export date
    doc.setFontSize(10);
    doc.text(`Exported: ${new Date().toLocaleString()}`, pageWidth / 2, 22, { align: 'center' });
    
    // Table data
    const tableData = entries.map(e => [
      e.store || '',
      e.zone || '',
      e.ocl || '',
      e.olpn || '',
      new Date(e.created_at).toLocaleString()
    ]);
    
    doc.autoTable({
      head: [['Store', 'Zone', 'OCL', 'oLPN #', 'Created']],
      body: tableData,
      startY: 30,
      theme: 'grid',
      styles: { fontSize: 9 },
      columnStyles: {
        0: { cellWidth: 15 },
        1: { cellWidth: 15 },
        2: { cellWidth: 15 },
        3: { cellWidth: 30 },
        4: { cellWidth: 40 }
      }
    });
    
    doc.save(`lox-plb-log-${new Date().toISOString().split('T')[0]}.pdf`);
    setStatus('PDF exported');
  }catch(err){
    console.error(err);
    setStatus('Export failed: ' + (err.message || 'Unknown error'));
  }
});


let scanStream = null;
let scanRAF = null;
let detector = null;

function normalizeScan(raw){
  const s = String(raw ?? '').trim();
  if(!s) return '';

  // Remove whitespace and common GS1 parentheses
  const compact = s.replace(/\s+/g,'').replace(/[()]/g,'');

  // Digits only (SSCC-18 is 18 digits; AI(00)+SSCC often yields 20 digits starting with 00)
  const digits = compact.replace(/[^0-9]/g,'');

  // If we have AI(00)+SSCC (20+ digits) -> take last 18
  if(digits.length >= 20 && digits.startsWith('00')){
    return digits.slice(-18);
  }

  // If we have at least 18 digits, take the last 18 (robust across scanners/cameras)
  if(digits.length >= 18){
    return digits.slice(-18);
  }

  // Fallback: allow alphanumerics for edge cases
  const alnum = compact.replace(/[^0-9A-Za-z_-]/g,'');
  return alnum || compact;
}

function openScan(){
  if(!scanModal) return;
  if(scanError) scanError.textContent = '';
  scanModal.classList.remove('hidden');
  startScan().catch(err => {
    console.error(err);
    if(scanError) scanError.textContent = (err && err.message) ? err.message : 'Unable to start camera';
  });
}

function closeScan(){
  if(!scanModal) return;
  scanModal.classList.add('hidden');
  stopScan();
}

async function startScan(){
  if(!('BarcodeDetector' in window)){
    throw new Error('Camera barcode scanning not supported on this device/browser. Use a hardware scanner or update Chrome.');
  }

  const formats = await window.BarcodeDetector.getSupportedFormats?.() || [];
  const want = ['code_128','ean_13','ean_8','upc_a','upc_e','itf','codabar','qr_code','data_matrix'];
  const useFormats = formats.length ? want.filter(f => formats.includes(f)) : want;
  detector = new window.BarcodeDetector({ formats: useFormats });

  scanStream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: { ideal: 'environment' } },
    audio: false
  });
  scanVideo.srcObject = scanStream;
  await scanVideo.play();

  const tick = async () => {
    try{
      if(!detector || !scanVideo || scanVideo.readyState < 2) {
        scanRAF = requestAnimationFrame(tick);
        return;
      }
      const barcodes = await detector.detect(scanVideo);
      if(barcodes && barcodes.length){
        const raw = barcodes[0].rawValue || '';
        const val = normalizeScan(raw);
        if(val){
          olpnInput.value = val;
          olpnInput.focus();
          closeScan();
          return;
        }
      }
    }catch{}
    scanRAF = requestAnimationFrame(tick);
  };
  scanRAF = requestAnimationFrame(tick);
}

function stopScan(){
  if(scanRAF){ cancelAnimationFrame(scanRAF); scanRAF = null; }
  if(scanVideo){ scanVideo.pause?.(); scanVideo.srcObject = null; }
  if(scanStream){
    for(const t of scanStream.getTracks()){
      try{ t.stop(); }catch{}
    }
    scanStream = null;
  }
  detector = null;
}

scanBtn?.addEventListener('click', openScan);
closeScanBtn?.addEventListener('click', closeScan);
scanModal?.addEventListener('click', (e)=>{ if(e.target === scanModal) closeScan(); });
document.addEventListener('keydown', (e)=>{
  if(e.key === 'Escape' && scanModal && !scanModal.classList.contains('hidden')) closeScan();
});



// Live sync via Server-Sent Events (SSE)
function connectSSE(){
  try{
    const es = new EventSource('/api/stream');
    es.onopen = ()=> setStatus('Ready');
    es.onmessage = (evt)=>{
      // Any change event -> reload
      if(evt.data === 'changed'){
        loadEntries().catch(()=>{});
      }
    };
    es.onerror = ()=>{
      // browser will auto-retry; keep status calm
      setStatus('Reconnecting…');
    };
  }catch{
    // fallback to polling every 10s if SSE not supported
    setStatus('Polling…');
    setInterval(()=> loadEntries().catch(()=>{}), 10000);
  }
}

loadEntries().then(connectSSE).catch(err=>{
  console.error(err);
  setStatus('API offline');
});


// Refresh age colors even if no one adds or deletes an entry.
setInterval(render, 30000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) render(); });
async function loadReports() {
  const data = await api('/api/reports');
  document.getElementById('reportInfo').textContent = 'Saved daily at 11:57 p.m. (' + data.timeZone + '). Finalized after midnight.';
  const select = document.getElementById('reportDate');
  const selected = select.value || data.today;
  const dates = [...new Set([data.today, ...data.reports.map(r => r.date)])].sort().reverse();
  select.innerHTML = dates.map(date => '<option value="' + date + '">' + date + (date === data.today ? ' (today)' : '') + '</option>').join('');
  if (dates.includes(selected)) select.value = selected;
}
document.getElementById('downloadReportBtn').addEventListener('click', async () => {
  try {
    setStatus('Exporting activity…');
    const date = document.getElementById('reportDate').value;
    if (!date) throw new Error('Report dates are still loading. Try again.');
    const response = await fetch('/api/reports/' + encodeURIComponent(date));
    if (!response.ok) throw new Error((await response.json()).error || 'Export failed');
    const url = URL.createObjectURL(await response.blob());
    const link = document.createElement('a');
    link.href = url; link.download = 'plb-activity-' + date + '.xlsx'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    setStatus('Excel exported');
  } catch (err) { setStatus(err.message); }
});
loadReports().catch(err => { document.getElementById('reportInfo').textContent = err.message; });
setInterval(() => loadReports().catch(() => {}), 60000);
