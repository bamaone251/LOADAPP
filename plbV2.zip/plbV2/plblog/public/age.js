(function(root) {
  function dateKey(value, timeZone) {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date(value));
    const get = type => parts.find(p => p.type === type).value;
    return `${get('year')}-${get('month')}-${get('day')}`;
  }
  function ageDays(created, now, timeZone) {
    return Math.max(0, Math.round((Date.parse(dateKey(now, timeZone)) - Date.parse(dateKey(created, timeZone))) / 86400000));
  }
  function ageClass(days) {
    return days === 0 ? 'age-green' : days === 1 ? 'age-yellow' : days === 2 ? 'age-red' : 'age-flashing';
  }
  const api = { dateKey, ageDays, ageClass };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PlbAge = api;
})(typeof window === 'undefined' ? globalThis : window);
