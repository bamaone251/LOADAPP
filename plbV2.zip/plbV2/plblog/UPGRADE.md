# PLB Log 1.1 upgrade

## Install over your existing app

1. Stop the existing app/container. Back up the entire existing data folder while stopped (including plb.sqlite, plb.sqlite-wal and plb.sqlite-shm if present).
2. Copy this package's files into your existing app folder. Keep your existing data folder and environment settings. This package contains no production database.
3. With Docker: run docker compose up -d --build from the app folder. The included compose file keeps ./data mounted at /app/data.
4. Without Docker: use Node 20 or newer, run npm ci, then npm start. Keep your existing DB_PATH setting.
5. Open the app and confirm your entries are present. Use Daily activity reports > Download Excel to check the report.

The first startup adds audit tables and triggers to the existing database. Existing PLBs and their creation timestamps remain intact. Historical additions/deletions before this upgrade cannot be reconstructed; tracking begins when this version starts.

## Reporting

- Default schedule: 11:57 p.m. America/Chicago (Central time, including daylight saving). The scheduler checks every 15 seconds, so export begins within 15 seconds of the scheduled time while the server is running.
- Files: data/reports/plb-activity-YYYY-MM-DD.xlsx by default, beside your database. REPORT_DIR can override the directory; keep it on persistent storage.
- Each workbook contains Summary and Activity sheets, with counts, action, local and UTC activity times, entry ID, store, zone, OCL, oLPN and original creation timestamp. Deleted PLBs retain these details in the audit history.
- Reports use calendar days in REPORT_TIME_ZONE, which defaults to America/Chicago. Set it to your facility's IANA timezone before first startup and keep it consistent.
- The 11:57 report contains activity through generation. After midnight it is finalized to include any activity in the final three minutes. Today's download always includes activity through the download time.
- Empty days receive reports. Missed reports are generated when the server restarts, from the tracking start date onward. An open browser is not required. The server must run to write files at the scheduled time; it cannot automatically place files on each user's desktop.
- The app provides a date selector and Download Excel button. Keep enough disk space for the audit history and daily workbooks.

## Entry borders

Age is the number of calendar date changes since creation in REPORT_TIME_ZONE, consistently across users:

- 0 days: green.
- 1 day: yellow.
- 2 days: solid red.
- 3 or more days: flashing red.

The requested wording overlaps at day 2; this package interprets the separate day-2 red rule as solid red, with flashing beginning on day 3. Colors update every 30 seconds and when a hidden page becomes visible. A visible day count supplements color; reduced-motion users receive steady red borders.

## Verification

Run npm test. Tests cover atomic audit records, rollback, no-op deletion, deleted details, long barcode preservation, formula-like text, schedule cutoff, late-night finalization, missed and empty days, lost report recovery, and calendar-day aging across both daylight-saving transitions.

The existing app has no authentication. Report routes follow its existing access model. npm audit also reports transitive dependency advisories in the existing SQLite installation toolchain and Excel workbook dependencies; resolving those requires a separate dependency migration.
