const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const sqlite3 = require('sqlite3');
const ExcelJS = require('exceljs');
const { ageDays, ageClass, dateKey } = require('../public/age');

test('calendar-day age handles midnight, DST and thresholds', () => {
  const zone = 'America/Chicago';
  assert.equal(ageDays('2026-11-01T05:30:00Z', '2026-11-02T06:15:00Z', zone), 1);
  assert.equal(ageDays('2026-03-08T06:30:00Z', '2026-03-09T05:15:00Z', zone), 1);
  assert.equal(ageDays('2026-11-01T05:01:00Z', '2026-11-01T05:59:00Z', zone), 0);
  assert.equal(dateKey('2026-11-01T04:59:00Z', zone), '2026-10-31');
  assert.deepEqual([0,1,2,3,20].map(ageClass), ['age-green','age-yellow','age-red','age-flashing','age-flashing']);
});

test('atomic audit, deletion snapshots, Excel values, cutoff and catch-up', async t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'plb-upgrade-'));
  const db = new sqlite3.Database(path.join(directory, 'test.sqlite'));
  const run = (sql, values = []) => new Promise((resolve, reject) => db.run(sql, values, function(err) { err ? reject(err) : resolve(this); }));
  const all = sql => new Promise((resolve,reject) => db.all(sql, (err, rows) => err ? reject(err) : resolve(rows)));
  t.after(async () => {
    await new Promise(resolve => db.close(resolve));
    fs.rmSync(directory, { recursive: true, force: true });
  });
  await run('CREATE TABLE entries (id INTEGER PRIMARY KEY, store TEXT, zone TEXT, ocl TEXT, olpn TEXT, created_at TEXT)');
  // Existing entries retain their original age and do not become new additions.
  await run("INSERT INTO entries VALUES(1,'FE11','AMB','1','000123456789012345','2025-01-01T00:00:00.000Z')");
  const reports = require('../reports')(db, directory, 'America/Chicago');
  await reports.init();
  assert.equal((await all('SELECT * FROM activity')).length, 0);
  await run("INSERT INTO entries VALUES(2,'=1+1','CHL','01','000123456789012345','2026-01-01T12:00:00.000Z')");
  await run('DELETE FROM entries WHERE id=2');
  await run('DELETE FROM entries WHERE id=999');
  await run('BEGIN');
  await run('DELETE FROM entries WHERE id=1');
  await run('ROLLBACK');
  let activity = await all('SELECT * FROM activity ORDER BY id');
  assert.deepEqual(activity.map(r => r.action), ['Added', 'Deleted']);
  assert.equal(activity[1].olpn, '000123456789012345');
  assert.equal((await all('SELECT * FROM entries')).length, 1);
  await run("UPDATE report_settings SET value='2026-01-01' WHERE key='tracking_start'");
  await run("UPDATE activity SET occurred_at='2026-01-01T12:00:00.000Z'");
  await reports.tick(new Date('2026-01-02T05:56:59Z')); // Jan 1, 23:56 CST
  assert.equal((await reports.list()).length, 0);
  await reports.tick(new Date('2026-01-02T05:57:00Z'));
  assert.equal((await reports.list()).length, 1);
  const file = path.join(directory, 'plb-activity-2026-01-01.xlsx');
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(file);
  const sheet = workbook.getWorksheet('Activity');
  assert.equal(sheet.rowCount, 3);
  assert.equal(sheet.getCell('I2').value, '000123456789012345');
  assert.equal(sheet.getCell('F2').value, '=1+1');
  assert.equal(sheet.getCell('F2').type, ExcelJS.ValueType.String);
  assert.equal(workbook.getWorksheet('Summary').getCell('B4').value, 1);
  // Activity after 23:57 must be included in the final report after midnight.
  await run("INSERT INTO entries VALUES(3,'FE12','AMB','','123','2026-01-02T05:59:00.000Z')");
  await run("UPDATE activity SET occurred_at='2026-01-02T05:59:00.000Z' WHERE entry_id=3");
  await run("UPDATE daily_reports SET generated_at='2026-01-02T05:57:00.000Z'");
  await reports.tick(new Date('2026-01-02T06:00:00Z'));
  await workbook.xlsx.readFile(file);
  assert.equal(workbook.getWorksheet('Activity').rowCount, 4);
  // A restart after two missed days writes even the empty day's workbook.
  await reports.tick(new Date('2026-01-04T06:00:00Z'));
  assert.deepEqual((await reports.list()).map(r => r.date), ['2026-01-03','2026-01-02','2026-01-01']);
  await workbook.xlsx.readFile(path.join(directory, 'plb-activity-2026-01-03.xlsx'));
  assert.equal(workbook.getWorksheet('Summary').getCell('B6').value, 0);
  // Missing files are recovered without losing the activity history.
  fs.unlinkSync(file);
  await reports.tick(new Date('2026-01-04T06:00:00Z'));
  assert.ok(fs.existsSync(file));
});
