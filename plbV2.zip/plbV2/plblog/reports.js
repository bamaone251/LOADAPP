const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const { dateKey } = require('./public/age');

function reporting(db, directory, timeZone) {
  const run = (sql, params = []) => new Promise((resolve, reject) => db.run(sql, params, function(err) { err ? reject(err) : resolve(this); }));
  const all = (sql, params = []) => new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));
  let queue = Promise.resolve();
  function exclusive(task) {
    const result = queue.then(task);
    queue = result.catch(() => {});
    return result;
  }
  const today = (now = new Date()) => dateKey(now, timeZone);
  async function init() {
    // Validate timezone before starting the server.
    today();
    fs.mkdirSync(directory, { recursive: true });
    await run(`CREATE TABLE IF NOT EXISTS activity (
      id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL,
      entry_id INTEGER NOT NULL, store TEXT, zone TEXT, ocl TEXT, olpn TEXT,
      created_at TEXT NOT NULL, occurred_at TEXT NOT NULL)`);
    await run(`CREATE INDEX IF NOT EXISTS activity_time ON activity(occurred_at)`);
    // Database triggers make each change and its audit record one atomic operation.
    for (const [event, action, row] of [['INSERT', 'Added', 'NEW'], ['DELETE', 'Deleted', 'OLD']]) {
      await run(`CREATE TRIGGER IF NOT EXISTS audit_entry_${event.toLowerCase()}
        AFTER ${event} ON entries BEGIN
        INSERT INTO activity(action,entry_id,store,zone,ocl,olpn,created_at,occurred_at)
        VALUES ('${action}',${row}.id,${row}.store,${row}.zone,${row}.ocl,${row}.olpn,
          ${row}.created_at,strftime('%Y-%m-%dT%H:%M:%fZ','now')); END`);
    }
    await run(`CREATE TABLE IF NOT EXISTS report_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`);
    await run(`INSERT OR IGNORE INTO report_settings VALUES ('tracking_start',?)`, [today()]);
    await run(`CREATE TABLE IF NOT EXISTS daily_reports (date TEXT PRIMARY KEY, event_id INTEGER NOT NULL, generated_at TEXT NOT NULL)`);
  }
  async function writeReport(date) {
    // ISO timestamps are UTC. Select a wide UTC window, then use the configured
    // calendar date to handle both DST transitions without fixed offsets.
    const center = Date.parse(date + 'T00:00:00Z');
    const candidates = await all(`SELECT * FROM activity WHERE occurred_at >= ? AND occurred_at < ? ORDER BY id`,
      [new Date(center - 86400000).toISOString(), new Date(center + 172800000).toISOString()]);
    const rows = candidates.filter(row => today(row.occurred_at) === date);
    const workbook = new ExcelJS.Workbook();
    const summary = workbook.addWorksheet('Summary');
    summary.addRows([
      ['PLB daily activity', date], ['Time zone', timeZone],
      ['Generated (UTC)', new Date().toISOString()],
      ['Added', rows.filter(r => r.action === 'Added').length],
      ['Deleted', rows.filter(r => r.action === 'Deleted').length],
      ['Total actions', rows.length],
      ['Coverage', 'Calendar day; current-day exports contain activity through generation time.'],
      ['Tracking began', (await all("SELECT value FROM report_settings WHERE key='tracking_start'"))[0].value]
    ]);
    summary.getColumn(1).width = 24;
    summary.getColumn(2).width = 90;
    const sheet = workbook.addWorksheet('Activity');
    sheet.columns = [
      { header: 'Action', key: 'action', width: 12 },
      { header: 'Occurred (local)', key: 'local', width: 28 },
      { header: 'Time zone', key: 'timeZone', width: 24 },
      { header: 'Occurred (UTC)', key: 'occurred_at', width: 28 },
      { header: 'Entry ID', key: 'entry_id', width: 12 },
      { header: 'Store', key: 'store', width: 16 },
      { header: 'Zone', key: 'zone', width: 12 },
      { header: 'OCL', key: 'ocl', width: 16 },
      { header: 'oLPN #', key: 'olpn', width: 28 },
      { header: 'Created (UTC)', key: 'created_at', width: 28 }
    ];
    for (const row of rows) sheet.addRow({ ...row, timeZone,
      local: new Date(row.occurred_at).toLocaleString('en-US', { timeZone, hour12: false }) });
    sheet.views = [{ state: 'frozen', ySplit: 1 }];
    sheet.autoFilter = 'A1:J1';
    sheet.getRow(1).font = { bold: true };
    // Values are strings, never formulas; preserve leading zeros and long oLPNs.
    for (const key of ['store', 'zone', 'ocl', 'olpn']) sheet.getColumn(key).numFmt = '@';
    const filename = path.join(directory, `plb-activity-${date}.xlsx`);
    const temporary = filename + '.tmp';
    await workbook.xlsx.writeFile(temporary);
    fs.renameSync(temporary, filename);
    const eventId = rows.length ? rows[rows.length - 1].id : 0;
    await run(`INSERT INTO daily_reports VALUES (?,?,?) ON CONFLICT(date) DO UPDATE SET event_id=excluded.event_id, generated_at=excluded.generated_at`,
      [date, eventId, new Date().toISOString()]);
    return filename;
  }
  const generate = date => exclusive(() => writeReport(date));
  const list = () => all('SELECT date, generated_at FROM daily_reports ORDER BY date DESC');
  const tick = (now = new Date()) => exclusive(async () => {
    const current = today(now);
    const parts = new Intl.DateTimeFormat('en-GB', { timeZone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(now);
    const start = (await all("SELECT value FROM report_settings WHERE key='tracking_start'"))[0].value;
    const existing = new Map((await all('SELECT * FROM daily_reports')).map(r => [r.date, r]));
    for (let date = start; date <= current; date = new Date(Date.parse(date) + 86400000).toISOString().slice(0,10)) {
      if (date === current && parts < '23:57') continue;
      const previous = existing.get(date);
      // Finalize each day's last three minutes after midnight. Retry missed
      // exports on restart, even when that day had no activity.
      const exportedBeforeCutoff = previous && date === current &&
        new Intl.DateTimeFormat('en-GB', { timeZone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(previous.generated_at)) < '23:57';
      if (!previous || exportedBeforeCutoff || !fs.existsSync(path.join(directory, `plb-activity-${date}.xlsx`)) ||
          (date < current && today(previous.generated_at) === date)) await writeReport(date);
    }
  });
  return { init, today, generate, list, tick };
}
module.exports = reporting;
