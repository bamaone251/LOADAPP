# Loxley Load Team — Run Tracker (Scoreboard)

Real-time loader scoreboard with a public "Run Tracker" page and an Admin page.

## Features
- Big counters at the top: **Total Runs**, **Completed**, **Remaining**
- Loader cards: tap your card to add **+1 run** (plays a gong sound)
- Live sync across all devices using Socket.IO (no refresh needed)
- Admin page to set total runs, set loaders list, reset counts, and undo last tap
- Uses a simple JSON database file at `data/db.json` (persists across restarts)

## Run locally (Windows / Mac / Linux)
1. Install Node.js (LTS)
2. In this folder:
   ```bash
   npm install
   npm start
   ```
3. Open:
   - Run Tracker: http://localhost:3015
   - Admin: http://localhost:3015/admin

## Lock down the Admin actions (recommended on your VPS)
Set an environment variable:
- `ADMIN_PIN=1234` (pick your own)

Example (Linux):
```bash
export ADMIN_PIN=1234
npm start
```

The admin page stores the PIN in the browser (LocalStorage) and sends it as a header on admin API calls.

## Deploy with Docker (recommended for your VPS)
```bash
docker compose up -d --build
```

Then reverse-proxy the container with Nginx to a subdomain like `runtracker.andytalbert.com`.
