const path = require("path");
const fs = require("fs");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");

const PORT = process.env.PORT || 3016;
const ADMIN_PIN = process.env.ADMIN_PIN || ""; // optional

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "db.json");

// ---------- tiny persistence layer (single-file JSON) ----------
const DEFAULT_STATE = {
  totalRuns: 50,
  loaders: [
    { id: "l1", name: "Austin", runs: 0 },
    { id: "l2", name: "Chip", runs: 0 },
    { id: "l3", name: "Brittany", runs: 0 },
  ],
  updatedAt: new Date().toISOString()
};

function ensureDataFile() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(DEFAULT_STATE, null, 2), "utf8");
  }
}

let state = null;
let writing = Promise.resolve();

function loadState() {
  ensureDataFile();
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf8");
    state = JSON.parse(raw);
    // minimal migration safety
    if (!state || typeof state !== "object") state = { ...DEFAULT_STATE };
    if (!Array.isArray(state.loaders)) state.loaders = [];
    if (typeof state.totalRuns !== "number") state.totalRuns = DEFAULT_STATE.totalRuns;
    state.updatedAt = new Date().toISOString();
  } catch (e) {
    console.error("Failed to read db.json, re-seeding defaults:", e);
    state = { ...DEFAULT_STATE, updatedAt: new Date().toISOString() };
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2), "utf8");
  }
}

function saveState() {
  state.updatedAt = new Date().toISOString();
  // serialize writes so we don't corrupt file
  writing = writing.then(() =>
    fs.promises.writeFile(DATA_FILE, JSON.stringify(state, null, 2), "utf8")
  ).catch((e) => console.error("Write error:", e));
  return writing;
}

function computedState() {
  const totalCompleted = state.loaders.reduce((sum, l) => sum + (Number(l.runs) || 0), 0);
  return {
    ...state,
    totalCompleted,
    remaining: Math.max(0, (Number(state.totalRuns) || 0) - totalCompleted),
  };
}

function broadcast() {
  io.emit("state", computedState());
}

loadState();

// ---------- middleware ----------
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function requireAdmin(req, res, next) {
  // If no ADMIN_PIN is set, admin endpoints are open (LAN use).
  if (!ADMIN_PIN) return next();
  const pin = req.get("x-admin-pin") || "";
  if (pin !== ADMIN_PIN) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// ---------- pages ----------
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));

// ---------- public API ----------
app.get("/api/state", (req, res) => {
  res.json(computedState());
});

app.post("/api/tap", async (req, res) => {
  const { loaderId } = req.body || {};
  const loader = state.loaders.find(l => l.id === loaderId);
  if (!loader) return res.status(404).json({ error: "Loader not found" });

  loader.runs = (Number(loader.runs) || 0) + 1;
  await saveState();
  broadcast();
  res.json({ ok: true, state: computedState() });
});

// ---------- admin API ----------
app.post("/api/admin/setTotalRuns", requireAdmin, async (req, res) => {
  const { totalRuns } = req.body || {};
  const n = Number(totalRuns);
  if (!Number.isFinite(n) || n < 0 || n > 9999) {
    return res.status(400).json({ error: "totalRuns must be a number between 0 and 9999" });
  }
  state.totalRuns = Math.round(n);
  await saveState();
  broadcast();
  res.json({ ok: true, state: computedState() });
});

app.post("/api/admin/resetCounts", requireAdmin, async (req, res) => {
  state.loaders = state.loaders.map(l => ({ ...l, runs: 0 }));
  await saveState();
  broadcast();
  res.json({ ok: true, state: computedState() });
});

app.post("/api/admin/setLoaders", requireAdmin, async (req, res) => {
  const { names } = req.body || {};
  if (!Array.isArray(names)) return res.status(400).json({ error: "names must be an array" });

  const cleaned = names
    .map(s => String(s || "").trim())
    .filter(Boolean)
    .slice(0, 50);

  // keep existing runs if same name exists
  const byName = new Map(state.loaders.map(l => [l.name.toLowerCase(), l]));
  const next = cleaned.map((name, idx) => {
    const prev = byName.get(name.toLowerCase());
    return {
      id: prev?.id || `l${Date.now()}_${idx}`,
      name,
      runs: Number(prev?.runs) || 0
    };
  });

  state.loaders = next;
  await saveState();
  broadcast();
  res.json({ ok: true, state: computedState() });
});

app.post("/api/admin/undoLast", requireAdmin, async (req, res) => {
  // undo last tap on a specific loader (or last non-zero loader if not provided)
  const { loaderId } = req.body || {};
  let loader = null;

  if (loaderId) loader = state.loaders.find(l => l.id === loaderId);
  if (!loader) loader = [...state.loaders].reverse().find(l => (Number(l.runs) || 0) > 0);

  if (!loader) return res.status(400).json({ error: "Nothing to undo" });

  loader.runs = Math.max(0, (Number(loader.runs) || 0) - 1);
  await saveState();
  broadcast();
  res.json({ ok: true, state: computedState() });
});

// ---------- sockets ----------
io.on("connection", (socket) => {
  socket.emit("state", computedState());
});

server.listen(PORT, () => {
  console.log(`✅ Run Tracker listening on http://localhost:${PORT}`);
  if (ADMIN_PIN) console.log("🔒 Admin PIN enabled via ADMIN_PIN env var.");
  else console.log("⚠️  Admin PIN not set (admin endpoints open). Set ADMIN_PIN to lock it down.");
});
