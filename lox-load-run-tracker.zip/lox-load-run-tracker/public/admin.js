const socket = io();

const totalRunsInput = document.getElementById("totalRunsInput");
const loadersText = document.getElementById("loadersText");
const saveTotalBtn = document.getElementById("saveTotalBtn");
const resetBtn = document.getElementById("resetBtn");
const saveLoadersBtn = document.getElementById("saveLoadersBtn");
const undoBtn = document.getElementById("undoBtn");
const liveEl = document.getElementById("live");
const lockBtn = document.getElementById("lockBtn");
const toastEl = document.getElementById("toast");

function toast(msg){
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  clearTimeout(toastEl._t);
  toastEl._t = setTimeout(() => toastEl.classList.remove("show"), 2000);
}

function getPin(){
  return localStorage.getItem("runTrackerAdminPin") || "";
}

function setPin(){
  const cur = getPin();
  const next = prompt("Enter ADMIN PIN (matches server env ADMIN_PIN). Leave blank to clear.", cur);
  if (next === null) return;
  localStorage.setItem("runTrackerAdminPin", next);
  toast(next ? "🔒 PIN saved in this browser" : "🔓 PIN cleared");
}

lockBtn.addEventListener("click", setPin);

async function post(url, body){
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-admin-pin": getPin()
    },
    body: JSON.stringify(body || {})
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.error || `HTTP ${res.status}`);
  return json;
}

async function saveTotal(){
  const n = Number(totalRunsInput.value);
  await post("/api/admin/setTotalRuns", { totalRuns: n });
  toast("✅ Total runs saved");
}

async function resetCounts(){
  if (!confirm("Reset ALL loader counts to 0?")) return;
  await post("/api/admin/resetCounts");
  toast("✅ Counts reset");
}

async function undoLast(){
  await post("/api/admin/undoLast");
  toast("↩️ Undid last tap");
}

async function saveLoaders(){
  const names = loadersText.value
    .split("\n")
    .map(s => s.trim())
    .filter(Boolean);

  if (names.length === 0) {
    if (!confirm("No names entered. Clear all loaders?")) return;
  }

  await post("/api/admin/setLoaders", { names });
  toast("✅ Loaders saved");
}

saveTotalBtn.addEventListener("click", () => saveTotal().catch(e => toast(`❌ ${e.message}`)));
resetBtn.addEventListener("click", () => resetCounts().catch(e => toast(`❌ ${e.message}`)));
saveLoadersBtn.addEventListener("click", () => saveLoaders().catch(e => toast(`❌ ${e.message}`)));
undoBtn.addEventListener("click", () => undoLast().catch(e => toast(`❌ ${e.message}`)));

function render(state){
  totalRunsInput.value = state.totalRuns ?? "";
  loadersText.value = (state.loaders || []).map(l => l.name).join("\n");

  const totalCompleted = state.totalCompleted ?? 0;
  const remaining = state.remaining ?? 0;
  liveEl.innerHTML = `
    <div><strong>Total Runs:</strong> ${state.totalRuns ?? 0}</div>
    <div><strong>Completed:</strong> ${totalCompleted}</div>
    <div><strong>Remaining:</strong> ${remaining}</div>
    <div style="margin-top:6px;"><strong>Last update:</strong> ${state.updatedAt ? new Date(state.updatedAt).toLocaleString() : "—"}</div>
    ${state._locked ? `<div style="margin-top:6px;color:#fbbf24;">Locked</div>` : ""}
  `;
}

socket.on("state", render);

fetch("/api/state").then(r => r.json()).then(render).catch(()=>{});
