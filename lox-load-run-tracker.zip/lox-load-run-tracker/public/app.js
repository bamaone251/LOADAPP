const socket = io();

const grid = document.getElementById("grid");
const totalRunsEl = document.getElementById("totalRuns");
const completedRunsEl = document.getElementById("completedRuns");
const remainingRunsEl = document.getElementById("remainingRuns");
const statusEl = document.getElementById("status");
const toastEl = document.getElementById("toast");

let current = null;

function toast(msg){
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  clearTimeout(toastEl._t);
  toastEl._t = setTimeout(() => toastEl.classList.remove("show"), 1800);
}

// --- "gong" using WebAudio (no file needed, works offline) ---
let audioCtx = null;
function gong(){
  try{
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    const now = audioCtx.currentTime;

    // two detuned partials + noise burst for metallic hit
    const o1 = audioCtx.createOscillator();
    const o2 = audioCtx.createOscillator();
    o1.type = "sine";
    o2.type = "sine";
    o1.frequency.setValueAtTime(220, now);
    o2.frequency.setValueAtTime(330, now);
    o2.detune.setValueAtTime(18, now);

    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.9, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.8);

    // subtle metallic shimmer
    const biquad = audioCtx.createBiquadFilter();
    biquad.type = "bandpass";
    biquad.frequency.setValueAtTime(900, now);
    biquad.Q.setValueAtTime(1.2, now);

    // noise click
    const bufferSize = audioCtx.sampleRate * 0.08;
    const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i=0;i<bufferSize;i++) data[i] = (Math.random()*2-1) * Math.exp(-i/(bufferSize/8));
    const noise = audioCtx.createBufferSource();
    noise.buffer = noiseBuffer;

    const noiseGain = audioCtx.createGain();
    noiseGain.gain.setValueAtTime(0.35, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);

    o1.connect(gain);
    o2.connect(gain);
    gain.connect(biquad);
    biquad.connect(audioCtx.destination);

    noise.connect(noiseGain);
    noiseGain.connect(audioCtx.destination);

    o1.start(now);
    o2.start(now);
    noise.start(now);

    o1.stop(now + 2);
    o2.stop(now + 2);
    noise.stop(now + 0.1);
  }catch(e){
    // ignore
  }
}

function render(state){
  current = state;
  totalRunsEl.textContent = state.totalRuns ?? "—";
  completedRunsEl.textContent = state.totalCompleted ?? "—";
  remainingRunsEl.textContent = state.remaining ?? "—";

  grid.innerHTML = "";
  (state.loaders || []).forEach(loader => {
    const card = document.createElement("div");
    card.className = "card";
    card.setAttribute("role", "button");
    card.setAttribute("tabindex", "0");
    card.setAttribute("aria-label", `${loader.name}, ${loader.runs} runs completed`);

    card.innerHTML = `
      <div class="card-inner">
        <div>
          <div class="loader-name">${escapeHtml(loader.name)}</div>
          <div class="hint" style="margin-top:6px"></div>
        </div>
        <div class="runs">
          <div class="num">${Number(loader.runs) || 0}</div>
          <div class="sub">runs</div>
        </div>
      </div>
    `;

    const tap = async () => {
      // required on iOS for audio: resume on first gesture
      if (audioCtx && audioCtx.state === "suspended") await audioCtx.resume().catch(()=>{});
      await fetch("/api/tap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ loaderId: loader.id })
      }).then(r => r.json()).then(j => {
        if(j?.error) throw new Error(j.error);
        gong();
      }).catch(err => toast(`❌ ${err.message || err}`));
    };

    card.addEventListener("click", tap);
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); tap(); }
    });

    grid.appendChild(card);
  });

  const stamp = state.updatedAt ? new Date(state.updatedAt).toLocaleString() : "";
  statusEl.textContent = `Live • last update ${stamp}`;
}

function escapeHtml(str){
  return String(str).replace(/[&<>"']/g, s => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  })[s]);
}

socket.on("connect", () => {
  statusEl.textContent = "Live • connected";
});

socket.on("disconnect", () => {
  statusEl.textContent = "Offline • reconnecting…";
});

socket.on("state", (state) => {
  render(state);
});

// initial fetch (helps if websocket blocked)
fetch("/api/state").then(r => r.json()).then(render).catch(()=>{});
